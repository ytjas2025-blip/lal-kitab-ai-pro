# Rule Source & Method Notes — V6

Lal Kitab has multiple editions, translations and teaching lineages. Public modern references also disagree on details such as Pakka Ghar tables, sleeping-house rules, Rin categories and annual progression. V6 therefore treats those as **source-aware rule profiles**, not invisible universal truths.

## Separation of layers
1. **Calculated astronomy** — Swiss Ephemeris/Moshier, Lahiri sidereal longitude, sign, degree and retrograde flag.
2. **Traditional/reference layer** — fixed-house Lal Kitab framework, Pakka/Uchcha/Neecha references, relationships, Drishti, Masnui, technical Teva and Rin review.
3. **Software synthesis** — 16-domain scores, event-theme windows, consensus, compatibility and rectification ranking.
4. **Narrative layer** — built-in/OpenAI explanation.

## Annual / Varshphal boundary
V6 keeps the age-based Lal Kitab annual house-rotation layer separate from the astronomical birthday comparison. It does not silently blend Tajika solar-return methods into the Lal Kitab annual progression workflow.

Modern explanatory references consulted while designing the method boundary include:
- Paramarsh: Lal Kitab Varshphal — annual progression described separately from Tajika.
- PanchangBodh: Lal Kitab Varshphal — age-based annual-house transformation example.
- xalen-lalkitab documentation: annual chart built by rotating the birth chart by year/age.

These public references are not treated as a substitute for primary editions.

## Rin boundary
Modern sources disagree on how many Rin categories to emphasize (examples range from three/six/seven to nine). V6 keeps a nine-category review workspace but does **not** claim a single simplified placement test is a canonical diagnosis. Rin is presented as traditional symbolic terminology, not proof of wrongdoing or literal debt.

## Compatibility boundary
The V6 Compatibility Lab is a software synthesis based on domain alignment and low-weight planet-house resonance. It is not claimed to be a classical Lal Kitab marriage-matching canon, and its index is not a probability of relationship success.

## Rectification boundary
The V6 Birth-Time Rectification Assistant ranks nearby candidate times against user-supplied known-event years using the same explainable forecast engine. It is exploratory only. A low discrimination spread is explicitly shown when the model cannot distinguish candidate times.

## Safety boundary
No deterministic output is generated for death, disease diagnosis, pregnancy/fertility, crime, court results, gambling wins, exact investment returns or other safety-critical outcomes. High-stakes decisions must use appropriate professional and real-world evidence.
