from __future__ import annotations
import json, sqlite3
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional

BASE_DIR=Path(__file__).resolve().parent
DB_PATH=BASE_DIR/'data'/'lal_kitab_pro.db'
DB_PATH.parent.mkdir(parents=True,exist_ok=True)

def conn():
    c=sqlite3.connect(DB_PATH)
    c.row_factory=sqlite3.Row
    return c

def init_db():
    with conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS profiles(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,birth_date TEXT NOT NULL,birth_time TEXT NOT NULL,city TEXT,
            timezone_offset REAL,latitude REAL,longitude REAL,rule_profile TEXT,notes TEXT,
            chart_json TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS remedy_programs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,planet TEXT NOT NULL,
            remedy TEXT NOT NULL,duration INTEGER NOT NULL DEFAULT 43,start_date TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        );
        CREATE TABLE IF NOT EXISTS remedy_checkins(
            id INTEGER PRIMARY KEY AUTOINCREMENT,program_id INTEGER NOT NULL,day_no INTEGER NOT NULL,checkin_date TEXT NOT NULL,
            completed INTEGER NOT NULL DEFAULT 1,note TEXT,created_at TEXT NOT NULL,
            UNIQUE(program_id,day_no),FOREIGN KEY(program_id) REFERENCES remedy_programs(id)
        );
        CREATE TABLE IF NOT EXISTS notes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,note TEXT NOT NULL,created_at TEXT NOT NULL,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        );
        CREATE TABLE IF NOT EXISTS prediction_outcomes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,year INTEGER NOT NULL,domain TEXT NOT NULL,
            predicted_score REAL,outcome TEXT NOT NULL,note TEXT,created_at TEXT NOT NULL,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        );
        CREATE TABLE IF NOT EXISTS followups(
            id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,due_date TEXT NOT NULL,kind TEXT NOT NULL,
            note TEXT,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        );
        CREATE TABLE IF NOT EXISTS chat_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER,mode TEXT NOT NULL,question TEXT NOT NULL,answer TEXT NOT NULL,created_at TEXT NOT NULL,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        );
        CREATE TABLE IF NOT EXISTS consultation_sessions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,title TEXT NOT NULL,summary TEXT,actions TEXT,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        );
        CREATE TABLE IF NOT EXISTS favorite_insights(
            id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,category TEXT NOT NULL,title TEXT NOT NULL,content TEXT NOT NULL,created_at TEXT NOT NULL,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        );
        CREATE TABLE IF NOT EXISTS appointments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER,appointment_at TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'consultation',
            fee REAL NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'scheduled',note TEXT,created_at TEXT NOT NULL,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        );
        CREATE TABLE IF NOT EXISTS payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER,amount REAL NOT NULL,mode TEXT NOT NULL DEFAULT 'cash',
            reference TEXT,note TEXT,created_at TEXT NOT NULL,
            FOREIGN KEY(profile_id) REFERENCES profiles(id)
        );
        CREATE TABLE IF NOT EXISTS team_members(
            id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'Astrologer',phone TEXT,email TEXT,
            status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL
        );
        ''')

def rowdict(row):
    return dict(row) if row else None

def save_profile(data:Dict[str,Any],chart:Dict[str,Any])->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        cur=c.execute('''INSERT INTO profiles(name,birth_date,birth_time,city,timezone_offset,latitude,longitude,rule_profile,notes,chart_json,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',(
            data.get('name'),data.get('birth_date'),data.get('birth_time'),data.get('city'),data.get('timezone_offset'),data.get('latitude'),data.get('longitude'),data.get('rule_profile'),data.get('notes',''),json.dumps(chart,ensure_ascii=False),now,now))
        pid=cur.lastrowid
    return get_profile(pid)

def list_profiles(search:str='')->List[Dict[str,Any]]:
    with conn() as c:
        if search:
            rows=c.execute("SELECT id,name,birth_date,birth_time,city,rule_profile,created_at,updated_at FROM profiles WHERE lower(name) LIKE ? ORDER BY updated_at DESC",(f'%{search.lower()}%',)).fetchall()
        else:
            rows=c.execute("SELECT id,name,birth_date,birth_time,city,rule_profile,created_at,updated_at FROM profiles ORDER BY updated_at DESC").fetchall()
    return [dict(r) for r in rows]

def get_profile(pid:int)->Optional[Dict[str,Any]]:
    with conn() as c:r=c.execute('SELECT * FROM profiles WHERE id=?',(pid,)).fetchone()
    if not r:return None
    d=dict(r);d['chart']=json.loads(d.pop('chart_json'));return d

def update_chart(pid:int,chart:Dict[str,Any],data:Optional[Dict[str,Any]]=None)->Optional[Dict[str,Any]]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        if data:
            c.execute('''UPDATE profiles SET name=?,birth_date=?,birth_time=?,city=?,timezone_offset=?,latitude=?,longitude=?,rule_profile=?,notes=?,chart_json=?,updated_at=? WHERE id=?''',(
                data.get('name'),data.get('birth_date'),data.get('birth_time'),data.get('city'),data.get('timezone_offset'),data.get('latitude'),data.get('longitude'),data.get('rule_profile'),data.get('notes',''),json.dumps(chart,ensure_ascii=False),now,pid))
        else:c.execute('UPDATE profiles SET chart_json=?,updated_at=? WHERE id=?',(json.dumps(chart,ensure_ascii=False),now,pid))
    return get_profile(pid)

def delete_profile(pid:int)->bool:
    with conn() as c:
        pids=[r['id'] for r in c.execute('SELECT id FROM remedy_programs WHERE profile_id=?',(pid,)).fetchall()]
        if pids:c.executemany('DELETE FROM remedy_checkins WHERE program_id=?',[(x,) for x in pids])
        c.execute('DELETE FROM remedy_programs WHERE profile_id=?',(pid,));c.execute('DELETE FROM notes WHERE profile_id=?',(pid,));cur=c.execute('DELETE FROM profiles WHERE id=?',(pid,))
    return cur.rowcount>0

def stats()->Dict[str,Any]:
    with conn() as c:
        profiles=c.execute('SELECT COUNT(*) n FROM profiles').fetchone()['n']
        active=c.execute("SELECT COUNT(*) n FROM remedy_programs WHERE status='active'").fetchone()['n']
        notes=c.execute('SELECT COUNT(*) n FROM notes').fetchone()['n']
        outcomes=c.execute('SELECT COUNT(*) n FROM prediction_outcomes').fetchone()['n']
        followups=c.execute("SELECT COUNT(*) n FROM followups WHERE status='open'").fetchone()['n']
    
        chats=c.execute('SELECT COUNT(*) n FROM chat_history').fetchone()['n']
        sessions=c.execute("SELECT COUNT(*) n FROM consultation_sessions WHERE status='open'").fetchone()['n']
        appointments=c.execute("SELECT COUNT(*) n FROM appointments WHERE status='scheduled'").fetchone()['n']
        revenue=c.execute('SELECT COALESCE(SUM(amount),0) n FROM payments').fetchone()['n']
        team=c.execute("SELECT COUNT(*) n FROM team_members WHERE status='active'").fetchone()['n']
    return {'profiles':profiles,'active_remedies':active,'notes':notes,'prediction_outcomes':outcomes,'open_followups':followups,'ai_chats':chats,'open_consultations':sessions,'scheduled_appointments':appointments,'payments_total':round(float(revenue or 0),2),'active_team':team}

def add_remedy(profile_id:int,planet:str,remedy:str,duration:int,start_date:str)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        cur=c.execute('INSERT INTO remedy_programs(profile_id,planet,remedy,duration,start_date,status,created_at) VALUES(?,?,?,?,?,?,?)',(profile_id,planet,remedy,duration,start_date,'active',now));rid=cur.lastrowid
    return get_remedy(rid)

def get_remedy(rid:int)->Optional[Dict[str,Any]]:
    with conn() as c:
        r=c.execute('SELECT * FROM remedy_programs WHERE id=?',(rid,)).fetchone();checks=c.execute('SELECT * FROM remedy_checkins WHERE program_id=? ORDER BY day_no',(rid,)).fetchall()
    if not r:return None
    d=dict(r);d['checkins']=[dict(x) for x in checks];d['completed_days']=sum(x['completed'] for x in d['checkins']);d['progress']=round(100*d['completed_days']/max(d['duration'],1),1);return d

def list_remedies(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c:ids=[r['id'] for r in c.execute('SELECT id FROM remedy_programs WHERE profile_id=? ORDER BY created_at DESC',(profile_id,)).fetchall()]
    return [get_remedy(i) for i in ids]

def checkin(rid:int,day_no:int,date:str,note:str='',completed:bool=True)->Optional[Dict[str,Any]]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        c.execute('''INSERT INTO remedy_checkins(program_id,day_no,checkin_date,completed,note,created_at) VALUES(?,?,?,?,?,?)
        ON CONFLICT(program_id,day_no) DO UPDATE SET checkin_date=excluded.checkin_date,completed=excluded.completed,note=excluded.note''',(rid,day_no,date,1 if completed else 0,note,now))
        rem=c.execute('SELECT duration FROM remedy_programs WHERE id=?',(rid,)).fetchone()
        if rem:
            done=c.execute('SELECT COUNT(*) n FROM remedy_checkins WHERE program_id=? AND completed=1',(rid,)).fetchone()['n']
            if done>=rem['duration']:c.execute("UPDATE remedy_programs SET status='completed' WHERE id=?",(rid,))
    return get_remedy(rid)

def add_note(profile_id:int,note:str)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO notes(profile_id,note,created_at) VALUES(?,?,?)',(profile_id,note,now));nid=cur.lastrowid;r=c.execute('SELECT * FROM notes WHERE id=?',(nid,)).fetchone()
    return dict(r)

def list_notes(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT * FROM notes WHERE profile_id=? ORDER BY created_at DESC',(profile_id,)).fetchall()
    return [dict(r) for r in rows]


def add_prediction_outcome(profile_id:int,year:int,domain:str,predicted_score:float,outcome:str,note:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    outcome=outcome if outcome in {'hit','partial','miss','unknown'} else 'unknown'
    with conn() as c:
        cur=c.execute('INSERT INTO prediction_outcomes(profile_id,year,domain,predicted_score,outcome,note,created_at) VALUES(?,?,?,?,?,?,?)',(profile_id,int(year),domain,float(predicted_score),outcome,note,now))
        r=c.execute('SELECT * FROM prediction_outcomes WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)

def list_prediction_outcomes(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c: rows=c.execute('SELECT * FROM prediction_outcomes WHERE profile_id=? ORDER BY year DESC,created_at DESC',(profile_id,)).fetchall()
    return [dict(r) for r in rows]

def outcome_stats(profile_id:Optional[int]=None)->Dict[str,Any]:
    with conn() as c:
        if profile_id is None: rows=c.execute('SELECT outcome,COUNT(*) n FROM prediction_outcomes GROUP BY outcome').fetchall()
        else: rows=c.execute('SELECT outcome,COUNT(*) n FROM prediction_outcomes WHERE profile_id=? GROUP BY outcome',(profile_id,)).fetchall()
    counts={r['outcome']:r['n'] for r in rows}; total=sum(counts.values())
    return {'total':total,'counts':counts,'hit_rate_label':('Not enough tracked outcomes' if total<5 else f"{round(100*(counts.get('hit',0)+0.5*counts.get('partial',0))/total)}% tracked-match index"),'note':'Outcome tracking is retrospective user feedback, not proof that astrology is predictive.'}

def add_followup(profile_id:int,due_date:str,kind:str,note:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        cur=c.execute('INSERT INTO followups(profile_id,due_date,kind,note,status,created_at) VALUES(?,?,?,?,?,?)',(profile_id,due_date,kind,note,'open',now))
        r=c.execute('SELECT * FROM followups WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)

def list_followups(profile_id:Optional[int]=None,status:str='open')->List[Dict[str,Any]]:
    with conn() as c:
        if profile_id is None: rows=c.execute('SELECT * FROM followups WHERE status=? ORDER BY due_date ASC',(status,)).fetchall()
        else: rows=c.execute('SELECT * FROM followups WHERE profile_id=? AND status=? ORDER BY due_date ASC',(profile_id,status)).fetchall()
    return [dict(r) for r in rows]

def close_followup(fid:int)->bool:
    with conn() as c: cur=c.execute("UPDATE followups SET status='done' WHERE id=?",(fid,))
    return cur.rowcount>0


def add_chat(profile_id:int|None,mode:str,question:str,answer:str)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        cur=c.execute('INSERT INTO chat_history(profile_id,mode,question,answer,created_at) VALUES(?,?,?,?,?)',(profile_id,mode,question,answer,now))
        r=c.execute('SELECT * FROM chat_history WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)

def list_chats(profile_id:Optional[int]=None,limit:int=100)->List[Dict[str,Any]]:
    with conn() as c:
        if profile_id is None: rows=c.execute('SELECT * FROM chat_history ORDER BY created_at DESC LIMIT ?',(int(limit),)).fetchall()
        else: rows=c.execute('SELECT * FROM chat_history WHERE profile_id=? ORDER BY created_at DESC LIMIT ?',(profile_id,int(limit))).fetchall()
    return [dict(r) for r in rows]

def add_consultation(profile_id:int,title:str,summary:str='',actions:Optional[List[str]]=None)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        cur=c.execute('INSERT INTO consultation_sessions(profile_id,title,summary,actions,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(profile_id,title,summary,json.dumps(actions or [],ensure_ascii=False),'open',now,now))
        r=c.execute('SELECT * FROM consultation_sessions WHERE id=?',(cur.lastrowid,)).fetchone()
    d=dict(r);d['actions']=json.loads(d.get('actions') or '[]');return d

def list_consultations(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c: rows=c.execute('SELECT * FROM consultation_sessions WHERE profile_id=? ORDER BY updated_at DESC',(profile_id,)).fetchall()
    out=[]
    for r in rows:
        d=dict(r);d['actions']=json.loads(d.get('actions') or '[]');out.append(d)
    return out

def add_favorite_insight(profile_id:int,category:str,title:str,content:str)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        cur=c.execute('INSERT INTO favorite_insights(profile_id,category,title,content,created_at) VALUES(?,?,?,?,?)',(profile_id,category,title,content,now))
        r=c.execute('SELECT * FROM favorite_insights WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)

def list_favorite_insights(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c: rows=c.execute('SELECT * FROM favorite_insights WHERE profile_id=? ORDER BY created_at DESC',(profile_id,)).fetchall()
    return [dict(r) for r in rows]


def add_appointment(profile_id:int|None,appointment_at:str,kind:str='consultation',fee:float=0,note:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        cur=c.execute('INSERT INTO appointments(profile_id,appointment_at,kind,fee,status,note,created_at) VALUES(?,?,?,?,?,?,?)',(profile_id,appointment_at,kind,float(fee or 0),'scheduled',note,now))
        r=c.execute('SELECT * FROM appointments WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)

def list_appointments(status:Optional[str]=None,profile_id:Optional[int]=None)->List[Dict[str,Any]]:
    q='SELECT a.*,p.name profile_name FROM appointments a LEFT JOIN profiles p ON p.id=a.profile_id'
    cond=[];args=[]
    if status: cond.append('a.status=?');args.append(status)
    if profile_id is not None: cond.append('a.profile_id=?');args.append(profile_id)
    if cond:q+=' WHERE '+' AND '.join(cond)
    q+=' ORDER BY a.appointment_at ASC'
    with conn() as c:rows=c.execute(q,args).fetchall()
    return [dict(r) for r in rows]

def update_appointment_status(appointment_id:int,status:str)->bool:
    status=status if status in {'scheduled','completed','cancelled','no_show'} else 'scheduled'
    with conn() as c:cur=c.execute('UPDATE appointments SET status=? WHERE id=?',(status,appointment_id))
    return cur.rowcount>0

def add_payment(profile_id:int|None,amount:float,mode:str='cash',reference:str='',note:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        cur=c.execute('INSERT INTO payments(profile_id,amount,mode,reference,note,created_at) VALUES(?,?,?,?,?,?)',(profile_id,float(amount),mode,reference,note,now))
        r=c.execute('SELECT * FROM payments WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)

def list_payments(profile_id:Optional[int]=None,limit:int=200)->List[Dict[str,Any]]:
    with conn() as c:
        if profile_id is None:rows=c.execute('SELECT x.*,p.name profile_name FROM payments x LEFT JOIN profiles p ON p.id=x.profile_id ORDER BY x.created_at DESC LIMIT ?',(int(limit),)).fetchall()
        else:rows=c.execute('SELECT x.*,p.name profile_name FROM payments x LEFT JOIN profiles p ON p.id=x.profile_id WHERE x.profile_id=? ORDER BY x.created_at DESC LIMIT ?',(profile_id,int(limit))).fetchall()
    return [dict(r) for r in rows]

def payment_stats()->Dict[str,Any]:
    with conn() as c:
        total=c.execute('SELECT COALESCE(SUM(amount),0) n FROM payments').fetchone()['n']
        month=c.execute("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE substr(created_at,1,7)=?",(datetime.now().strftime('%Y-%m'),)).fetchone()['n']
        cnt=c.execute('SELECT COUNT(*) n FROM payments').fetchone()['n']
    return {'total':round(float(total or 0),2),'this_month':round(float(month or 0),2),'count':cnt}

def add_team_member(name:str,role:str='Astrologer',phone:str='',email:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        cur=c.execute('INSERT INTO team_members(name,role,phone,email,status,created_at) VALUES(?,?,?,?,?,?)',(name,role,phone,email,'active',now))
        r=c.execute('SELECT * FROM team_members WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)

def list_team(status:Optional[str]=None)->List[Dict[str,Any]]:
    with conn() as c:
        if status:rows=c.execute('SELECT * FROM team_members WHERE status=? ORDER BY created_at DESC',(status,)).fetchall()
        else:rows=c.execute('SELECT * FROM team_members ORDER BY created_at DESC').fetchall()
    return [dict(r) for r in rows]
