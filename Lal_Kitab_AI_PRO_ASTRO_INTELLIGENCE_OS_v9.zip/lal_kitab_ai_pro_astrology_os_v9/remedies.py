from __future__ import annotations

"""Large, safety-filtered Lal Kitab-inspired remedy catalog.

This module deliberately separates:
1) traditional motif (planet/house symbolic association),
2) a low-risk modern action, and
3) blocked variants that should not be operationalized.

The text is paraphrased and normalized rather than copied from any single source.
"""

from typing import Dict, List, Optional

PLANETS = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu"]

PLANET_DATA: Dict[str, Dict] = {
    "Sun": {
        "hi":"सूर्य", "day":"Sunday", "themes":["authority","father/mentors","self-respect","public role"],
        "items":["wheat","jaggery","copper item","simple red/orange cloth"],
        "actions":[
            "Offer clean water toward the morning Sun from a reusable vessel, without creating litter.",
            "Show practical respect to father-figures, mentors or legitimate authority while keeping healthy boundaries.",
            "Donate wheat or another staple food within your means.",
            "Use a simple copper item as a symbolic reminder of disciplined conduct; no expensive purchase is needed.",
            "Keep the east-facing area of your room/home clean and uncluttered.",
            "Begin Sunday with one completed responsibility before leisure.",
            "Avoid ego-driven arguments and public promises you cannot keep.",
            "Help an elder with a practical task or service.",
        ],
    },
    "Moon": {
        "hi":"चंद्र", "day":"Monday", "themes":["mind","mother/caregivers","home","emotional rhythm"],
        "items":["rice","milk donation","silver-coloured item","clean water"],
        "actions":[
            "Keep sleep and waking times steady for a week as a symbolic Moon discipline.",
            "Support your mother or a caregiving elder through a practical act where appropriate.",
            "Donate rice or another white staple food to a verified community kitchen.",
            "Keep drinking-water storage clean and covered.",
            "Place a clean glass of water near the bedside only if safe, then use it for a plant the next morning.",
            "Keep a small inexpensive silver-coloured object as a symbolic reminder rather than buying jewellery.",
            "Reduce reactive communication when emotionally overloaded.",
            "Create one calm, uncluttered corner at home for reflection.",
        ],
    },
    "Mars": {
        "hi":"मंगल", "day":"Tuesday", "themes":["courage","siblings","energy","conflict","initiative"],
        "items":["red lentils","copper","red cloth","tree/plant care"],
        "actions":[
            "Channel extra energy into safe exercise, walking or constructive physical work.",
            "Donate red lentils or another protein staple to a community kitchen.",
            "Repair one broken household item instead of leaving it pending.",
            "Keep relations with siblings/cousins respectful and avoid impulsive escalation.",
            "Plant or responsibly care for a tree/plant where local rules permit.",
            "Use copper only as a low-cost symbolic object; do not ingest metals or metal-infused substances.",
            "On Tuesday, pause before sending angry messages or making confrontational decisions.",
            "Offer practical help to workers doing physically demanding tasks.",
        ],
    },
    "Mercury": {
        "hi":"बुध", "day":"Wednesday", "themes":["speech","learning","trade","records","siblings/young people"],
        "items":["green moong","stationery","books","green plant"],
        "actions":[
            "Donate whole green moong or another staple food through a verified channel.",
            "Donate notebooks, pens or school supplies to students.",
            "Keep contracts, receipts and messages clear and archived.",
            "Practice truthful, measured speech for one full day each Wednesday.",
            "Teach or mentor someone in a skill you know well.",
            "Care for a green plant rather than using wasteful symbolic disposal rituals.",
            "Review one financial or business record for errors before signing or sending.",
            "Support daughters, sisters or younger relatives with respect and without control.",
        ],
    },
    "Jupiter": {
        "hi":"गुरु", "day":"Thursday", "themes":["wisdom","teachers","ethics","children","expansion"],
        "items":["chana dal","books","yellow staple food","educational support"],
        "actions":[
            "Respect teachers and mentors; acknowledge useful guidance without blind obedience.",
            "Donate chana dal or another staple food through a trusted charity.",
            "Donate or lend useful books and educational material.",
            "Share knowledge freely for a short mentoring session.",
            "Keep one ethical commitment even when a shortcut looks easier.",
            "Support a child's education through time, materials or a verified scholarship fund within your means.",
            "Use Thursday for reviewing long-term goals and values.",
            "Avoid preaching, exaggeration and status-based moral superiority.",
        ],
    },
    "Venus": {
        "hi":"शुक्र", "day":"Friday", "themes":["relationships","comfort","art","agreements","cleanliness"],
        "items":["clean clothes","white staple food","art supplies","fragrance-free hygiene essentials"],
        "actions":[
            "Keep clothes, bedding and personal spaces clean and orderly.",
            "Donate clean clothing or hygiene essentials through a reputable organization.",
            "Practice respectful communication and consent in relationships.",
            "Avoid display-driven overspending or buying status items as a remedy.",
            "Support women/girls in family or community through practical, respectful assistance.",
            "Contribute art or craft supplies to students or a community center.",
            "Resolve one small relationship misunderstanding without manipulation.",
            "Use Friday to review subscriptions, luxury spending and unused possessions.",
        ],
    },
    "Saturn": {
        "hi":"शनि", "day":"Saturday", "themes":["discipline","workers","delay","responsibility","service"],
        "items":["black gram","sesame","mustard oil donation","blanket/work essentials"],
        "actions":[
            "Be punctual and fair with workers, service staff and people in dependent roles.",
            "Finish one delayed responsibility before starting a new one.",
            "Donate black gram, sesame or another staple item through a verified food program.",
            "Donate a blanket, footwear or work essentials when genuinely needed and seasonally appropriate.",
            "Support a reputable animal-welfare shelter instead of feeding unsafe food to stray animals.",
            "Avoid exploiting labour, delaying dues or withholding agreed payment.",
            "Use Saturday for maintenance, repairs and cleaning neglected areas.",
            "Practice consistency rather than extreme fasting or self-punishment.",
        ],
    },
    "Rahu": {
        "hi":"राहु", "day":"Saturday / source-dependent", "themes":["ambition","foreign/unusual paths","obsession","secrecy","technology"],
        "items":["coconut donation","dark blanket","digital declutter","anonymous charity"],
        "actions":[
            "Keep legal, tax, digital and financial records transparent and backed up.",
            "Reduce one compulsive digital habit or doom-scrolling window.",
            "Donate a coconut or equivalent food item through a temple/community kitchen rather than throwing it into water.",
            "Choose one anonymous act of charity without posting it publicly.",
            "Avoid intoxicant-linked, illegal or risky 'remedies' and shortcuts.",
            "Review privacy settings, passwords and suspicious subscriptions.",
            "Declutter broken electronics through certified e-waste channels.",
            "Seek facts before acting on rumours, fear or obsession.",
        ],
    },
    "Ketu": {
        "hi":"केतु", "day":"Tuesday / source-dependent", "themes":["detachment","simplification","breaks","animals","inner work"],
        "items":["blanket donation","simple cloth","animal-welfare support","decluttering"],
        "actions":[
            "Declutter one small area and donate usable items responsibly.",
            "Support a reputable dog/animal-welfare shelter rather than feeding unsafe foods.",
            "Use solitude for reflection, journaling or prayer instead of social isolation.",
            "Donate a simple blanket or useful cloth when needed.",
            "Finish or consciously close one abandoned task.",
            "Avoid superstition-driven fear, self-harm, animal harm or costly rituals.",
            "Practice a short device-free period to simplify attention.",
            "Help an elderly, disabled or isolated person through practical community support without making assumptions about them.",
        ],
    },
}

HOUSE_DATA: Dict[int, Dict] = {
    1:{"theme":"self, conduct, body routine","hi":"स्वभाव/शरीर","actions":["Keep personal routines disciplined.","Use respectful speech when asserting yourself.","Keep your entrance and personal workspace orderly.","Avoid impulsive identity or status decisions."]},
    2:{"theme":"family, speech, stored resources","hi":"परिवार/वाणी/संचित धन","actions":["Keep family financial records transparent.","Avoid insulting or deceptive speech.","Share staple food with someone in need.","Protect emergency savings from impulsive use."]},
    3:{"theme":"effort, courage, siblings, communication","hi":"पराक्रम/भाई-बहन","actions":["Complete one pending communication.","Support a sibling/peer without controlling them.","Use physical effort constructively.","Avoid gossip and unnecessary confrontations."]},
    4:{"theme":"home, mother, emotional base","hi":"घर/माता/मन","actions":["Keep the home clean and well ventilated.","Support caregivers respectfully.","Repair a household water issue promptly.","Create a calm family routine."]},
    5:{"theme":"learning, children, creativity","hi":"संतान/बुद्धि/रचना","actions":["Support education or creative learning.","Avoid gambling-like decisions framed as luck.","Mentor a younger person respectfully.","Keep promises made to children/dependents."]},
    6:{"theme":"service, competition, obligations","hi":"सेवा/प्रतिस्पर्धा/दायित्व","actions":["Pay dues and bills on time where possible.","Keep workplace boundaries fair.","Organize medicines/documents safely without changing medical treatment.","Resolve one small debt or obligation practically."]},
    7:{"theme":"partnership, spouse, trade","hi":"साझेदारी/विवाह/व्यापार","actions":["Put agreements in writing.","Practice consent and respectful negotiation.","Avoid secret parallel commitments.","Review business partnership responsibilities."]},
    8:{"theme":"change, shared resources, hidden matters","hi":"परिवर्तन/गुप्त विषय","actions":["Keep insurance and emergency documents organized.","Avoid secrecy around shared money.","Safely dispose of unusable clutter through proper channels.","Plan for contingencies without fear-based thinking."]},
    9:{"theme":"fortune, mentors, ethics, long journeys","hi":"भाग्य/गुरु/धर्म","actions":["Respect teachers while verifying claims.","Support education or a public-good cause.","Avoid religious or moral superiority.","Plan long travel responsibly and legally."]},
    10:{"theme":"career, status, duty","hi":"कर्म/करियर/प्रतिष्ठा","actions":["Finish a visible professional responsibility.","Keep work records and promises accurate.","Treat junior staff fairly.","Avoid unethical shortcuts for recognition."]},
    11:{"theme":"gains, network, fulfilment","hi":"लाभ/नेटवर्क","actions":["Help one contact without immediate expectation of return.","Audit recurring income/expense records.","Avoid exploitative networking.","Share credit for collaborative work."]},
    12:{"theme":"expense, sleep, release, distance","hi":"व्यय/नींद/त्याग","actions":["Review unnecessary expenses.","Keep a steady sleep routine.","Donate unused usable items responsibly.","Avoid escapist or compulsive habits."]},
}

CONCERN_MAP: Dict[str, Dict] = {
    "career":{"label":"Career / Job","planets":["Saturn","Sun","Mercury","Jupiter"],"houses":[10,6,11,2]},
    "business":{"label":"Business / Trade","planets":["Mercury","Saturn","Mars","Venus"],"houses":[7,10,11,3]},
    "money":{"label":"Money / Savings","planets":["Jupiter","Mercury","Venus","Saturn"],"houses":[2,11,10,9]},
    "relationship":{"label":"Relationship / Marriage","planets":["Venus","Moon","Jupiter","Mercury"],"houses":[7,2,4,11]},
    "family":{"label":"Family / Home","planets":["Moon","Sun","Jupiter","Venus"],"houses":[2,4,9]},
    "education":{"label":"Education / Learning","planets":["Mercury","Jupiter","Sun"],"houses":[3,5,9]},
    "property":{"label":"Property / Home Assets","planets":["Mars","Saturn","Moon"],"houses":[4,8,10]},
    "travel":{"label":"Travel / Foreign Exposure","planets":["Rahu","Ketu","Moon","Jupiter"],"houses":[3,9,12]},
    "stress":{"label":"Calm / Routine","planets":["Moon","Saturn","Mercury"],"houses":[4,6,12]},
    "spiritual":{"label":"Spiritual / Simplification","planets":["Jupiter","Ketu","Moon"],"houses":[9,12,5]},
}

CATEGORY_LABELS = {
    "conduct":"Conduct / Habit",
    "charity":"Charity / Service",
    "household":"Household / Order",
    "relationship":"Relationship / Respect",
    "symbolic":"Symbolic Object",
    "animal_welfare":"Animal Welfare",
    "environment":"Environment-safe Alternative",
    "learning":"Learning / Records",
}


def _cat(text: str) -> str:
    s=text.lower()
    if any(k in s for k in ["donate","charity","support a reputable","community kitchen","help an elder","help an elderly","service"]): return "charity"
    if any(k in s for k in ["animal","dog","shelter"]): return "animal_welfare"
    if any(k in s for k in ["clean","home","room","entrance","declutter","repair","water storage","workspace"]): return "household"
    if any(k in s for k in ["relationship","mother","father","sibling","mentor","teacher","caregiver","consent"]): return "relationship"
    if any(k in s for k in ["copper","silver","object","cloth","vessel"]): return "symbolic"
    if any(k in s for k in ["record","contract","receipt","learn","teach","book","stationery","privacy","password"]): return "learning"
    if any(k in s for k in ["plant","e-waste","waterway","litter","dispose"]): return "environment"
    return "conduct"


def build_catalog() -> List[Dict]:
    rows: List[Dict] = []
    rid=1
    # Planet universal remedies
    for planet,pd in PLANET_DATA.items():
        for i,action in enumerate(pd["actions"],1):
            rows.append({
                "id":f"U{rid:04d}","planet":planet,"planet_hi":pd["hi"],"house":None,
                "category":_cat(action),"concerns":[],"title":f"{planet} universal #{i}","action":action,
                "timing":pd["day"],"duration":"Optional routine; 43-day tracking available",
                "source_class":"Traditional motif — safety-normalized","safety":"low-risk","priority":2,
                "note":"Use only if chart/context supports the planet; no guaranteed outcome."
            });rid+=1
    # House universal practices
    for house,hd in HOUSE_DATA.items():
        for i,action in enumerate(hd["actions"],1):
            rows.append({
                "id":f"H{rid:04d}","planet":None,"planet_hi":"—","house":house,
                "category":_cat(action),"concerns":[],"title":f"House {house} practice #{i}","action":action,
                "timing":"Any suitable day","duration":"Repeat as a practical habit",
                "source_class":"House-theme practical layer","safety":"low-risk","priority":1,
                "note":f"House {house}: {hd['theme']}."
            });rid+=1
    # Source-aware "house awakening" reference layer, safety-normalized.
    # Traditional sources assign one planet to each sleeping-house awakening rule; the software
    # stores these as a study/reference option, not as a guaranteed prescription.
    house_awakener={1:"Mars",2:"Moon",3:"Mercury",4:"Moon",5:"Sun",6:"Rahu",7:"Venus",8:"Moon",9:"Jupiter",10:"Saturn",11:"Jupiter",12:"Ketu"}
    for house,planet in house_awakener.items():
        hd=HOUSE_DATA[house];pd=PLANET_DATA[planet]
        awaken_actions=[
            f"House {house} awakening reference: use a low-risk {planet}-linked service habit rather than a costly ritual; start with: {pd['actions'][0]}",
            f"For a sleeping House {house} study flag, strengthen the practical theme of {hd['theme']} for 43 days and track completion before judging any result.",
            f"If using the traditional {planet} association for House {house}, prefer lawful charity, cleanliness, respectful conduct or a small symbolic reminder; avoid pollution, fear-based rituals and expensive purchases.",
        ]
        for i,action in enumerate(awaken_actions,1):
            rows.append({
                "id":f"A{rid:04d}","planet":planet,"planet_hi":pd["hi"],"house":house,
                "category":_cat(action),"concerns":[],"title":f"House {house} awakening reference #{i}","action":action,
                "timing":pd["day"],"duration":"43-day tracking available",
                "source_class":"Traditional sleeping-house awakening reference — safety-normalized",
                "safety":"low-risk","priority":2,
                "note":"Source-dependent Lal Kitab study rule; whole-chart context and school profile matter."
            });rid+=1

    # General cross-chart practices frequently seen in Lal Kitab teaching, rewritten as low-risk options.
    general_actions=[
        "Keep the home and workplace free of long-unused clutter; donate or recycle usable items responsibly.",
        "Take meals in a clean designated eating area rather than making ritual rules that create distress or conflict.",
        "Seek blessings or goodwill from parents/elders where the relationship is safe; respectful boundaries still apply.",
        "Use food donation through a verified community kitchen instead of leaving unsuitable food where animals or wildlife may be harmed.",
        "Keep drinking-water areas, storage vessels and drains clean; do not use waterways as disposal sites for ritual objects.",
        "Pay workers, helpers and service providers fairly and on time.",
        "Avoid humiliating elderly, poor, disabled or dependent people; practical dignity and fairness are preferred over symbolic show.",
        "Before adding a new remedy, complete one pending responsibility connected with the affected house theme.",
        "Use a 43-day habit tracker for any selected remedy and stop if it causes harm, conflict, financial strain or unsafe behavior.",
        "Prefer modest charity within your means; never borrow money or buy luxury items solely for an astrological remedy.",
        "Do not replace medical care, legal advice, financial planning or emergency action with astrology.",
        "Keep promises realistic and written where money, business or shared responsibilities are involved.",
        "Repair broken household items or dispose of them responsibly instead of allowing long-term neglect to accumulate.",
        "Maintain one weekly act of anonymous or low-profile service without seeking public recognition.",
        "When a traditional remedy involves animals, use a reputable animal-welfare route and species-appropriate food only.",
        "When a traditional remedy involves water, use a reusable vessel or plant-watering substitute rather than throwing materials into rivers or lakes.",
        "When a traditional remedy involves fire or smoke, follow local safety rules and use a non-fire symbolic alternative if needed.",
        "When a remedy mentions a metal, keep it external and symbolic; never ingest metals, ash or unknown preparations.",
        "Use journaling to record the issue, selected remedy, practical action and observed outcome separately.",
        "Reassess a remedy after 43 days; do not keep escalating rituals because of fear or a promise of guaranteed results.",
        "Do not use astrology to accuse relatives, partners or coworkers of causing bad luck.",
        "Do not abandon lawful contracts, treatment, education or employment solely because of a symbolic score.",
        "Keep one small daily act aligned with truthfulness, cleanliness, discipline, service or respectful speech.",
        "If multiple remedies conflict, choose the lowest-risk practical action and consult the source/rule profile before combining traditions.",
    ]
    for i,action in enumerate(general_actions,1):
        rows.append({
            "id":f"G{rid:04d}","planet":None,"planet_hi":"—","house":None,
            "category":_cat(action),"concerns":[],"title":f"General Lal Kitab-safe practice #{i}","action":action,
            "timing":"Any suitable day","duration":"Use as a sustainable routine",
            "source_class":"Cross-source Lal Kitab motif — paraphrased + safety-normalized",
            "safety":"low-risk","priority":1,
            "note":"General supportive practice; not a chart-specific prescription or guaranteed cure."
        });rid+=1

    # 108 planet x house combinations, twelve safe actions per combination.
    # This makes the catalog deeply house-personalized without copying any one website/book verbatim.
    for planet,pd in PLANET_DATA.items():
        for house,hd in HOUSE_DATA.items():
            item=pd["items"][(house-1) % len(pd["items"])]
            combos = [
                pd["actions"][(house-1) % len(pd["actions"])],
                hd["actions"][(PLANETS.index(planet)) % len(hd["actions"])],
                f"For {planet} in House {house}, combine {pd['themes'][house % len(pd['themes'])]} awareness with one concrete {hd['theme']} responsibility; keep it simple and measurable.",
                f"On {pd['day']}, review House {house} ({hd['theme']}) and complete one low-cost act of service or discipline before adding any symbolic remedy.",
                f"If you want a material symbol for {planet} in House {house}, prefer a small lawful donation involving {item} or an equivalent useful item; never overspend for astrological reasons.",
                f"Run a House {house} responsibility audit: write one unresolved issue connected with {hd['theme']}, choose one practical next action, and finish it before repeating a ritual remedy.",
                f"For the {planet}–House {house} combination, improve one relationship linked to {pd['themes'][(house+1) % len(pd['themes'])]} through respectful communication, clear boundaries and a concrete helpful act.",
                f"Use an environment-safe Lal Kitab alternative for {planet} in House {house}: do not dump ritual objects into water or public spaces; donate, reuse, recycle or dispose of symbolic items responsibly.",
                f"For {planet} in House {house}, keep a 43-day observation log: record the selected action, one real-world responsibility tied to {hd['theme']}, and whether the habit improved clarity or conduct.",
                f"Create a low-cost daan/seva option for {planet} in House {house}: give a useful staple, school/work essential or verified charitable contribution within your means, then avoid attaching a guaranteed outcome to it.",
                f"Use a household-order option for {planet} in House {house}: clean, repair or organize one area symbolically linked with {hd['theme']} and keep it maintained rather than repeating wasteful disposal rituals.",
                f"Use a speech-and-relationship option for {planet} in House {house}: avoid one recurring harmful communication pattern and replace it with a specific respectful behavior for the tracking period.",
            ]
            concerns=[k for k,v in CONCERN_MAP.items() if planet in v["planets"] or house in v["houses"]]
            for i,action in enumerate(combos,1):
                rows.append({
                    "id":f"PH{rid:04d}","planet":planet,"planet_hi":pd["hi"],"house":house,
                    "category":_cat(action),"concerns":concerns,"title":f"{planet} in House {house} — option {i}",
                    "action":action,"timing":pd["day"],"duration":"Traditionally tracked consistently; software supports 43 days",
                    "source_class":"108-combination Lal Kitab-inspired, paraphrased + safety-normalized","safety":"low-risk","priority":3,
                    "note":"Selection must consider whole-chart context; this is not an automatic prescription."
                });rid+=1
    # Concern-focused cross-planet options.
    for concern,cfg in CONCERN_MAP.items():
        for planet in cfg["planets"]:
            pd=PLANET_DATA[planet]
            for j in range(2):
                action=pd["actions"][(j+len(concern)) % len(pd["actions"])]
                rows.append({
                    "id":f"C{rid:04d}","planet":planet,"planet_hi":pd["hi"],"house":None,
                    "category":_cat(action),"concerns":[concern],"title":f"{cfg['label']} — {planet} option {j+1}",
                    "action":action,"timing":pd["day"],"duration":"Use as a supportive routine, not a substitute for practical action",
                    "source_class":"Concern index / traditional theme mapping","safety":"low-risk","priority":2,
                    "note":"The concern-to-planet mapping is interpretive and should be checked against the chart."
                });rid+=1
    return rows



def build_ultra_extensions(start_no: int=1) -> List[Dict]:
    """Additional low-risk indexed options for PRO ULTRA.

    These are normalized practice variants, not claims that every line is a verbatim
    classical remedy. They make the vault more useful for filtering and planning while
    keeping source-dependent traditional rules distinct from modern safe substitutions.
    """
    rows: List[Dict] = []
    rid=start_no
    # Six extra context variants for every graha x house pair (648 records).
    for planet,pd in PLANET_DATA.items():
        pi=PLANETS.index(planet)
        for house,hd in HOUSE_DATA.items():
            item=pd["items"][(house+pi) % len(pd["items"])]
            extra=[
                f"{planet} in House {house}: choose one truth-and-conduct correction connected with {hd['theme']}; write the exact behaviour to stop and the replacement behaviour to follow for 43 days.",
                f"{planet} in House {house}: choose one seva action linked with {pd['themes'][pi % len(pd['themes'])]} and House {house}; keep the cost modest and record completion rather than expecting a guaranteed result.",
                f"{planet} in House {house}: if using a symbolic item, use a small lawful {item} or equivalent useful donation; do not bury, burn, ingest or dump objects into public land or water.",
                f"{planet} in House {house}: use a family/relationship correction only where safe — reduce one repeated disrespectful pattern linked with {hd['theme']} and replace it with a specific boundary or helpful act.",
                f"{planet} in House {house}: add a records-and-accountability remedy — review one document, payment, promise, maintenance task or communication tied to {hd['theme']} and close the oldest pending item.",
                f"{planet} in House {house}: run a minimalist 3-part protocol on {pd['day']}: one practical duty, one modest service act and one short reflection note; do not stack multiple rituals at once.",
            ]
            concerns=[k for k,v in CONCERN_MAP.items() if planet in v['planets'] or house in v['houses']]
            for i,action in enumerate(extra,1):
                rows.append({
                    'id':f'X{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':house,
                    'category':_cat(action),'concerns':concerns,'title':f'{planet} in House {house} — ULTRA option {i}',
                    'action':action,'timing':pd['day'],'duration':'Use one selected protocol for 43 days, then review',
                    'source_class':'PRO ULTRA context variant — Lal Kitab-inspired + safety-normalized','safety':'low-risk','priority':3,
                    'note':'Use as one option within a whole-chart plan; do not combine many remedies simply to increase intensity.',
                    'remedy_group':'context_protocol','intensity':'gentle'
                });rid+=1
    # Four additional safe sleeping-house review options (48 records).
    house_awakener={1:'Mars',2:'Moon',3:'Mercury',4:'Moon',5:'Sun',6:'Rahu',7:'Venus',8:'Moon',9:'Jupiter',10:'Saturn',11:'Jupiter',12:'Ketu'}
    for house,planet in house_awakener.items():
        pd=PLANET_DATA[planet];hd=HOUSE_DATA[house]
        acts=[
            f"Sleeping-house review H{house}: first verify that the house is truly unoccupied and receives no relevant source-defined drishti before using the {planet} awakening reference.",
            f"H{house} / {planet} awakening reference: select the lowest-risk {planet} conduct or charity practice and pair it with one real-world responsibility related to {hd['theme']}.",
            f"H{house} review: track the practical house theme for 43 days before adding a second symbolic practice; improvement in routine is the observation target, not proof of astrology.",
            f"H{house} review: if the traditional version would create pollution, animal risk, fire risk or financial strain, replace it with service, donation, cleaning, repair or respectful conduct linked with {planet}.",
        ]
        for i,action in enumerate(acts,1):
            rows.append({'id':f'SA{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':house,
                         'category':_cat(action),'concerns':[],'title':f'House {house} awakening review — ULTRA {i}',
                         'action':action,'timing':pd['day'],'duration':'43-day review cycle',
                         'source_class':'Sleeping-house source-aware review — safety-normalized','safety':'low-risk','priority':3,
                         'note':'A sleeping-house label is source/rule dependent and should not be auto-diagnosed from emptiness alone.',
                         'remedy_group':'house_awakening','intensity':'gentle'});rid+=1
    # Four planet-specific protocol cards per planet (36 records).
    for planet,pd in PLANET_DATA.items():
        acts=[
            f"{planet} protocol: choose only one of the indexed {planet} actions as the core remedy and one practical responsibility as support; avoid remedy stacking.",
            f"{planet} protocol: use {pd['day']} as a weekly review point for conduct, spending, promises and service connected with {', '.join(pd['themes'][:2])}.",
            f"{planet} protocol: if charity is selected, set a sustainable budget cap first and never borrow or make a large purchase for astrological reasons.",
            f"{planet} protocol: stop and reassess any practice that creates fear, family conflict, unsafe behaviour, medical delay, legal risk or financial strain.",
        ]
        for i,action in enumerate(acts,1):
            rows.append({'id':f'PP{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':None,
                         'category':_cat(action),'concerns':[],'title':f'{planet} PRO protocol #{i}','action':action,
                         'timing':pd['day'],'duration':'Weekly review / 43-day observation','source_class':'PRO remedy planning protocol',
                         'safety':'low-risk','priority':2,'note':'Planning layer; not a classical verbatim prescription.',
                         'remedy_group':'planet_protocol','intensity':'gentle'});rid+=1
    return rows

def build_v6_extensions(start_no: int=1) -> List[Dict]:
    """420 additional V6 safe planning/index records.

    These extend search and protocol design without pretending to be 420 newly
    discovered classical prescriptions. Each record is explicitly labelled as a
    V6 safe planning or verification protocol.
    """
    rows: List[Dict] = []
    rid = start_no
    # 3 per graha x house = 324
    for planet, pd in PLANET_DATA.items():
        for house, hd in HOUSE_DATA.items():
            concerns=[k for k,v in CONCERN_MAP.items() if planet in v['planets'] or house in v['houses']]
            acts=[
                f"{planet} H{house} verification protocol: before starting an upay, write one observable issue linked with {hd['theme']}, one practical action, and one 43-day review measure; do not use coincidence as proof.",
                f"{planet} H{house} low-cost protocol: select one existing safe {planet} remedy plus one real-world responsibility related to {hd['theme']}; set a zero-debt budget and avoid gemstones or expensive purchases unless independently desired.",
                f"{planet} H{house} de-escalation protocol: if several remedies are suggested, keep only the single most relevant conduct/service action for 14 days, then decide whether a 43-day continuation is useful.",
            ]
            for i,action in enumerate(acts,1):
                rows.append({
                    'id':f'V6{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':house,
                    'category':_cat(action),'concerns':concerns,'title':f'{planet} in House {house} — V6 protocol {i}',
                    'action':action,'timing':pd['day'],'duration':'14-day check then up to 43-day review',
                    'source_class':'V6 software planning protocol — not a classical verbatim remedy','safety':'low-risk','priority':2,
                    'note':'Designed to reduce remedy stacking and keep practical verification visible.',
                    'remedy_group':'v6_verification','intensity':'gentle'
                }); rid += 1
    # 8 per house = 96; total 420
    for house, hd in HOUSE_DATA.items():
        house_acts=[
            f"House {house} practical reset: clear one overdue task directly connected with {hd['theme']} before adding a symbolic remedy.",
            f"House {house} record check: document one promise, payment, maintenance item or boundary connected with {hd['theme']} and close the oldest unresolved item.",
            f"House {house} service option: choose one modest act of help relevant to {hd['theme']} without publicising it or expecting a guaranteed return.",
            f"House {house} environment option: clean, repair or responsibly declutter one physical area associated with {hd['theme']} instead of dumping ritual materials outdoors.",
            f"House {house} communication option: replace one repeated reactive sentence or behaviour linked with {hd['theme']} with a specific respectful alternative for 43 days.",
            f"House {house} budget option: if a donation/remedy involves money, set a sustainable cap first and never borrow for it.",
            f"House {house} review option: track what changed in routine, communication or responsibility after 14 and 43 days; record no-change honestly.",
            f"House {house} stop-rule: discontinue any practice tied to {hd['theme']} that causes fear, conflict, pollution, animal risk, medical delay, legal risk or financial strain.",
        ]
        for i,action in enumerate(house_acts,1):
            rows.append({
                'id':f'VH{rid:05d}','planet':None,'planet_hi':'','house':house,
                'category':_cat(action),'concerns':[k for k,v in CONCERN_MAP.items() if house in v['houses']],
                'title':f'House {house} V6 safe protocol {i}','action':action,'timing':'Any suitable day',
                'duration':'14/43-day practical review','source_class':'V6 house-level safe planning protocol','safety':'low-risk','priority':1,
                'note':'Software planning layer; not a claim of classical Lal Kitab authorship.',
                'remedy_group':'v6_house_protocol','intensity':'gentle'
            }); rid += 1
    return rows

CATALOG = build_catalog()
CATALOG.extend(build_ultra_extensions(len(CATALOG)+1))
CATALOG.extend(build_v6_extensions(len(CATALOG)+1))
CATALOG_BY_ID = {x["id"]:x for x in CATALOG}

# Unsafe or environmentally harmful variants are catalogued only as blocked categories,
# without operational instructions that could encourage harm.
BLOCKED_VARIANTS = [
    {"type":"water pollution","rule":"Do not throw coins, plastics, oils, chemicals, cloth or food waste into rivers/lakes.","alternative":"Donate the item or use a clean symbolic water offering at home and dispose responsibly."},
    {"type":"animal harm","rule":"Do not feed animals chocolate, sweets, excessive salt/spices or species-inappropriate foods.","alternative":"Support a reputable animal-welfare group or use veterinarian-approved feed."},
    {"type":"fire/smoke hazard","rule":"Do not create unsafe indoor smoke, unattended flames or hazardous burning rituals.","alternative":"Use a safe lamp only where permitted, or replace it with a non-fire symbolic routine."},
    {"type":"ingestion risk","rule":"Do not ingest metals, ash, unknown herbs, chemicals, oils or ritual mixtures as an astrological remedy.","alternative":"Keep symbolic objects external; medical treatment belongs with qualified clinicians."},
    {"type":"medical replacement","rule":"No remedy may replace prescribed medicines, emergency care, therapy or medical evaluation.","alternative":"Use cultural practices only as optional personal rituals alongside appropriate care."},
    {"type":"financial exploitation","rule":"No remedy requires expensive gemstones, large payments, loans, secret fees or guaranteed-return purchases.","alternative":"Prefer low-cost service, discipline and charity within your means."},
    {"type":"self-harm / deprivation","rule":"No extreme fasting, sleep deprivation, self-punishment or deliberate exposure to unsafe conditions.","alternative":"Use ordinary, sustainable habits."},
    {"type":"illegal activity","rule":"No trespass, dumping, wildlife interference, theft, bribery or other unlawful conduct as a remedy.","alternative":"Choose a lawful symbolic or charitable substitute."},
]


def catalog_meta() -> Dict:
    return {
        "total":len(CATALOG),
        "planet_house_combinations":108,
        "planets":PLANETS,
        "houses":list(range(1,13)),
        "categories":CATEGORY_LABELS,
        "concerns":{k:v["label"] for k,v in CONCERN_MAP.items()},
        "blocked_safety_variants":BLOCKED_VARIANTS,
        "method_note":"V6 catalog spanning universal, house, sleeping-house reference, concern, protocol, verification and all 108 planet×house combinations. Entries are paraphrased/safety-normalized; the software does not claim every worldwide oral or published remedy is captured.",
        "planner":"V6 priority engine selects a small protocol, adds verification/stop rules, and avoids remedy stacking.",
        "source_boundary":"Traditional source rules, safe modern substitutions and software planning protocols are labelled separately."
    }


def search_catalog(q: str="", planet: Optional[str]=None, house: Optional[int]=None,
                   category: Optional[str]=None, concern: Optional[str]=None,
                   limit: int=250) -> List[Dict]:
    q=(q or "").strip().lower();out=[]
    for r in CATALOG:
        if planet and r.get("planet") != planet: continue
        if house and r.get("house") != house: continue
        if category and r.get("category") != category: continue
        if concern and concern not in r.get("concerns",[]): continue
        if q:
            blob=" ".join(str(r.get(k,"")) for k in ["planet","planet_hi","house","category","title","action","note","source_class"]).lower()
            if q not in blob: continue
        out.append(r)
        if len(out)>=max(1,min(limit,2000)): break
    return out


def recommended_for_chart(chart: Dict, concern: Optional[str]=None, limit: int=18) -> List[Dict]:
    placements=chart.get("placements",[])
    scored=[]
    for p in placements:
        base=100-int(p.get("score",50))
        if "Neecha reference" in p.get("status",[]): base+=35
        if "Soya candidate" in p.get("status",[]): base+=20
        for r in CATALOG:
            if r.get("planet") != p.get("planet") or r.get("house") != p.get("house"): continue
            if concern and concern not in r.get("concerns",[]): continue
            scored.append((base+r.get("priority",1),r))
    # Deduplicate by action, preserve strongest chart relevance
    seen=set();out=[]
    for _,r in sorted(scored,key=lambda x:x[0],reverse=True):
        if r["action"] in seen: continue
        seen.add(r["action"]);out.append(r)
        if len(out)>=limit: break
    return out



def remedy_priority_plan(chart: Dict, concern: Optional[str]=None, primary_limit: int=3) -> Dict:
    """Build a small, diverse remedy protocol with conflict/overload warnings."""
    placements=chart.get('placements',[]) or []
    house_states={h.get('house'):h for h in chart.get('house_states',[]) or []}
    active_house=(chart.get('timing',{}).get('house_cycle_36',{}) or {}).get('house')
    candidates=[]
    for p in placements:
        weakness=max(0,70-float(p.get('score',50)))
        if 'Neecha reference' in (p.get('status') or []): weakness+=24
        if 'Soya candidate' in (p.get('status') or []): weakness+=16
        if active_house==p.get('house'): weakness+=8
        hs=house_states.get(p.get('house'),{})
        if 'sleep' in str(hs.get('state','')).lower() or 'soya' in str(hs.get('state','')).lower(): weakness+=7
        for r in CATALOG:
            if r.get('planet')!=p.get('planet'): continue
            if r.get('house') not in (None,p.get('house')): continue
            if concern and concern not in r.get('concerns',[]) and r.get('concerns'): continue
            relevance=weakness + 4*float(r.get('priority',1))
            if r.get('house')==p.get('house'): relevance+=12
            if concern and concern in r.get('concerns',[]): relevance+=14
            if r.get('remedy_group')=='context_protocol': relevance+=3
            candidates.append((relevance,r,p))
    candidates.sort(key=lambda x:x[0],reverse=True)

    def materialize(score,r,p):
        row=dict(r);row['relevance_score']=round(min(100,score),1)
        row['why_selected']=f"{p.get('planet')} H{p.get('house')} chart score {p.get('score',50)}/100" + ("; active 36-year house" if active_house==p.get('house') else '')
        return row

    # Core plan: one planet per core remedy and category diversity where possible.
    primary=[];seen_actions=set();used_planets=set();used_categories=set()
    for score,r,p in candidates:
        if r['action'] in seen_actions or r.get('planet') in used_planets: continue
        if r.get('category') in used_categories and len(used_categories)>=2: continue
        primary.append(materialize(score,r,p));seen_actions.add(r['action']);used_planets.add(r.get('planet'));used_categories.add(r.get('category'))
        if len(primary)>=primary_limit: break
    # If the chart has too few unique candidates after concern filtering, relax category but not action.
    if len(primary)<primary_limit:
        for score,r,p in candidates:
            if r['action'] in seen_actions or r.get('planet') in used_planets: continue
            primary.append(materialize(score,r,p));seen_actions.add(r['action']);used_planets.add(r.get('planet'))
            if len(primary)>=primary_limit: break

    secondary=[];planet_count={x.get('planet'):1 for x in primary};category_count={x.get('category'):1 for x in primary}
    for score,r,p in candidates:
        if r['action'] in seen_actions: continue
        if planet_count.get(r.get('planet'),0)>=2: continue
        if category_count.get(r.get('category'),0)>=3: continue
        secondary.append(materialize(score,r,p));seen_actions.add(r['action'])
        planet_count[r.get('planet')]=planet_count.get(r.get('planet'),0)+1;category_count[r.get('category')]=category_count.get(r.get('category'),0)+1
        if len(secondary)>=5: break

    conflicts=[]
    for i,a in enumerate(primary):
        for b in primary[i+1:]:
            if a.get('planet')==b.get('planet'):
                conflicts.append({'level':'review','pair':[a['id'],b['id']], 'reason':'Two core remedies target the same planet; use one core action first unless a source-aware astrologer intentionally combines them.'})
            elif a.get('category')==b.get('category'):
                conflicts.append({'level':'review','pair':[a['id'],b['id']], 'reason':f"Both are {a.get('category')} actions; simplify if the protocol becomes burdensome."})
    rules=[
        'Use at most 1–3 core remedies at a time; more remedies are not automatically stronger.',
        'Prefer conduct, responsibility, service and low-cost charity before symbolic material actions.',
        'Do not combine traditions when their source rules conflict; keep the selected Lal Kitab rule profile visible.',
        'Stop or replace any practice that creates pollution, animal risk, fire risk, health risk, legal risk or financial strain.',
        'Review after 43 days and record observable habit/practical changes; do not treat coincidence as proof of causation.'
    ]
    return {'primary':primary,'secondary':secondary,'conflicts':conflicts,'protocol_rules':rules,
            'concern':concern,'catalog_total':len(CATALOG),
            'note':'Priority is a software relevance ranking, not proof that a remedy changes external events.'}
