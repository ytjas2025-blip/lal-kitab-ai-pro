# Lal Kitab AI PRO — ASTRO INTELLIGENCE OS v9

A local-first, mobile-style Lal Kitab + Vedic auxiliary astrology workstation with a black/gold professional kundli interface, explainable prediction/remedy engines, advanced research labs, AI consultation tools and practice CRM.

## V9 dashboard / UI

- Screenshot-inspired black + gold mobile astrology interface.
- North Indian Lagna Kundli and slide-out professional navigation drawer.
- **Command Center v9** with prediction balance, evidence coverage, consensus, remedy status and an Intelligence Strip.
- Sacred Lal Kitab ornamental chart based on the user-provided visual reference; calculations remain engine-driven.
- Mobile/desktop responsive layout.

## Charts and calculation workspaces

- D1 Lagna / Rashi.
- D9 Navamsha.
- Moon Chart.
- Bhav Chalit auxiliary.
- D10 Dasamsa.
- D12 Dwadasamsa.
- Lal Kitab fixed-house Teva.
- Live sidereal Transit chart.
- **Full 16-Varga Lab**: D1, D2, D3, D4, D7, D9, D10, D12, D16, D20, D24, D27, D30, D40, D45 and D60.
- Panchang: Vara, Tithi, Nakshatra/Pada, Yoga and Karana.
- Vimshottari Dasha.
- **Yogini Dasha**.
- Raj Yoga candidate lab.
- Bhav Madhya, Friendship, Karakamsha, Swamsa, KP cusp and Avakhada workspaces.
- Ashtakavarga remains a source-audited workspace rather than fabricating bindu totals.

## V9 advanced intelligence

- **Shad Bala Research Lab** with visible Sthana, Dig, Kala, Cheshta, Naisargika and Drik software indexes.
- **Muhurta AI Planner**: rank up to 60 days for general, business, job, property, travel, education, relationship or launch planning.
- **Animated Transit Wheel** and date slider.
- **Why-this-Prediction Rule Graph** connecting planets → houses → prediction domains → remedy review.
- 12-month forecast focus.
- Life Timeline age 1–90.
- Turning-point detector.
- Scenario Lab.
- Year-vs-year comparison.
- Prediction consensus / contradiction analysis.
- Birth-time sensitivity and known-event rectification assistant.

## Lal Kitab prediction and remedies

- 16 explainable life-domain indexes.
- 11 event-theme windows.
- 2,700 indexed safety-normalized remedy records.
- Full 108 graha × house remedy matrix.
- Smart Top-3 remedy protocol.
- Remedy duplication / stacking / conflict review.
- 43-day remedy tracker.
- Pakka Ghar teaching profiles.
- Uchcha / Neecha reference labels.
- Soya / Jagta review, Masnui scan, Rin workspace and special Teva candidates.
- Separate 35-year planetary planner and 36-year house cycle.

## AI OS — 12 modes

1. Chart Explainer
2. Second Opinion
3. Skeptic / contradiction finder
4. Consultation Copilot
5. Remedy Safety Review
6. Timeline Narrator
7. Report Writer
8. Why-this-Prediction evidence trace
9. Muhurta Copilot
10. Research Copilot
11. Compatibility Analyst
12. Business Planning Lens

The app works without an API key using built-in explainable fallbacks. Optional cloud AI activates only when both `OPENAI_API_KEY` and `OPENAI_MODEL` are configured.

## Voice consultation

- Browser microphone input using Web Speech API when supported.
- Hindi/English/Hinglish transcription depends on browser/device speech services.
- Optional browser text-to-speech for AI answers.
- Typed AI consultation remains available when voice is unsupported.

## Practice Command Center

- Client CRM.
- Appointments with status tracking.
- Payment / fee ledger (cash, UPI, card, bank labels).
- Team roster.
- Consultation sessions and notes.
- Follow-up center.
- Prediction Hit / Partial / Miss history.
- AI history and favourite insights.
- WhatsApp-ready client summary generator.

The practice console is local-first. It is **not** a production payment gateway or hardened multi-tenant authentication system.

## Reports

- Premium PDF report.
- Planetary Passport.
- Lal Kitab states / Rin / Masnui / special Teva.
- 16-domain predictions and event themes.
- Smart remedy protocol.
- Consensus / contradictions.
- Vedic auxiliary summary.
- V9 Varga/Yogini/Shadbala-research summary.
- Turning-point preview and timing reference.

## Run on Windows

1. Install Python 3.11+.
2. Extract the ZIP.
3. Double-click `run_windows.bat`.
4. Open `http://127.0.0.1:8000` if it does not open automatically.

## Run on macOS / Linux

```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```

Then open `http://127.0.0.1:8000`.

## Optional cloud AI

```bash
export OPENAI_API_KEY="..."
export OPENAI_MODEL="your-enabled-model"
```

## Important method boundary

Astrology is a traditional belief system. V9 keeps astronomical calculation, Lal Kitab rules, Vedic auxiliary formulas, software research indexes and AI narrative visibly separate. Higher Varga conventions and some classical systems differ across lineages/software. The Shad Bala Research Lab is **not** presented as the classical virupa/rupa total, and Ashtakavarga bindu totals remain disabled until an auditable rule-table pack is selected.

Do not use this software as a substitute for medical, legal, financial, relationship-safety or other professional advice.

See `CHANGELOG_V9.md`, `RULE_SOURCE_NOTES.md` and `REMEDY_VAULT_NOTES.md`.
