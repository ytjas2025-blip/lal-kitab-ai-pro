"""Offline smoke test for Lal Kitab AI PRO — ASTRO INTELLIGENCE OS v9."""
from pathlib import Path
import tempfile

from app import BirthInput, _chart_from_model, health
from remedies import catalog_meta, remedy_priority_plan
from prediction_pro import event_windows_for_year
from intelligence_v6 import compatibility_report, family_matrix, prediction_consensus, rule_audit, rectification_assistant
from intelligence_v7 import command_center, scenario_compare, year_compare, consultation_brief
from astro_v8 import vedic_auxiliary, transit_snapshot, monthly_focus, life_timeline, turning_point_summary, ai_feature_catalog
from astro_v9 import shodashavarga_full, yogini_dasha, shadbala_research, muhurta_finder, transit_series, rule_graph, whatsapp_summary
import db

b1=BirthInput(name="Smoke Test A",birth_date="1990-05-12",birth_time="10:30",city="Delhi",timezone_offset=5.5,rule_profile="1940-foundation")
b2=BirthInput(name="Smoke Test B",birth_date="1992-08-14",birth_time="07:35",city="Ludhiana",timezone_offset=5.5,rule_profile="1940-foundation")
c1=_chart_from_model(b1); c2=_chart_from_model(b2)
assert health()["version"] == "9.0.0"
assert len(c1["placements"]) == 9
assert catalog_meta()["total"] == 2700
assert len(c1["predictions"]) == 16
assert len(c1["pro_predictions"]["forecast"]) == 12
assert len(c1["event_windows"]["events"]) == 11
assert len(c1["remedy_plan"]["primary"]) == 3
assert len({x.get("planet") for x in c1["remedy_plan"]["primary"]}) == 3
assert all("confidence" in x for x in c1["predictions"])
assert event_windows_for_year(c1, 2027)["year"] == 2027
assert remedy_priority_plan(c1)["catalog_total"] == 2700

# V8/V9 kundli and auxiliary suite
va=c1["vedic_aux"]
assert va["lagna"]["sign_no"] in range(1,13)
for k in ["lagna","navamsha","moon","chalit","dasamsa","dwadasamsa"]:
    assert len(va["charts"][k]) == 12
assert va["panchang"]["nakshatra"]["name"]
assert len(va["vimshottari"]["mahadasha"]) >= 5
assert len(va["bhav_madhya"]) == 12
assert va["raj_yoga_candidates"]
assert len(ai_feature_catalog()) == 12
assert len(transit_snapshot(c1)["placements"]) == 9
assert len(monthly_focus(c1,2027)["months"]) == 12
lt=life_timeline(c1,1,90); assert len(lt["rows"]) == 90
assert turning_point_summary(c1,10)["years"]

# V9 advanced engines
vargas=shodashavarga_full(c1)
assert len(vargas["calculated"]) == 16
assert len(vargas["charts"]) == 16
assert all(len(v["houses"]) == 12 for v in vargas["charts"].values())
yog=yogini_dasha(c1,3); assert yog["periods"] and yog["starting_yogini"]
shad=shadbala_research(c1); assert len(shad["rows"]) == 9 and all(len(x["components"]) == 6 for x in shad["rows"])
mu=muhurta_finder(c1,"2026-09-10","2026-09-24","business",8); assert len(mu["ranked"]) == 8
trs=transit_series(c1,"2026-09-10",7); assert len(trs["series"]) == 7 and len(trs["series"][0]["planets"]) == 9
rg=rule_graph(c1,2027); assert rg["nodes"] and rg["edges"]
ws=whatsapp_summary(c1,2027); assert "Lal Kitab AI" in ws["text"]
assert c1["astro_v9"]["vargas"]["calculated"] and c1["astro_v9"]["yogini"]

comp=compatibility_report(c1,c2,"business"); assert 0 <= comp["overall_index"] <= 100 and len(comp["dimensions"]) >= 5
fam=family_matrix([c1,c2]); assert fam["pair_count"] == 1
cons=prediction_consensus(c1,2027); assert cons["year"] == 2027 and len(cons["all"]) == 16
aud=rule_audit(c1,2027); assert len(aud["calculated_layer"]["placements"]) == 9
rect=rectification_assistant(b1.model_dump(),30,10,[{"year":2022,"domain":"career","direction":"support","note":"known work change"}]); assert rect["candidate_count"] >= 5 and rect["top_candidates"]
cmd=command_center(c1,2026); assert cmd["kpis"]["consensus_index"] >= 0 and len(cmd["scenario_spotlight"]) >= 5
sc=scenario_compare(c1,2026); assert len(sc["scenarios"]) >= 9 and sc["scenarios"][0]["index"] >= sc["scenarios"][-1]["index"]
yc=year_compare(c1,2026,2027); assert len(yc["all"]) == 16
brief=consultation_brief(c1,2026); assert brief["consultation_questions"]

# CRM additions on isolated temp DB.
with tempfile.TemporaryDirectory() as td:
    db.DB_PATH=Path(td)/"test.db"; db.init_db()
    saved=db.save_profile(b1.model_dump(),c1); pid=saved["id"]
    db.add_prediction_outcome(pid,2026,"career",65,"partial","verified test")
    assert db.outcome_stats(pid)["total"] == 1
    fu=db.add_followup(pid,"2026-09-22","remedy review","test")
    assert len(db.list_followups(pid)) == 1
    assert db.close_followup(fu["id"])
    db.add_chat(pid,"explainer","test question","test answer")
    assert len(db.list_chats(pid)) == 1
    db.add_consultation(pid,"Test consultation","summary",["follow-up"])
    assert len(db.list_consultations(pid)) == 1
    db.add_favorite_insight(pid,"prediction","Test insight","content")
    assert len(db.list_favorite_insights(pid)) == 1
    ap=db.add_appointment(pid,"2026-09-15T17:00","consultation",1500,"test")
    assert len(db.list_appointments(profile_id=pid)) == 1 and db.update_appointment_status(ap["id"],"completed")
    db.add_payment(pid,1500,"upi","TEST","consultation")
    assert db.payment_stats()["total"] == 1500
    db.add_team_member("Astrologer A","Astrologer","9999999999","")
    assert len(db.list_team("active")) == 1

print("PASS - V9: 9 grahas, 2,700 remedies, 16 domains, 16 Varga workspaces, Yogini Dasha, six-component Shadbala research, Muhurta AI, transit series/wheel data, rule graph, 12 AI modes, voice-ready UI, practice CRM, compatibility, rectification and outcome tracking.")
