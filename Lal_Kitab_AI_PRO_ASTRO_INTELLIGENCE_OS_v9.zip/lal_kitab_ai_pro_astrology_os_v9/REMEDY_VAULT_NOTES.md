# Remedy Vault Notes — V6

## Count
The V6 vault contains **2,700 indexed records**.

## What the count means
The count includes multiple clearly labelled classes:
- universal planet-linked low-risk actions,
- house-linked actions,
- all 108 planet × house combinations,
- concern indexes,
- sleeping-house review protocols,
- conduct/service/charity/environment-safe variants,
- PRO/ULTRA context protocols,
- **420 V6 verification and de-escalation protocols**.

The V6 software protocols are not presented as classical verbatim Lal Kitab prescriptions. Their purpose is to make consultation planning safer, cheaper, more measurable and less prone to remedy stacking.

## Smart Remedy Protocol
The planner:
- scores chart relevance,
- prefers a small Top-3 core protocol,
- diversifies planets/categories where possible,
- provides backups,
- flags duplicate-category overload,
- recommends a 14-day check followed by a 43-day review where appropriate.

## Safety filter
The software blocks operational guidance involving:
- water/land pollution,
- animal harm or unsafe feeding,
- unsafe fire/smoke,
- ingestion of metals/ash/unknown substances,
- replacing medical treatment,
- expensive/borrowed-money astrological purchases,
- self-harm or extreme deprivation,
- illegal activity.

Where a traditional motif could create harm, a lawful low-risk substitute such as service, donation, cleaning, repair, record-keeping or respectful conduct is preferred.

## Scope honesty
No software can honestly guarantee it contains every remedy from every Lal Kitab edition, translation, oral tradition and modern practitioner worldwide. V6 therefore prioritizes a large structured vault with source-class labels and safety normalization rather than claiming impossible completeness.
