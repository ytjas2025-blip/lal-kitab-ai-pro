from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import swisseph as swe
from remedies import PLANET_DATA, catalog_meta, recommended_for_chart

PLANETS = {
    "Sun": swe.SUN, "Moon": swe.MOON, "Mars": swe.MARS, "Mercury": swe.MERCURY,
    "Jupiter": swe.JUPITER, "Venus": swe.VENUS, "Saturn": swe.SATURN, "Rahu": swe.TRUE_NODE,
}
PLANET_ORDER = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu"]
PLANET_HI = {"Sun":"सूर्य","Moon":"चंद्र","Mars":"मंगल","Mercury":"बुध","Jupiter":"गुरु","Venus":"शुक्र","Saturn":"शनि","Rahu":"राहु","Ketu":"केतु"}
SIGNS = [
    ("Aries","मेष"),("Taurus","वृषभ"),("Gemini","मिथुन"),("Cancer","कर्क"),
    ("Leo","सिंह"),("Virgo","कन्या"),("Libra","तुला"),("Scorpio","वृश्चिक"),
    ("Sagittarius","धनु"),("Capricorn","मकर"),("Aquarius","कुंभ"),("Pisces","मीन")
]
HOUSE_MEANINGS = {
    1:("Self, vitality & identity","स्वभाव, शरीर, पहचान"),2:("Family, speech & stored wealth","परिवार, वाणी, संचित धन"),
    3:("Courage, effort & siblings","पराक्रम, प्रयास, भाई-बहन"),4:("Home, mother & emotional base","घर, माता, मन की शांति"),
    5:("Children, intellect & creativity","संतान, बुद्धि, रचनात्मकता"),6:("Service, competition & obligations","सेवा, प्रतिस्पर्धा, ऋण/दायित्व"),
    7:("Partnership, spouse & trade","विवाह, साझेदारी, व्यापार"),8:("Change, longevity & hidden matters","परिवर्तन, आयु, गुप्त विषय"),
    9:("Fortune, mentors & principles","भाग्य, गुरु, धर्म/सिद्धांत"),10:("Career, status & duty","कर्म, करियर, प्रतिष्ठा"),
    11:("Gains, network & fulfilment","लाभ, मित्र, इच्छापूर्ति"),12:("Expense, sleep & release","व्यय, नींद, त्याग/मुक्ति"),
}
PLANET_THEMES = {
    "Sun":("authority, confidence, father figures","आत्मविश्वास, अधिकार, पिता/वरिष्ठ"),
    "Moon":("mind, habits, mother, emotional rhythm","मन, आदतें, माता, भावनात्मक लय"),
    "Mars":("drive, courage, conflict, initiative","ऊर्जा, साहस, संघर्ष, पहल"),
    "Mercury":("speech, learning, analysis, trade","वाणी, सीखना, विश्लेषण, व्यापार"),
    "Jupiter":("wisdom, guidance, expansion, ethics","ज्ञान, मार्गदर्शन, विस्तार, नैतिकता"),
    "Venus":("comfort, relationships, taste, agreements","सुख, संबंध, सौंदर्य, समझौते"),
    "Saturn":("discipline, delay, work, responsibility","अनुशासन, विलंब, मेहनत, जिम्मेदारी"),
    "Rahu":("ambition, unconventional paths, obsession","महत्त्वाकांक्षा, असामान्य रास्ते, तीव्र इच्छा"),
    "Ketu":("detachment, introspection, breaks, simplification","वैराग्य, आत्मचिंतन, कटाव, सरलता"),
}

RULE_PROFILES = {
    "1940-foundation": {
        "label":"1940 foundation-style Pakka Ghar profile",
        "pakka": {"Sun":{1},"Moon":{4},"Mars":{3,8},"Mercury":{7},"Jupiter":{2,5,9,11},"Venus":{7},"Saturn":{8,10},"Rahu":{12},"Ketu":{6}},
        "note":"Source-aware profile; later schools may expand some assignments."
    },
    "common-extended": {
        "label":"Common extended teaching profile",
        "pakka": {"Sun":{1},"Moon":{4},"Mars":{3,8},"Mercury":{6,7},"Jupiter":{2,5,9,12},"Venus":{7},"Saturn":{8,10,11},"Rahu":{12},"Ketu":{6}},
        "note":"Useful comparison profile. Differences are kept visible rather than silently merged."
    }
}

UCHCHA = {"Sun":{1},"Moon":{2},"Mars":{10},"Mercury":{6},"Jupiter":{4},"Venus":{12},"Saturn":{7},"Rahu":{3,6},"Ketu":{9,12}}
NEECHA = {"Sun":{7},"Moon":{8},"Mars":{4},"Mercury":{12},"Jupiter":{10},"Venus":{6},"Saturn":{1},"Rahu":{9,12},"Ketu":{3,6}}

RELATIONSHIPS = {
    "Jupiter":{"friends":{"Sun","Moon","Mars"},"enemies":{"Venus","Mercury"},"equals":{"Saturn","Rahu","Ketu"}},
    "Sun":{"friends":{"Jupiter","Moon","Mars"},"enemies":{"Venus","Saturn","Rahu"},"equals":{"Mercury","Ketu"}},
    "Moon":{"friends":{"Sun","Mercury","Rahu"},"enemies":{"Ketu"},"equals":{"Saturn","Venus","Mars","Jupiter"}},
    "Venus":{"friends":{"Saturn","Mercury","Ketu"},"enemies":{"Sun","Moon","Rahu"},"equals":{"Mars","Jupiter"}},
    "Mars":{"friends":{"Sun","Moon","Jupiter"},"enemies":{"Mercury","Ketu"},"equals":{"Saturn","Venus","Rahu"}},
    "Mercury":{"friends":{"Sun","Venus","Rahu"},"enemies":{"Moon"},"equals":{"Saturn","Ketu","Mars","Jupiter"}},
    "Saturn":{"friends":{"Mercury","Venus","Rahu"},"enemies":{"Moon","Sun","Mars"},"equals":{"Ketu","Jupiter"}},
    "Rahu":{"friends":{"Mercury","Saturn","Ketu"},"enemies":{"Venus","Sun","Mars"},"equals":{"Jupiter","Moon"}},
    "Ketu":{"friends":{"Venus","Rahu"},"enemies":{"Moon","Mars"},"equals":{"Jupiter","Saturn","Mercury","Sun"}},
}

MASNUI = [
    (("Sun","Venus"),"Jupiter","Sun + Venus → Jupiter reference"),
    (("Mercury","Venus"),"Sun","Mercury + Venus → Sun reference"),
    (("Sun","Jupiter"),"Moon","Sun + Jupiter → Moon reference"),
    (("Rahu","Ketu"),"Venus","Rahu + Ketu → Venus reference"),
    (("Sun","Mercury"),"Mars Nek","Sun + Mercury → Mars Nek reference"),
    (("Sun","Saturn"),"Mars Bad / Rahu Neecha","Sun + Saturn → Mars Bad / Rahu Neecha reference"),
    (("Jupiter","Rahu"),"Mercury","Jupiter + Rahu → Mercury reference"),
    (("Jupiter","Venus"),"Saturn-like Ketu","Jupiter + Venus → Saturn-like Ketu reference"),
    (("Mars","Mercury"),"Saturn-like Rahu/Manda","Mars + Mercury → Saturn-like Rahu/Manda reference"),
    (("Mars","Saturn"),"Rahu Uchcha","Mars + Saturn → Rahu Uchcha reference"),
    (("Venus","Saturn"),"Ketu Uchcha","Venus + Saturn → Ketu Uchcha reference"),
    (("Moon","Saturn"),"Ketu Neecha","Moon + Saturn → Ketu Neecha reference"),
]

SAFE_REMEDIES = {
    "Sun":["Maintain a disciplined morning routine and get safe morning sunlight.","Show respect to father-figures, mentors and legitimate authority.","Offer a simple Sunday donation within your means."],
    "Moon":["Keep sleep, hydration and emotional routines steady.","Support and respect the maternal side where appropriate.","Donate a simple food staple if practical."],
    "Mars":["Channel excess energy into exercise or constructive physical work.","Avoid impulsive arguments and risky action when angry.","Offer practical help to siblings or workers."],
    "Mercury":["Keep promises, records and financial communication clear.","Practice truthful, measured speech and regular learning.","Donate stationery or books to students."],
    "Jupiter":["Respect teachers, elders and ethical commitments.","Share knowledge without expecting return.","Support education or donate staple food if convenient."],
    "Venus":["Keep relationships respectful and avoid display-driven overspending.","Maintain cleanliness in clothes and personal spaces.","Offer practical support to women/girls in family or community."],
    "Saturn":["Be punctual, consistent and fair with workers and service staff.","Finish delayed responsibilities instead of avoiding them.","Donate practical essentials to someone in need."],
    "Rahu":["Avoid shortcuts, secrecy and compulsive habits under pressure.","Keep digital, financial and legal records transparent.","Choose a simple anonymous act of service."],
    "Ketu":["Declutter regularly and reduce unnecessary commitments.","Use solitude for reflection rather than isolation.","Support reputable animal-welfare work if you wish."],
}



ASPECT_RULES = {
    "Sun":[7],"Moon":[7],"Mercury":[7],"Venus":[7],
    "Mars":[4,7,8],"Jupiter":[5,7,9],"Saturn":[3,7,10],
    "Rahu":[5,7,9],"Ketu":[5,7,9],
}
AXIS_PAIRS = {(1,7),(2,8),(3,9),(4,10),(5,11),(6,12)}

AREA_RULES = {
    "career":{"label":"Career & Status","houses":[10,6,11,2],"planets":["Saturn","Sun","Mercury","Jupiter"]},
    "business":{"label":"Business & Trade","houses":[7,10,11,3],"planets":["Mercury","Saturn","Mars","Venus"]},
    "money":{"label":"Money & Resource Management","houses":[2,11,10,9],"planets":["Jupiter","Mercury","Venus","Saturn"]},
    "relationship":{"label":"Relationship & Partnership","houses":[7,2,4,11],"planets":["Venus","Moon","Jupiter","Mercury"]},
    "family":{"label":"Family & Home","houses":[2,4,9],"planets":["Moon","Sun","Jupiter","Venus"]},
    "education":{"label":"Learning & Creativity","houses":[3,5,9],"planets":["Mercury","Jupiter","Sun"]},
    "property":{"label":"Property & Home Assets","houses":[4,8,10],"planets":["Mars","Saturn","Moon"]},
    "travel":{"label":"Travel & Foreign Exposure","houses":[3,9,12],"planets":["Rahu","Ketu","Moon","Jupiter"]},
    "wellbeing":{"label":"Routine & Wellbeing","houses":[1,4,6,12],"planets":["Moon","Saturn","Sun"]},
    "spiritual":{"label":"Spirituality & Simplification","houses":[9,12,5],"planets":["Jupiter","Ketu","Moon"]},
}

CITY_PRESETS = {
    "Delhi":{"lat":28.6139,"lon":77.2090,"tz":5.5},"Mumbai":{"lat":19.0760,"lon":72.8777,"tz":5.5},
    "Ludhiana":{"lat":30.9010,"lon":75.8573,"tz":5.5},"Srinagar":{"lat":34.0837,"lon":74.7973,"tz":5.5},
    "Jaipur":{"lat":26.9124,"lon":75.7873,"tz":5.5},"Kolkata":{"lat":22.5726,"lon":88.3639,"tz":5.5},
    "Bengaluru":{"lat":12.9716,"lon":77.5946,"tz":5.5},"Chennai":{"lat":13.0827,"lon":80.2707,"tz":5.5},
    "Dubai":{"lat":25.2048,"lon":55.2708,"tz":4.0},"London":{"lat":51.5072,"lon":-0.1276,"tz":0.0},
    "New York":{"lat":40.7128,"lon":-74.0060,"tz":-5.0},"Sydney":{"lat":-33.8688,"lon":151.2093,"tz":10.0},
}

HOUSE_AWAKENERS = {1:"Mars",2:"Moon",3:"Mercury",4:"Moon",5:"Sun",6:"Rahu",7:"Venus",8:"Moon",9:"Jupiter",10:"Saturn",11:"Jupiter",12:"Ketu"}

HOUSE_CYCLE_36 = [
    (1,3,1),(4,6,2),(7,9,3),(10,12,10),(13,15,11),(16,18,12),
    (19,21,4),(22,24,5),(25,27,6),(28,30,7),(31,33,8),(34,36,9)
]
PLANET_CYCLE_35 = [("Jupiter",6),("Sun",2),("Moon",1),("Venus",3),("Mars",6),("Mercury",2),("Saturn",6),("Rahu",6),("Ketu",3)]

RIN_CATALOG = [
    ("Pitri Rin","पितृ ऋण"),("Matri Rin","मातृ ऋण"),("Stri Rin","स्त्री ऋण"),("Santan Rin","संतान ऋण"),
    ("Karz / Financial Rin","कर्ज ऋण"),("Relative Rin","संबंधी ऋण"),("Self-created Rin","स्व-निर्मित ऋण"),
    ("Divine / Dharma Rin","धर्म ऋण"),("General family-line Rin","कुल/परिवार ऋण"),
]


def calc_planets(name:str,birth_date:str,birth_time:str,timezone_offset:float=5.5)->Dict:
    try:
        local_dt = datetime.fromisoformat(f"{birth_date}T{birth_time}")
    except Exception as exc:
        raise ValueError("Invalid birth date/time") from exc
    utc_dt = local_dt - timedelta(hours=timezone_offset)
    hour = utc_dt.hour + utc_dt.minute/60 + utc_dt.second/3600
    jd = swe.julday(utc_dt.year,utc_dt.month,utc_dt.day,hour,swe.GREG_CAL)
    swe.set_sid_mode(swe.SIDM_LAHIRI,0,0)
    flags = swe.FLG_SIDEREAL | swe.FLG_MOSEPH | swe.FLG_SPEED
    placements=[]
    for pname, code in PLANETS.items():
        vals,_=swe.calc_ut(jd,code,flags)
        lon=float(vals[0] % 360); speed=float(vals[3]); house=int(lon//30)+1; sidx=house-1
        placements.append({"planet":pname,"planet_hi":PLANET_HI[pname],"longitude":round(lon,4),"degree_in_sign":round(lon%30,2),"sign":SIGNS[sidx][0],"sign_hi":SIGNS[sidx][1],"house":house,"retrograde":speed<0})
    rahu=next(p for p in placements if p["planet"]=="Rahu")
    klon=(rahu["longitude"]+180)%360; kh=int(klon//30)+1; ks=kh-1
    placements.append({"planet":"Ketu","planet_hi":PLANET_HI["Ketu"],"longitude":round(klon,4),"degree_in_sign":round(klon%30,2),"sign":SIGNS[ks][0],"sign_hi":SIGNS[ks][1],"house":kh,"retrograde":rahu["retrograde"]})
    placements.sort(key=lambda p:PLANET_ORDER.index(p["planet"]))
    return {"julian_day":jd,"utc_datetime":utc_dt.isoformat(timespec="minutes"),"local_datetime":local_dt.isoformat(timespec="minutes"),"ayanamsa":round(float(swe.get_ayanamsa_ut(jd)),6),"placements":placements}


def mutual_enemy(a:str,b:str)->bool:
    return b in RELATIONSHIPS.get(a,{}).get("enemies",set()) and a in RELATIONSHIPS.get(b,{}).get("enemies",set())


def build_house_map(placements:List[Dict])->Dict[int,List[str]]:
    m={i:[] for i in range(1,13)}
    for p in placements:m[p["house"]].append(p["planet"])
    return m


def planet_states(placements:List[Dict], pakka:Dict[str,set])->List[Dict]:
    hm=build_house_map(placements); first_any=any(hm[h] for h in range(1,7)); later_any=any(hm[h] for h in range(7,13))
    out=[]
    for p in placements:
        h=p["house"]; reasons=[]; state="Awake / Jagta"
        if h in pakka.get(p["planet"],set()):
            reasons.append("Pakka Ghar exception: treated as awake in this rule profile")
        else:
            sleeping=False
            if h<=6 and not hm[h+6]: sleeping=True; reasons.append(f"Facing house {h+6} is empty — conservative Soya candidate")
            if not first_any and h>=7: sleeping=True; reasons.append("Houses 1–6 are empty — later-side Soya candidate")
            if not later_any and h<=6: sleeping=True; reasons.append("Houses 7–12 are empty — earlier-side review candidate")
            if h==2 and not hm[10]: sleeping=True; reasons.append("House 10 empty — special House 2 sleeping rule candidate")
            if h in {9,10} and not hm[2]: sleeping=True; reasons.append("House 2 empty — special House 9/10 sleeping rule candidate")
            if sleeping: state="Soya candidate / manual review"
        out.append({"planet":p["planet"],"house":h,"state":state,"reasons":reasons or ["No conservative sleeping trigger detected"]})
    return out


def house_states(placements:List[Dict])->List[Dict]:
    hm=build_house_map(placements); out=[]
    for h in range(1,13):
        if hm[h]: state="Awake by occupancy"; note=f"Occupied by {', '.join(hm[h])}"
        else: state="Drishti review"; note="Empty house: full edition-specific aspect review needed before calling it sleeping"
        out.append({"house":h,"state":state,"planets":hm[h],"awakener_reference":HOUSE_AWAKENERS[h],"note":note})
    return out


def special_teva(placements:List[Dict])->List[Dict]:
    hm=build_house_map(placements); ph={p["planet"]:p["house"] for p in placements}; hits=[]
    if ph.get("Sun")==4 and ph.get("Saturn")==7:
        hits.append({"label":"Aadha-Andha / Nauhorata","status":"Detected","evidence":"Sun in House 4 + Saturn in House 7","note":"Technical source label only; not a statement about intelligence, disability or destiny."})
    h10=hm[10]
    pairs=[]
    for i in range(len(h10)):
        for j in range(i+1,len(h10)):
            if mutual_enemy(h10[i],h10[j]): pairs.append((h10[i],h10[j]))
    if pairs:
        hits.append({"label":"Andha Teva candidate","status":"Detected","evidence":"Mutual-enemy pair(s) in House 10: "+", ".join(f"{a}+{b}" for a,b in pairs),"note":"Strict technical candidate; final reading remains source- and context-dependent."})
    moon_house=ph.get("Moon")
    limb1=(ph.get("Rahu")==4 or ph.get("Ketu")==4 or ph.get("Rahu")==moon_house or ph.get("Ketu")==moon_house)
    limb2=(ph.get("Saturn")==11 or ph.get("Saturn")==ph.get("Jupiter"))
    if limb1 and limb2:
        hits.append({"label":"Dharmi Teva candidate","status":"Detected","evidence":"Node/Moon limb + Saturn/Jupiter limb both present","note":"Technical label; use as a study flag, not a guarantee of outcomes."})
    allowed={"Saturn","Rahu","Ketu"}
    nabalig=True; evidence=[]
    for h in [1,4,7,10]:
        ps=set(hm[h])
        ok=(not ps) or ps.issubset(allowed) or ps=={"Mercury"}
        evidence.append(f"H{h}: {', '.join(ps) if ps else 'empty'}")
        if not ok:nabalig=False
    if nabalig:
        hits.append({"label":"Nabalig Teva candidate","status":"Detected","evidence":"; ".join(evidence),"note":"Technical chart classification; requires careful edition-specific interpretation."})
    if not hits:
        hits.append({"label":"No special Teva trigger","status":"Clear","evidence":"No conservative automatic condition detected","note":"This does not rule out other edition-specific labels."})
    return hits


def masnui_scan(placements:List[Dict])->List[Dict]:
    hm=build_house_map(placements); out=[]
    for h, planets in hm.items():
        s=set(planets)
        for pair,target,note in MASNUI:
            if set(pair).issubset(s):out.append({"house":h,"pair":" + ".join(pair),"reference":target,"note":note})
    return out or [{"house":None,"pair":"None detected","reference":"—","note":"Only listed source-pair combinations are auto-detected."}]


def house_summary(placements:List[Dict])->List[Dict]:
    hm=build_house_map(placements); out=[]
    for h in range(1,13):
        en,hi=HOUSE_MEANINGS[h]
        out.append({"house":h,"meaning":en,"meaning_hi":hi,"planets":hm[h],"note":"Occupied" if hm[h] else "Unoccupied"})
    return out


def relationship_scan(placements:List[Dict])->List[Dict]:
    hm=build_house_map(placements); out=[]
    for h, planets in hm.items():
        if len(planets)<2:continue
        for i in range(len(planets)):
            for j in range(i+1,len(planets)):
                a,b=planets[i],planets[j]
                if mutual_enemy(a,b): label="Mutual enemy"
                elif b in RELATIONSHIPS[a]["friends"] and a in RELATIONSHIPS[b]["friends"]: label="Mutual friend"
                else: label="Mixed / directional"
                out.append({"house":h,"pair":f"{a} + {b}","relationship":label})
    return out


def rin_scan(placements:List[Dict])->List[Dict]:
    # Deliberately conservative: names are catalogued, but automatic diagnosis is avoided where exact edition rules are not encoded.
    ph={p["planet"]:p["house"] for p in placements}; rows=[]
    for name,hi in RIN_CATALOG:
        evidence=[]
        if name.startswith("Pitri") and (ph.get("Saturn")==9 or ph.get("Rahu") in {5,9} or ph.get("Ketu") in {5,9}): evidence.append("ancestry/fortune-axis indicator")
        if name.startswith("Matri") and (ph.get("Rahu")==4 or ph.get("Ketu")==4): evidence.append("node activates House 4")
        if name.startswith("Stri") and ph.get("Venus") in {2,7}: evidence.append("Venus activates family/partnership axis")
        if name.startswith("Santan") and (ph.get("Jupiter")==5 or ph.get("Ketu")==5 or ph.get("Rahu")==5): evidence.append("House 5 indicator")
        rows.append({"name":name,"name_hi":hi,"status":"Review" if evidence else "No auto-trigger","evidence":", ".join(evidence) if evidence else "Full source-specific Rin test not auto-asserted","guidance":"Treat Rin as a traditional symbolic label, not literal legal/financial debt or proof of wrongdoing."})
    return rows


def dignity_and_scores(placements:List[Dict], pakka:Dict[str,set])->List[Dict]:
    states={x["planet"]:x for x in planet_states(placements,pakka)}
    out=[]
    for p in placements:
        h=p["house"]; status=[]; score=50
        if h in pakka.get(p["planet"],set()):status.append("Pakka Ghar");score+=20
        if h in UCHCHA.get(p["planet"],set()):status.append("Uchcha reference");score+=18
        if h in NEECHA.get(p["planet"],set()):status.append("Neecha reference");score-=18
        if states[p["planet"]]["state"].startswith("Soya"):status.append("Soya candidate");score-=10
        score=max(0,min(100,score))
        eng_theme,hi_theme=PLANET_THEMES[p["planet"]]; eng_house,hi_house=HOUSE_MEANINGS[h]
        p2=dict(p);p2.update({"status":status or ["Standard placement"],"score":score,"state":states[p["planet"]]["state"],"state_reasons":states[p["planet"]]["reasons"],"reading":f"{p['planet']} activates {eng_house.lower()} through themes of {eng_theme}.","reading_hi":f"{PLANET_HI[p['planet']]} {hi_house} के क्षेत्र में {hi_theme} के विषयों को सक्रिय करता है।","remedies":PLANET_DATA[p["planet"]]["actions"][:4]})
        out.append(p2)
    return out


def current_age(birth_date:str,on_date:Optional[datetime]=None)->int:
    d=datetime.fromisoformat(birth_date); now=on_date or datetime.now(); return now.year-d.year-((now.month,now.day)<(d.month,d.day))


def house_cycle_for_age(age:int)->Dict:
    pos=((max(age,1)-1)%36)+1
    for a,b,h in HOUSE_CYCLE_36:
        if a<=pos<=b:return {"age":age,"cycle_position":pos,"house":h,"meaning":HOUSE_MEANINGS[h][0]}
    return {"age":age,"cycle_position":pos,"house":1,"meaning":HOUSE_MEANINGS[1][0]}


def house_cycle_timeline(start_age:int=1,end_age:int=108)->List[Dict]:
    return [house_cycle_for_age(a) for a in range(start_age,end_age+1)]


def planet_cycle_from_anchor(anchor_planet:str,anchor_age:int,start_age:int=1,end_age:int=108)->List[Dict]:
    order=[p for p,_ in PLANET_CYCLE_35]; durations=dict(PLANET_CYCLE_35)
    if anchor_planet not in order:anchor_planet="Jupiter"
    idx=order.index(anchor_planet); seq=[]
    # build intervals forward and backward around anchor; anchor_age is first age of anchor period
    age=anchor_age
    for _ in range(40):
        planet=order[idx%len(order)]; dur=durations[planet]
        seq.append((age,age+dur-1,planet)); age+=dur; idx+=1
        if age>end_age+35:break
    idx=order.index(anchor_planet)-1; age=anchor_age-1
    back=[]
    for _ in range(40):
        planet=order[idx%len(order)]; dur=durations[planet]; start=age-dur+1
        back.append((start,age,planet)); age=start-1; idx-=1
        if age<start_age-35:break
    intervals=list(reversed(back))+seq
    out=[]
    for a in range(start_age,end_age+1):
        planet=next((p for s,e,p in intervals if s<=a<=e),None)
        if planet:out.append({"age":a,"planet":planet})
    return out


def aspect_scan(placements:List[Dict])->List[Dict]:
    hm=build_house_map(placements);out=[]
    for p in placements:
        h=p["house"]
        for count in ASPECT_RULES.get(p["planet"],[7]):
            target=((h-1)+(count-1))%12+1
            targets=hm[target]
            out.append({"planet":p["planet"],"from_house":h,"aspect_count":count,"target_house":target,"target_planets":targets,"occupied":bool(targets),"note":f"{p['planet']} {count}th-house drishti reference to H{target}"})
    return out


def virtual_axis_scan(placements:List[Dict])->List[Dict]:
    hm=build_house_map(placements);out=[]
    for a,b in sorted(AXIS_PAIRS):
        if hm[a] and hm[b]:
            out.append({"axis":f"{a}-{b}","house_a":a,"house_b":b,"planets_a":hm[a],"planets_b":hm[b],"note":"Complementary-axis interaction / virtual conjunction study flag."})
    return out


def annual_rotation_from_natal(placements:List[Dict],birth_date:str,year:int,pakka:Dict[str,set])->Dict:
    dob=datetime.fromisoformat(birth_date)
    # completed age on birthday in target year; minimum 0 for birth year
    age=max(0,year-dob.year)
    rotated=[]
    for p in placements:
        x={k:v for k,v in p.items() if k not in {"status","score","state","state_reasons","reading","reading_hi","remedies"}}
        x["natal_house"]=p["house"]
        x["house"]=((p["house"]-1)+age)%12+1
        # signs are intentionally not relabelled: this is a house-rotation study method, not new sky positions
        x["sign"]="Annual house rotation";x["sign_hi"]="वार्षिक भाव घुमाव";x["degree_in_sign"]="—";x["retrograde"]=False
        rotated.append(x)
    scored=dignity_and_scores(rotated,pakka)
    return {"year":year,"age_index":age,"method":"Age-based annual house rotation (school-specific Varshphal study profile)","placements":scored,"note":"This is kept separate from astronomical birthday positions because Lal Kitab annual methods differ across teaching lines."}


def prediction_matrix(placements:List[Dict], house_cycle:Optional[Dict]=None, annual_rotation:Optional[Dict]=None)->List[Dict]:
    aspects=aspect_scan(placements);rels=relationship_scan(placements);results=[]
    annual_by={p["planet"]:p for p in (annual_rotation or {}).get("placements",[])}
    for key,cfg in AREA_RULES.items():
        score=50.0;evidence=[];support=[];caution=[]
        for p in placements:
            relevance=(2 if p["planet"] in cfg["planets"] else 0)+(2 if p["house"] in cfg["houses"] else 0)
            if relevance:
                delta=(p.get("score",50)-50)*0.12*relevance
                score+=delta
                ev=f"{p['planet']} H{p['house']} ({p.get('score',50)}/100)"
                evidence.append(ev)
                (support if delta>=0 else caution).append(ev)
            ap=annual_by.get(p["planet"])
            if ap and ap.get("house") in cfg["houses"]:
                ad=(ap.get("score",50)-50)*0.06
                score+=ad;evidence.append(f"Annual {p['planet']}→H{ap['house']}")
        for a in aspects:
            if a["target_house"] in cfg["houses"] and a["occupied"]:
                src=next((p for p in placements if p["planet"]==a["planet"]),None)
                if src:
                    delta=(src.get("score",50)-50)*0.035
                    score+=delta;evidence.append(f"{a['planet']} drishti H{a['target_house']}")
        for r in rels:
            if r["house"] in cfg["houses"]:
                if r["relationship"]=="Mutual friend": score+=4;support.append(f"Friendly conjunction H{r['house']}: {r['pair']}")
                elif r["relationship"]=="Mutual enemy": score-=5;caution.append(f"Tension conjunction H{r['house']}: {r['pair']}")
        if house_cycle and house_cycle.get("house") in cfg["houses"]:
            score+=4;evidence.append(f"Current house-cycle emphasis H{house_cycle['house']}")
        score=int(round(max(0,min(100,score))))
        if score>=68:band="Supportive emphasis"
        elif score<=38:band="Higher-friction emphasis"
        else:band="Mixed / balanced emphasis"
        results.append({
            "key":key,"label":cfg["label"],"score":score,"band":band,"houses":cfg["houses"],"planets":cfg["planets"],
            "evidence":evidence[:8],"support":support[:4],"caution":caution[:4],
            "guidance":("Use this as a prioritization lens. Build practical plans, verify with lived facts, and avoid treating the score as a guaranteed event probability." if key not in {"money","wellbeing"} else
                        "This is a symbolic planning lens only; it is not financial advice or a medical assessment. Use qualified professionals for high-stakes decisions.")
        })
    return results


def prediction_summary(matrix:List[Dict])->Dict:
    ordered=sorted(matrix,key=lambda x:x["score"],reverse=True)
    return {"strongest":ordered[:3],"watch":sorted(matrix,key=lambda x:x["score"])[:3],"method":"Evidence-weighted software score using placement condition, relevant houses/planets, Lal Kitab drishti, same-house relations, current house-cycle and annual rotation when available.","certainty":"Interpretive score, not statistical probability."}


def annual_snapshot(name:str,birth_date:str,birth_time:str,timezone_offset:float,year:int,rule_profile:str)->Dict:
    dob=datetime.fromisoformat(birth_date); day=min(dob.day,28) if dob.month==2 else dob.day
    calc=calc_planets(name,f"{year:04d}-{dob.month:02d}-{day:02d}",birth_time,timezone_offset)
    pakka=RULE_PROFILES.get(rule_profile,RULE_PROFILES["1940-foundation"])["pakka"]
    pl=dignity_and_scores(calc["placements"],pakka)
    return {"year":year,"label":"Experimental birthday-date sidereal comparison layer","placements":pl,"note":"Not presented as canonical Lal Kitab Varshphal; use it as a separate comparison layer."}


def chart_payload(data:Dict)->Dict:
    rule_profile=data.get("rule_profile") or "1940-foundation"; rp=RULE_PROFILES.get(rule_profile,RULE_PROFILES["1940-foundation"]); pakka=rp["pakka"]
    calc=calc_planets(data.get("name","Unnamed"),data["birth_date"],data["birth_time"],float(data.get("timezone_offset",5.5)))
    placements=dignity_and_scores(calc["placements"],pakka)
    city=data.get("city","Delhi"); preset=CITY_PRESETS.get(city,{})
    age=current_age(data["birth_date"])
    house_cycle=house_cycle_for_age(max(age,1))
    current_year=datetime.now().year
    annual_rot=annual_rotation_from_natal(placements,data["birth_date"],current_year,pakka)
    predictions=prediction_matrix(placements,house_cycle,annual_rot)
    remedy_shell={"placements":placements}
    return {
        "profile":{"name":data.get("name","Unnamed"),"birth_date":data["birth_date"],"birth_time":data["birth_time"],"city":city,"timezone_offset":float(data.get("timezone_offset",5.5)),"latitude":data.get("latitude",preset.get("lat")),"longitude":data.get("longitude",preset.get("lon")),"rule_profile":rule_profile,"rule_profile_label":rp["label"],"notes":data.get("notes","")},
        "engine":{"ephemeris":"Swiss Ephemeris / Moshier calculations","zodiac":"Sidereal","ayanamsa":"Lahiri","ayanamsa_degrees":calc["ayanamsa"],"framework":"Fixed 12-house Lal Kitab reference layer","rule_note":rp["note"]},
        "placements":placements,"houses":house_summary(placements),"house_states":house_states(placements),"relationships":relationship_scan(placements),"aspects":aspect_scan(placements),"virtual_axes":virtual_axis_scan(placements),"masnui":masnui_scan(placements),"special_teva":special_teva(placements),"rin":rin_scan(placements),
        "predictions":predictions,"prediction_summary":prediction_summary(predictions),
        "remedy_recommendations":recommended_for_chart(remedy_shell,limit=18),"remedy_catalog":catalog_meta(),
        "timing":{"age":age,"house_cycle_36":house_cycle,"planet_cycle_35_note":"Requires a traceable anchor planet + starting age; no universal birth-start planet is auto-assumed."},
        "annual":annual_snapshot(data.get("name","Unnamed"),data["birth_date"],data["birth_time"],float(data.get("timezone_offset",5.5)),current_year,rule_profile),
        "annual_rotation":annual_rot,
        "generated_at":datetime.now().isoformat(timespec="seconds"),
        "disclaimer":"Astrology is a traditional belief system. Use this software for cultural, spiritual and entertainment guidance, not as a substitute for medical, legal, financial or safety-critical advice. Technical labels are not deterministic predictions."
    }
