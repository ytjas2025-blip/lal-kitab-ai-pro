from __future__ import annotations

import base64, io, json, os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Optional, List

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

import db
from engine import (
    CITY_PRESETS, RULE_PROFILES, SAFE_REMEDIES, HOUSE_MEANINGS, RELATIONSHIPS, MASNUI,
    PLANET_CYCLE_35, HOUSE_CYCLE_36, chart_payload, annual_snapshot,
    house_cycle_timeline, planet_cycle_from_anchor, annual_rotation_from_natal
)
from remedies import catalog_meta, search_catalog, recommended_for_chart, remedy_priority_plan, vashist_source_recommended, sumitacharya_source_recommended, CATALOG_BY_ID
from prediction_pro import enrich_chart, forecast_year as pro_forecast_year, forecast_range as pro_forecast_range, event_windows_for_year, decision_dashboard
from intelligence_v6 import compatibility_report, family_matrix, prediction_consensus, rule_audit, rectification_assistant
from intelligence_v7 import command_center, scenario_compare, year_compare, consultation_brief
from astro_v8 import vedic_auxiliary, transit_snapshot, monthly_focus, life_timeline, turning_point_summary, ai_feature_catalog
from astro_v9 import shodashavarga_full, yogini_dasha, shadbala_research, muhurta_finder, transit_series, rule_graph, whatsapp_summary, v9_feature_catalog
from prediction_v10 import vimshottari_full, full_prediction_studio
from vashist_v11 import source_library, luck_meter, luck_chain, category_prediction_pack, problem_detector, vashist_dashboard
from sumitacharya_v12 import source_library as sumit_source_library, dosha_research_scanner, baby_name_lab, business_vastu_checklist, marriage_single_chart_panel, deep_prediction_studio as sumit_deep_prediction_studio, report_108_outline, sumitacharya_dashboard
from critical_alerts_v19 import critical_alert_center
from visual_intelligence_v19 import visual_intelligence
from intelligence_v19_2 import v19_2_dashboard
from enterprise_v18 import enterprise_dashboard, living_digital_twin, forecast_horizons, event_radar, astro_council, source_conflict_viewer, prediction_change_explainer, report_center_catalog
from professional_report_v18_1 import build_professional_pdf

BASE_DIR=Path(__file__).resolve().parent
STATIC_DIR=BASE_DIR/'static'
db.init_db()

app=FastAPI(title='Lal Kitab AI PRO ENTERPRISE INTELLIGENCE OS',version='18.1.0')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])

class BirthInput(BaseModel):
    name:str=Field(min_length=1,max_length=100)
    birth_date:str
    birth_time:str
    city:str='Delhi'
    timezone_offset:float=5.5
    latitude:Optional[float]=None
    longitude:Optional[float]=None
    rule_profile:str='1940-foundation'
    notes:str=''

class ChatInput(BaseModel):
    question:str=Field(min_length=1,max_length=1600)
    chart:Dict
    language:str='Hinglish'

class PdfInput(BaseModel):
    chart:Dict

class AnnualInput(BirthInput):
    year:int

class TimelineInput(BaseModel):
    start_age:int=1
    end_age:int=108
    anchor_planet:str='Jupiter'
    anchor_age:int=1

class RemedyInput(BaseModel):
    profile_id:int
    planet:str
    remedy:str
    duration:int=43
    start_date:str

class CheckinInput(BaseModel):
    day_no:int
    date:str
    note:str=''
    completed:bool=True

class NoteInput(BaseModel):
    profile_id:int
    note:str=Field(min_length=1,max_length=4000)

class ForecastRangeInput(BaseModel):
    chart:Dict
    start_year:int
    end_year:int

class EventYearInput(BaseModel):
    chart:Dict
    year:int

class BirthSensitivityInput(BirthInput):
    window_minutes:int=30
    step_minutes:int=5

class CompatibilityInput(BaseModel):
    chart_a:Dict
    chart_b:Dict
    mode:str='relationship'

class FamilyMatrixInput(BaseModel):
    charts:List[Dict]

class ConsensusInput(BaseModel):
    chart:Dict
    year:int

class AuditInput(BaseModel):
    chart:Dict
    year:Optional[int]=None

class RectificationInput(BirthInput):
    window_minutes:int=60
    step_minutes:int=5
    events:List[Dict]

class ScenarioInput(BaseModel):
    chart:Dict
    year:Optional[int]=None
    scenarios:Optional[List[str]]=None

class YearCompareInput(BaseModel):
    chart:Dict
    year_a:int
    year_b:int

class ConsultationBriefInput(BaseModel):
    chart:Dict
    year:Optional[int]=None

class PredictionOutcomeInput(BaseModel):
    profile_id:int
    year:int
    domain:str
    predicted_score:float
    outcome:str
    note:str=''

class FollowupInput(BaseModel):
    profile_id:int
    due_date:str
    kind:str='review'
    note:str=''

class MonthlyFocusInput(BaseModel):
    chart:Dict
    year:int

class LifeTimelineInput(BaseModel):
    chart:Dict
    start_age:int=1
    end_age:int=90

class TransitInput(BaseModel):
    chart:Dict
    when:Optional[str]=None

class AICopilotInput(BaseModel):
    chart:Dict
    mode:str='explainer'
    question:str=''
    language:str='Hinglish'
    profile_id:Optional[int]=None

class ConsultationSessionInput(BaseModel):
    profile_id:int
    title:str='Consultation'
    summary:str=''
    actions:List[str]=[]

class FavoriteInsightInput(BaseModel):
    profile_id:int
    category:str='general'
    title:str
    content:str


class MuhurtaInput(BaseModel):
    chart:Dict
    start_date:str
    end_date:str
    category:str='general'
    max_results:int=12

class TransitSeriesInput(BaseModel):
    chart:Dict
    start_date:str
    days:int=31

class RuleGraphInput(BaseModel):
    chart:Dict
    year:Optional[int]=None

class ShareSummaryInput(BaseModel):
    chart:Dict
    year:Optional[int]=None

class DashaProInput(BaseModel):
    chart:Dict
    when:Optional[str]=None

class FullPredictionInput(BaseModel):
    chart:Dict
    when:Optional[str]=None
    years:int=5

class VashistV11Input(BaseModel):
    chart:Dict
    horizon:int=25
    year:Optional[int]=None
    concern:Optional[str]=None

class SumitV12Input(BaseModel):
    chart:Dict
    horizon:int=5
    concern:Optional[str]=None

class V18Input(BaseModel):
    chart:Dict
    years:int=5
    year:Optional[int]=None
    profile_id:Optional[int]=None

class V18ChangeInput(BaseModel):
    chart:Dict
    year_a:int
    year_b:int

class V18ReportInput(BaseModel):
    chart:Dict
    report_type:str='full'


class AppointmentInput(BaseModel):
    profile_id:Optional[int]=None
    appointment_at:str
    kind:str='consultation'
    fee:float=0
    note:str=''

class AppointmentStatusInput(BaseModel):
    status:str='completed'

class PaymentInput(BaseModel):
    profile_id:Optional[int]=None
    amount:float
    mode:str='cash'
    reference:str=''
    note:str=''

class TeamMemberInput(BaseModel):
    name:str
    role:str='Astrologer'
    phone:str=''
    email:str=''


def _validate_rule_profile(v:str)->str:
    return v if v in RULE_PROFILES else '1940-foundation'

def _full_enrich(chart:Dict, years:int=12)->Dict:
    chart=enrich_chart(chart,years=years)
    chart['remedy_plan']=remedy_priority_plan(chart,primary_limit=3)
    try:
        chart['prediction_consensus']=prediction_consensus(chart,datetime.now().year)
    except Exception:
        chart['prediction_consensus']={}
    chart['v6']={
        'suite':'PRO ENTERPRISE INTELLIGENCE OS v18',
        'compatibility_modes':['relationship','business','family'],
        'rectification_assistant':True,
        'family_matrix':True,
        'prediction_consensus':True,
        'rule_audit':True,
        'scenario_lab':True,
        'command_center':True,
        'outcome_tracker':True,
        'vedic_auxiliary_suite':True,
        'ai_copilot_modes':8,
        'life_timeline_90':True,
        'monthly_focus':True,
        'live_transits':True,
    }
    try:
        chart['vedic_aux']=vedic_auxiliary(chart)
    except Exception as exc:
        chart['vedic_aux']={'error':str(exc),'method_note':'Vedic auxiliary layer unavailable for this chart.'}
    try:
        chart['dasha_pro']=vimshottari_full(chart)
    except Exception as exc:
        chart['dasha_pro']={'error':str(exc)}
    try:
        chart['live_transit']=transit_snapshot(chart)
    except Exception:
        chart['live_transit']={}
    try:
        chart['turning_points']=turning_point_summary(chart,18)
    except Exception:
        chart['turning_points']={}
    try:
        chart['command_center']=command_center(chart,datetime.now().year)
    except Exception:
        chart['command_center']={}
    try:
        v9v=shodashavarga_full(chart)
        chart['astro_v9']={
            'vargas':{'profile':v9v.get('profile'),'calculated':v9v.get('calculated',[]),'method_note':v9v.get('method_note')},
            'yogini':yogini_dasha(chart,3),
            'shadbala_research':shadbala_research(chart),
            'features':v9_feature_catalog(),
        }
    except Exception as exc:
        chart['astro_v9']={'error':str(exc),'features':v9_feature_catalog()}
    try:
        chart['vashist_v11']=vashist_dashboard(chart,25)
    except Exception as exc:
        chart['vashist_v11']={'error':str(exc),'source_library':source_library()}
    try:
        chart['sumitacharya_v12']=sumitacharya_dashboard(chart,5)
    except Exception as exc:
        chart['sumitacharya_v12']={'error':str(exc),'source_library':sumit_source_library()}
    try:
        chart['enterprise_v18']=enterprise_dashboard(chart)
    except Exception as exc:
        chart['enterprise_v18']={'error':str(exc),'reports':report_center_catalog()}
    chart['ai_os']={'version':'18.0','modes':ai_feature_catalog(),'ui':'Mobile-first Kundli + Astro Digital Twin + Event Radar + Astro Council + Full Prediction Studio + Source Labs + Reports & Print Center','principle':'Calculated facts, public-source references, independent software synthesis and AI narrative remain separate.','voice_browser':True,'practice_crm':True,'vashist_source_mode':True,'sumitacharya_source_mode':True,'source_labs':2}
    chart['critical_alert_center']=critical_alert_center(chart)
    chart['visual_intelligence_v19']=visual_intelligence(chart)
    chart['v19_2']=v19_2_dashboard(chart)
    chart['calculation_guard']={'status':'VERIFIED PIPELINE','house_mapping':'Lagna-relative whole-sign','separate_layers':['sign','whole_sign_house','Bhav Chalit','KP cusps','Lal Kitab interpretation'],'warning':'AI may interpret calculated values but must not rewrite them.'}
    return chart

def _chart_from_model(data:BirthInput)->Dict:
    d=data.model_dump();d['rule_profile']=_validate_rule_profile(d.get('rule_profile',''))
    try:
        chart=chart_payload(d)
        return _full_enrich(chart,years=12)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e))

@app.get('/api/health')
def health():return {'ok':True,'version':'19.2.0','database':str(db.DB_PATH.name),'remedies':catalog_meta()['total'],'prediction_engine':'Enterprise multi-source prediction + Astro Digital Twin + Council + Event Radar','prediction_domains':16,'vimshottari_4_level':True,'shodashavarga_16':True,'yogini_dasha':True,'muhurta_ai':True,'live_transits':True,'event_radar':True,'astro_digital_twin':True,'astro_council':True,'source_conflict_viewer':True,'forecast_horizons':['now','30d','12m','5y','10y','25y'],'reports_print_center':True,'full_research_pdf_pages':'dynamic-professional','vashist_source_lab':True,'sumitacharya_source_lab':True,'dosha_research_lab':True,'business_vastu_checklist':True,'practice_crm':True,'outcome_tracker':True,'source_labs':2,'category_horizons':[2,5,7,10,25],'safety_boundary':True}

@app.get('/api/cities')
def cities():return CITY_PRESETS

@app.post('/api/v19/critical-alerts')
def v19_critical_alerts(data:PdfInput):
    return critical_alert_center(data.chart)

@app.post('/api/v19/visual-intelligence')
def v19_visual_intelligence(data:PdfInput):
    return visual_intelligence(data.chart)

@app.post('/api/v19.2/intelligence')
def v19_2_intelligence(data:PdfInput):
    return v19_2_dashboard(data.chart)

@app.get('/api/rules')
def rules():
    return {
        'profiles':{k:{'label':v['label'],'pakka':{p:sorted(list(hs)) for p,hs in v['pakka'].items()},'note':v['note']} for k,v in RULE_PROFILES.items()},
        'relationships':{p:{k:sorted(list(vv)) for k,vv in d.items()} for p,d in RELATIONSHIPS.items()},
        'masnui':[{'pair':list(pair),'reference':ref,'note':note} for pair,ref,note in MASNUI],
        'planet_cycle_35':PLANET_CYCLE_35,'house_cycle_36':HOUSE_CYCLE_36,
        'method_note':'Observed astronomical placement, reference labels, source-specific rules and AI interpretation are kept as separate layers.'
    }

@app.get('/api/stats')
def stats():return db.stats()

@app.post('/api/chart')
def chart(data:BirthInput):return _chart_from_model(data)

@app.post('/api/profiles')
def create_profile(data:BirthInput):
    chart=_chart_from_model(data);return db.save_profile(data.model_dump(),chart)

@app.get('/api/profiles')
def list_profiles(search:str=''):return db.list_profiles(search)

@app.get('/api/profiles/{profile_id}')
def get_profile(profile_id:int):
    p=db.get_profile(profile_id)
    if not p:raise HTTPException(404,'Profile not found')
    return p

@app.delete('/api/profiles/{profile_id}')
def delete_profile(profile_id:int):
    if not db.delete_profile(profile_id):raise HTTPException(404,'Profile not found')
    return {'ok':True}

@app.post('/api/profiles/{profile_id}/recalculate')
def recalc_profile(profile_id:int):
    p=db.get_profile(profile_id)
    if not p:raise HTTPException(404,'Profile not found')
    data={k:p.get(k) for k in ['name','birth_date','birth_time','city','timezone_offset','latitude','longitude','rule_profile','notes']}
    chart=_full_enrich(chart_payload(data),years=12);return db.update_chart(profile_id,chart,data)

@app.post('/api/v10/dasha-pro')
def v10_dasha_pro(data:DashaProInput):
    return vimshottari_full(data.chart,data.when)

@app.post('/api/v10/full-predictions')
def v10_full_predictions(data:FullPredictionInput):
    return full_prediction_studio(data.chart,data.when,data.years)

@app.get('/api/v11/sources')
def v11_sources():
    return source_library()

@app.post('/api/v11/dashboard')
def v11_dashboard(data:VashistV11Input):
    return vashist_dashboard(data.chart,data.horizon)

@app.post('/api/v11/luck-meter')
def v11_luck_meter(data:VashistV11Input):
    return luck_meter(data.chart,data.year)

@app.post('/api/v11/luck-chain')
def v11_luck_chain(data:VashistV11Input):
    return luck_chain(data.chart,data.horizon)

@app.post('/api/v11/category-predictions')
def v11_category_predictions(data:VashistV11Input):
    return category_prediction_pack(data.chart,data.horizon)

@app.post('/api/v11/problem-detector')
def v11_problem_detector(data:VashistV11Input):
    return problem_detector(data.chart)

@app.post('/api/v11/source-remedies')
def v11_source_remedies(data:VashistV11Input):
    return {'items':vashist_source_recommended(data.chart,data.concern,60),'meta':catalog_meta(),'sources':source_library()}


@app.get('/api/v12/sources')
def v12_sources():
    return sumit_source_library()

@app.post('/api/v12/dashboard')
def v12_dashboard(data:SumitV12Input):
    return sumitacharya_dashboard(data.chart,data.horizon)

@app.post('/api/v12/deep-predictions')
def v12_deep_predictions(data:SumitV12Input):
    return sumit_deep_prediction_studio(data.chart,data.horizon)

@app.post('/api/v12/dosha-research')
def v12_dosha_research(data:SumitV12Input):
    return dosha_research_scanner(data.chart)

@app.post('/api/v12/source-remedies')
def v12_source_remedies(data:SumitV12Input):
    return {'items':sumitacharya_source_recommended(data.chart,data.concern,60),'meta':catalog_meta(),'sources':sumit_source_library()}

@app.post('/api/v12/baby-name')
def v12_baby_name(data:SumitV12Input):
    return baby_name_lab(data.chart)

@app.post('/api/v12/business-vastu')
def v12_business_vastu(data:SumitV12Input):
    return business_vastu_checklist(data.chart)

@app.post('/api/v12/marriage-panel')
def v12_marriage_panel(data:SumitV12Input):
    return marriage_single_chart_panel(data.chart)

@app.post('/api/v12/report-outline')
def v12_report_outline(data:SumitV12Input):
    return report_108_outline(data.chart)


def _v18_profile_context(profile_id:Optional[int]):
    if not profile_id:
        return {}
    try:
        st=db.outcome_stats(profile_id)
        return {'profile_id':profile_id,'outcomes_logged':st.get('total',0),'hit_rate_label':st.get('hit_rate_label'),'outcome_counts':st.get('counts',{})}
    except Exception:
        return {'profile_id':profile_id}

@app.get('/api/v18/reports')
def v18_reports_catalog():
    return report_center_catalog()

@app.post('/api/v18/dashboard')
def v18_dashboard(data:V18Input):
    return enterprise_dashboard(data.chart,_v18_profile_context(data.profile_id))

@app.post('/api/v18/digital-twin')
def v18_digital_twin(data:V18Input):
    return living_digital_twin(data.chart,_v18_profile_context(data.profile_id))

@app.post('/api/v18/forecast-horizons')
def v18_forecast_horizons(data:V18Input):
    return forecast_horizons(data.chart)

@app.post('/api/v18/event-radar')
def v18_event_radar(data:V18Input):
    return event_radar(data.chart,data.years)

@app.post('/api/v18/astro-council')
def v18_astro_council(data:V18Input):
    return astro_council(data.chart,data.year)

@app.post('/api/v18/source-compare')
def v18_source_compare(data:V18Input):
    return source_conflict_viewer(data.chart,data.years)

@app.post('/api/v18/what-changed')
def v18_what_changed(data:V18ChangeInput):
    return prediction_change_explainer(data.chart,data.year_a,data.year_b)

@app.post('/api/annual')
def annual(data:AnnualInput):
    base=_chart_from_model(data)
    pakka=RULE_PROFILES[_validate_rule_profile(data.rule_profile)]["pakka"]
    rot=annual_rotation_from_natal(base["placements"],data.birth_date,data.year,pakka)
    astro=annual_snapshot(data.name,data.birth_date,data.birth_time,data.timezone_offset,data.year,_validate_rule_profile(data.rule_profile))
    pro=pro_forecast_year(base,data.year)
    matrix=list(pro["domains"].values())
    events=event_windows_for_year(base,data.year)
    return {"year":data.year,"rotation":rot,"astronomical_comparison":astro,"predictions":matrix,"prediction_summary":{"strongest":pro["top"],"watch":pro["watch"],"method":pro["method"],"certainty":pro["certainty"]},"event_windows":events,"decision_dashboard":decision_dashboard(base,data.year),"note":"V7 keeps natal chart, 36-year house cycle, annual house rotation and birthday comparison as separate evidence layers, then derives multi-domain event-theme windows and exposes consensus/contradiction without treating them as guaranteed events."}

@app.get('/api/remedies/meta')
def remedies_meta():
    return catalog_meta()

@app.get('/api/remedies/catalog')
def remedies_catalog(q:str='',planet:Optional[str]=None,house:Optional[int]=None,category:Optional[str]=None,concern:Optional[str]=None,limit:int=250,source_kind:Optional[str]=None):
    return {"items":search_catalog(q,planet,house,category,concern,limit,source_kind),"meta":catalog_meta()}

@app.post('/api/remedies/recommended')
def remedies_recommended(data:PdfInput,concern:Optional[str]=None):
    return {"items":recommended_for_chart(data.chart,concern=concern,limit=30),"meta":catalog_meta()}

@app.post('/api/remedies/plan')
def remedies_plan(data:PdfInput,concern:Optional[str]=None):
    return remedy_priority_plan(data.chart,concern=concern,primary_limit=3)

@app.post('/api/forecast/range')
def forecast_range(data:ForecastRangeInput):
    try:
        return pro_forecast_range(data.chart,data.start_year,data.end_year)
    except ValueError as e:
        raise HTTPException(400,str(e))

@app.post('/api/events/year')
def events_year(data:EventYearInput):
    try:
        return event_windows_for_year(data.chart,data.year)
    except ValueError as e:
        raise HTTPException(400,str(e))

@app.post('/api/compatibility')
def compatibility(data:CompatibilityInput):
    return compatibility_report(data.chart_a,data.chart_b,data.mode)

@app.post('/api/family/matrix')
def family_matrix_api(data:FamilyMatrixInput):
    if len(data.charts)<2:
        raise HTTPException(400,'At least two charts are required')
    return family_matrix(data.charts)

@app.post('/api/predictions/consensus')
def predictions_consensus_api(data:ConsensusInput):
    try:
        return prediction_consensus(data.chart,data.year)
    except ValueError as e:
        raise HTTPException(400,str(e))

@app.post('/api/audit')
def audit_api(data:AuditInput):
    try:
        return rule_audit(data.chart,data.year)
    except ValueError as e:
        raise HTTPException(400,str(e))

@app.post('/api/birthtime/rectify')
def birthtime_rectify(data:RectificationInput):
    payload=data.model_dump()
    events=payload.pop('events',[])
    window=payload.pop('window_minutes',60)
    step=payload.pop('step_minutes',5)
    payload['rule_profile']=_validate_rule_profile(payload.get('rule_profile',''))
    try:
        return rectification_assistant(payload,window,step,events)
    except ValueError as e:
        raise HTTPException(400,str(e))

@app.post('/api/birthtime/sensitivity')
def birthtime_sensitivity(data:BirthSensitivityInput):
    window=max(5,min(int(data.window_minutes),120)); step=max(1,min(int(data.step_minutes),30))
    try:
        base_dt=datetime.fromisoformat(f"{data.birth_date}T{data.birth_time}")
    except Exception as e:
        raise HTTPException(400,'Invalid birth date/time') from e
    offsets=list(range(-window,window+1,step))
    if 0 not in offsets: offsets.append(0); offsets.sort()
    base_payload=data.model_dump();base_payload.pop('window_minutes',None);base_payload.pop('step_minutes',None)
    base_payload['rule_profile']=_validate_rule_profile(base_payload.get('rule_profile',''))
    base_chart=chart_payload(base_payload); base_by={p['planet']:p for p in base_chart['placements']}
    rows=[];changed_planets=set()
    for off in offsets:
        dt=base_dt+timedelta(minutes=off); payload=dict(base_payload);payload['birth_date']=dt.date().isoformat();payload['birth_time']=dt.time().replace(second=0,microsecond=0).isoformat(timespec='minutes')
        ch=chart_payload(payload); by={p['planet']:p for p in ch['placements']};changes=[]
        for pl,b in base_by.items():
            x=by[pl]
            house_changed=x['house']!=b['house'];sign_changed=x['sign']!=b['sign']
            if house_changed or sign_changed:
                changed_planets.add(pl);changes.append({'planet':pl,'base_house':b['house'],'house':x['house'],'base_sign':b['sign'],'sign':x['sign']})
        rows.append({'offset_minutes':off,'local_datetime':dt.isoformat(timespec='minutes'),'changes':changes,'changed_count':len(changes)})
    return {'window_minutes':window,'step_minutes':step,'stable':not changed_planets,'changed_planets':sorted(changed_planets),'rows':rows,
            'note':'This tests whether small birth-time changes alter fixed-house planetary sign/house placement in this software. It is a sensitivity check, not automatic birth-time rectification; many charts will remain unchanged because Lal Kitab fixed houses follow sidereal sign placement.'}

@app.post('/api/dashboard/command')
def dashboard_command(data:PdfInput):
    return command_center(data.chart,datetime.now().year)

@app.post('/api/scenarios/compare')
def scenarios_compare(data:ScenarioInput):
    return scenario_compare(data.chart,data.year,data.scenarios)

@app.post('/api/years/compare')
def years_compare(data:YearCompareInput):
    return year_compare(data.chart,data.year_a,data.year_b)

@app.post('/api/consultation/brief')
def consultation_brief_api(data:ConsultationBriefInput):
    return consultation_brief(data.chart,data.year)

@app.post('/api/outcomes')
def add_outcome(data:PredictionOutcomeInput):
    if not db.get_profile(data.profile_id): raise HTTPException(404,'Profile not found')
    return db.add_prediction_outcome(data.profile_id,data.year,data.domain,data.predicted_score,data.outcome,data.note)

@app.get('/api/outcomes/profile/{profile_id}')
def get_outcomes(profile_id:int):
    return {'items':db.list_prediction_outcomes(profile_id),'stats':db.outcome_stats(profile_id)}

@app.post('/api/followups')
def add_followup(data:FollowupInput):
    if not db.get_profile(data.profile_id): raise HTTPException(404,'Profile not found')
    return db.add_followup(data.profile_id,data.due_date,data.kind,data.note)

@app.get('/api/followups/profile/{profile_id}')
def get_followups(profile_id:int):
    return db.list_followups(profile_id)

@app.post('/api/followups/{followup_id}/done')
def close_followup(followup_id:int):
    if not db.close_followup(followup_id): raise HTTPException(404,'Follow-up not found')
    return {'ok':True}

@app.post('/api/timeline')
def timeline(data:TimelineInput):
    start=max(1,min(data.start_age,108));end=max(start,min(data.end_age,108))
    return {'house_cycle':house_cycle_timeline(start,end),'planet_cycle':planet_cycle_from_anchor(data.anchor_planet,data.anchor_age,start,end),'note':'35-year planet cycle needs a traceable anchor. The selected anchor is a user-supplied study setting, not an automatically proven birth start.'}

@app.post('/api/remedy-programs')
def remedy_program(data:RemedyInput):
    if not db.get_profile(data.profile_id):raise HTTPException(404,'Profile not found')
    if data.duration<1 or data.duration>365:raise HTTPException(400,'Duration must be 1–365 days')
    return db.add_remedy(data.profile_id,data.planet,data.remedy,data.duration,data.start_date)

@app.get('/api/remedy-programs/profile/{profile_id}')
def remedy_list(profile_id:int):return db.list_remedies(profile_id)

@app.post('/api/remedy-programs/{program_id}/checkin')
def remedy_checkin(program_id:int,data:CheckinInput):
    r=db.checkin(program_id,data.day_no,data.date,data.note,data.completed)
    if not r:raise HTTPException(404,'Program not found')
    return r

@app.post('/api/notes')
def add_note(data:NoteInput):
    if not db.get_profile(data.profile_id):raise HTTPException(404,'Profile not found')
    return db.add_note(data.profile_id,data.note)

@app.get('/api/notes/profile/{profile_id}')
def notes(profile_id:int):return db.list_notes(profile_id)

@app.post('/api/vedic/auxiliary')
def vedic_aux_api(data:PdfInput):
    return vedic_auxiliary(data.chart)

@app.post('/api/transits')
def transits_api(data:TransitInput):
    return transit_snapshot(data.chart,data.when)

@app.post('/api/monthly-focus')
def monthly_focus_api(data:MonthlyFocusInput):
    return monthly_focus(data.chart,data.year)

@app.post('/api/life-timeline')
def life_timeline_api(data:LifeTimelineInput):
    return life_timeline(data.chart,data.start_age,data.end_age)

@app.get('/api/ai/features')
def ai_features_api():
    return {'items':ai_feature_catalog(),'cloud_ready':bool(os.getenv('OPENAI_API_KEY') and os.getenv('OPENAI_MODEL')),'note':'Cloud AI activates only when OPENAI_API_KEY and OPENAI_MODEL are configured. Built-in explainable fallbacks remain available.'}

@app.post('/api/v9/vargas')
def v9_vargas(data:PdfInput):
    return shodashavarga_full(data.chart)

@app.post('/api/v9/yogini')
def v9_yogini(data:PdfInput):
    return yogini_dasha(data.chart,3)

@app.post('/api/v9/shadbala-research')
def v9_shadbala(data:PdfInput):
    return shadbala_research(data.chart)

@app.post('/api/v9/muhurta')
def v9_muhurta(data:MuhurtaInput):
    try:
        return muhurta_finder(data.chart,data.start_date,data.end_date,data.category,data.max_results)
    except ValueError as e:
        raise HTTPException(400,str(e))

@app.post('/api/v9/transit-series')
def v9_transit_series(data:TransitSeriesInput):
    try:
        return transit_series(data.chart,data.start_date,data.days)
    except ValueError as e:
        raise HTTPException(400,str(e))

@app.post('/api/v9/rule-graph')
def v9_rule_graph(data:RuleGraphInput):
    return rule_graph(data.chart,data.year)

@app.post('/api/v9/share-summary')
def v9_share_summary(data:ShareSummaryInput):
    return whatsapp_summary(data.chart,data.year)

@app.get('/api/v9/features')
def v9_features():
    return {'version':'9.0.0','features':v9_feature_catalog(),'method_note':'V9 separates classical/reference workspaces from software research indexes and AI narrative.'}

@app.post('/api/appointments')
def add_appointment(data:AppointmentInput):
    if data.profile_id is not None and not db.get_profile(data.profile_id): raise HTTPException(404,'Profile not found')
    return db.add_appointment(data.profile_id,data.appointment_at,data.kind,data.fee,data.note)

@app.get('/api/appointments')
def appointments(status:Optional[str]=None,profile_id:Optional[int]=None):
    return db.list_appointments(status,profile_id)

@app.post('/api/appointments/{appointment_id}/status')
def appointment_status(appointment_id:int,data:AppointmentStatusInput):
    if not db.update_appointment_status(appointment_id,data.status): raise HTTPException(404,'Appointment not found')
    return {'ok':True}

@app.post('/api/payments')
def add_payment(data:PaymentInput):
    if data.amount<=0: raise HTTPException(400,'Amount must be positive')
    if data.profile_id is not None and not db.get_profile(data.profile_id): raise HTTPException(404,'Profile not found')
    return db.add_payment(data.profile_id,data.amount,data.mode,data.reference,data.note)

@app.get('/api/payments')
def payments(profile_id:Optional[int]=None):
    return {'items':db.list_payments(profile_id),'stats':db.payment_stats()}

@app.post('/api/team')
def add_team(data:TeamMemberInput):
    return db.add_team_member(data.name,data.role,data.phone,data.email)

@app.get('/api/team')
def team():
    return db.list_team()

@app.post('/api/consultations')
def add_consultation_session(data:ConsultationSessionInput):
    if not db.get_profile(data.profile_id): raise HTTPException(404,'Profile not found')
    return db.add_consultation(data.profile_id,data.title,data.summary,data.actions)

@app.get('/api/consultations/profile/{profile_id}')
def consultation_sessions(profile_id:int):
    return db.list_consultations(profile_id)

@app.post('/api/favorites')
def add_favorite(data:FavoriteInsightInput):
    if not db.get_profile(data.profile_id): raise HTTPException(404,'Profile not found')
    return db.add_favorite_insight(data.profile_id,data.category,data.title,data.content)

@app.get('/api/favorites/profile/{profile_id}')
def favorite_insights(profile_id:int):
    return db.list_favorite_insights(profile_id)

@app.get('/api/chats/profile/{profile_id}')
def chat_history(profile_id:int):
    return db.list_chats(profile_id,100)


def _fallback_ai(question:str,chart:Dict)->str:
    q=question.lower();pl=chart.get('placements',[]);by={p['planet']:p for p in pl};hm={h:[] for h in range(1,13)}
    for p in pl:hm[p['house']].append(p['planet'])
    def pp(n):
        p=by.get(n);return '' if not p else f"{n}: H{p['house']} {p['sign']}, {', '.join(p.get('status',[]))}, state {p.get('state')}"
    if any(x in q for x in ['career','business','job','karrier','काम','व्यापार']):
        return f"Career lens — H10: {', '.join(hm[10]) or 'empty'}; H11: {', '.join(hm[11]) or 'empty'}. {pp('Saturn')}. {pp('Mercury')}. Treat this as a reflection layer: skill, consistency, contracts and documented decisions matter more than any prediction."
    if any(x in q for x in ['money','wealth','finance','paisa','धन']):
        return f"Money lens — H2: {', '.join(hm[2]) or 'empty'}; H11: {', '.join(hm[11]) or 'empty'}. {pp('Jupiter')}. {pp('Venus')}. Do not use astrology alone for investments, loans or major financial decisions."
    if any(x in q for x in ['marriage','love','relationship','shaadi','विवाह']):
        return f"Relationship lens — H7: {', '.join(hm[7]) or 'empty'}. {pp('Venus')}. Focus on communication, respect, consent, boundaries and compatibility; the chart cannot guarantee a marriage outcome or date."
    if any(x in q for x in ['rin','debt','ऋण']):
        review=[r for r in chart.get('rin',[]) if r.get('status')=='Review']
        return ('Rin review flags: '+('; '.join(f"{r['name']}: {r['evidence']}" for r in review) if review else 'no conservative auto-trigger')+'. Formal Rin diagnosis is edition-specific and should not be treated as proof of wrongdoing or literal debt.')
    if any(x in q for x in ['remedy','upay','उपाय']):
        challenging=[p for p in pl if 'Neecha reference' in p.get('status',[]) or 'Soya candidate' in p.get('status',[])] or pl[:2]
        recs=chart.get('remedy_recommendations',[])[:5]; return 'Priority low-risk options: '+(' | '.join(f"{r.get('planet') or 'House'}: {r['action']}" for r in recs) if recs else ' | '.join(f"{p['planet']}: {p['remedies'][0]}" for p in challenging[:3]))+'. Avoid expensive, hazardous or medical-treatment-replacing remedies.'
    if any(x in q for x in ['prediction','future','forecast','year','outlook','भविष्य']):
        rows=chart.get('predictions',[]); top=sorted(rows,key=lambda x:x.get('score',50),reverse=True)[:3]; watch=sorted(rows,key=lambda x:x.get('score',50))[:2]
        return 'PRO prediction matrix — stronger emphasis: '+('; '.join(f"{x['label']} {x['score']}/100 ({x['band']})" for x in top) if top else 'not calculated')+'. Watch areas: '+('; '.join(f"{x['label']} {x['score']}/100" for x in watch) if watch else 'none')+'. These are evidence-weighted symbolic scores, not event probabilities or guarantees.'
    strong=sorted(pl,key=lambda p:p.get('score',50),reverse=True)[:3]
    special=[x for x in chart.get('special_teva',[]) if x.get('status')=='Detected']
    return 'Chart overview — '+'. '.join(f"{p['planet']} H{p['house']} score {p['score']}/100 ({', '.join(p['status'])})" for p in strong)+('. Special technical flags: '+', '.join(x['label'] for x in special) if special else '')+'. Ask about a house, planet, career, relationship, Rin, timing or remedies.'


def _openai_text(question:str,chart:Dict,language:str,mode:str="explainer")->Optional[str]:
    key=os.getenv('OPENAI_API_KEY'); model=os.getenv('OPENAI_MODEL')
    if not key or not model or OpenAI is None:return None
    try:
        client=OpenAI(api_key=key)
        compact={k:chart.get(k) for k in ['profile','engine','placements','relationships','aspects','virtual_axes','masnui','special_teva','rin','timing','predictions','prediction_summary','pro_predictions','remedy_recommendations','remedy_plan','prediction_consensus','vedic_aux','turning_points']}
        vv=chart.get('vashist_v11',{}) or {}; sv=chart.get('sumitacharya_v12',{}) or {}
        compact['gd_vashist_public_source']={'luck_meter':vv.get('luck_meter'),'problem_detector':vv.get('problem_detector'),'source_remedies':(vv.get('source_remedies') or [])[:8]}
        compact['sumitacharya_public_source']={'dosha_research':sv.get('dosha_research'),'baby_name':sv.get('baby_name'),'business_vastu':sv.get('business_vastu'),'marriage_panel':sv.get('marriage_panel'),'source_remedies':(sv.get('source_remedies') or [])[:8],'deep_strongest':((sv.get('deep_predictions') or {}).get('strongest') or [])[:6],'deep_watch':((sv.get('deep_predictions') or {}).get('watch') or [])[:6]}
        mode_guidance={
            'explainer':'Explain the requested chart topic with explicit supporting and caution evidence.',
            'second_opinion':'Give an independent second interpretation, then state where it agrees/disagrees with the existing software synthesis.',
            'skeptic':'Actively search for contradictory evidence, uncertainty, missing birth-data assumptions and reasons NOT to overstate the result.',
            'consultation':'Act as a consultation copilot: produce concise agenda, verification questions, observations, practical follow-ups and documentation notes.',
            'remedy_review':'Review proposed/current remedies for duplication, overload, ambiguity and safety. Prefer no more than 1–3 low-risk cultural practices at a time.',
            'timeline':'Narrate the timeline carefully, separating annual software emphasis, house cycle, Vedic auxiliary timing and real-world verification.',
            'report':'Write a client-friendly executive summary with calculated facts, traditional-reference interpretations, uncertainty and practical reflection.',
            'evidence':'Answer only by tracing the evidence chain behind the requested prediction: placements, house rules, aspects/relations, annual/cycle layers and contradictions.',
            'muhurta':'Act as a cautious Muhurta planning assistant. Compare candidate dates using the computed Panchang/Tara/natal context and explicitly state that timing is not a guarantee.',
            'research':'Act as an astrology research copilot. Compare Varga, Yogini, Shadbala-research, Lal Kitab and prediction layers without silently mixing systems.',
            'compatibility_ai':'Explain compatibility evidence in a balanced way and avoid deterministic relationship outcomes.',
            'business_ai':'Explain business/career symbolic indicators while explicitly avoiding financial-return guarantees or investment instructions.',
            'source_compare':'Compare core calculations with GD Vashist/Astroscience public-source and Shri Sumitacharya public-source layers. State agreements, differences, missing evidence and attribution; never imply endorsement or proprietary equivalence.',
            'dosha_audit':'Audit dosha candidate flags skeptically. Highlight variant definitions, cancellation rules and missing evidence. Never infer death, widowhood, disease, fertility, lifespan or unavoidable harm.',
            'remedy_scholar':'Explain the chart-ranked source-aware remedies, their attribution and safety. Prefer 1–3 low-risk practices, flag duplicates/expensive or risky variants, and do not reproduce proprietary remedy lists.'
        }
        instructions=("You are Lal Kitab AI PRO MULTI-SOURCE INTELLIGENCE OS v12. Astrology is a traditional belief system, not scientific certainty. "
            "Keep astronomical calculations, Lal Kitab source/reference rules, Vedic auxiliary layers, software synthesis scores and AI narrative visibly separate. "
            "Never make deterministic claims about death, disease, pregnancy, crime, legal outcomes, investment returns or guaranteed future events. "
            "Never tell users to stop treatment or take financial/legal/safety risks. Technical chart labels are not descriptions of a person's worth. "
            "Do not call interpretive scores probabilities. Prefer low-cost, low-risk remedies and practical verification. "
            + mode_guidance.get(mode,mode_guidance['explainer']) + " Reply in "+language+".")
        r=client.responses.create(model=model,instructions=instructions,input=f"Chart JSON:\n{json.dumps(compact,ensure_ascii=False)}\n\nUser request: {question or mode}",max_output_tokens=1300)
        return r.output_text.strip()
    except Exception:return None

def _fallback_copilot(mode:str,question:str,chart:Dict)->str:
    base=_fallback_ai(question or 'chart overview',chart)
    pc=chart.get('prediction_consensus',{})
    rp=chart.get('remedy_plan',{})
    if mode=='skeptic':
        cons=pc.get('contradictions',[])[:4]
        return 'AI Skeptic — '+(('Mixed evidence: '+'; '.join(f"{x.get('label')}: support {', '.join(x.get('support_layers',[])) or '—'} / caution {', '.join(x.get('caution_layers',[])) or '—'}" for x in cons)) if cons else 'No high-priority contradiction is currently flagged, but birth-time and source-school assumptions still limit certainty.')+' Treat all outcome language as interpretive. '+base
    if mode=='second_opinion':
        top=sorted(chart.get('predictions',[]),key=lambda x:x.get('score',50),reverse=True)[:3]
        return 'AI Second Opinion — Independent emphasis check: '+', '.join(f"{x.get('label')} {x.get('score')}/100" for x in top)+'. I would downgrade any strong wording where consensus is mixed or data integrity is weak. '+base
    if mode=='consultation':
        brief=consultation_brief(chart,datetime.now().year)
        qs=' | '.join(brief.get('consultation_questions',[])[:5])
        return f"AI Consultation Copilot — Opening: {brief.get('opening_summary')}. Verify: {qs}. Close by separating verified facts, chart observations, source rules and client choices."
    if mode=='remedy_review':
        prim=rp.get('primary',[])[:3]
        return 'AI Remedy Safety Review — Keep the protocol small: '+(' | '.join(str(x.get('action')) for x in prim) if prim else 'no core remedy selected')+'. Avoid remedy stacking, hazardous ingestion, pollution, animal harm, fire risk, medical replacement or expensive guarantees. Review adherence and outcome before adding more.'
    if mode=='timeline':
        tp=chart.get('turning_points',{}).get('turning_points',[])[:5]
        return 'AI Timeline Narrator — Largest software-index shifts: '+(' | '.join(f"{x.get('year')} Δ{x.get('delta')}" for x in tp) if tp else 'timeline not calculated')+'. These are changes in model emphasis, not promised life events.'
    if mode=='evidence':
        return 'Why this prediction? — '+base+' Cross-check the prediction consensus and rule audit before treating any single rule as decisive.'
    if mode=='report':
        cmd=chart.get('command_center',{}); k=cmd.get('kpis',{})
        return f"Executive summary — domain balance {k.get('domain_balance','—')}, evidence coverage {k.get('evidence_coverage','—')}, consensus {k.get('consensus_index','—')}. "+base
    if mode=='muhurta':
        return 'Muhurta AI — Use the dedicated Muhurta Planner to rank dates from Panchang/Tara and natal annual context. Timing is a traditional planning reference, not a guarantee. '+base
    if mode=='research':
        a=chart.get('astro_v9',{}); return f"Research Copilot — Varga profile: {(a.get('vargas') or {}).get('profile','—')}; Yogini active: {((a.get('yogini') or {}).get('active') or {}).get('yogini','—')}. Keep Lal Kitab, Vedic auxiliary and software indexes separate. "+base
    if mode=='compatibility_ai':
        return 'Compatibility AI — Compare communication, shared-goal and caution evidence without treating a chart as proof that a relationship will succeed or fail. '+base
    if mode=='business_ai':
        return 'Business AI — Use career/business indicators as reflective planning inputs only. Do not treat astrology as investment advice or guaranteed revenue forecasting. '+base
    if mode=='source_compare':
        vv=chart.get('vashist_v11',{}) or {}; sv=chart.get('sumitacharya_v12',{}) or {}
        return 'AI Source Compare — GD Vashist public-source layer and Shri Sumitacharya public-source layer are independent references, not one merged doctrine. GD Vashist layer currently emphasizes house-first/Luck-chain/category synthesis; Sumitacharya layer emphasizes detailed multi-area report breadth, dosha research, marriage/business/Vastu workflows and source-linked remedies. Compare them against calculated placements and current dasha; disagreements stay visible. '+base
    if mode=='dosha_audit':
        ds=(chart.get('sumitacharya_v12',{}) or {}).get('dosha_research',{}) or {}
        return 'AI Dosha Auditor — '+(' | '.join(f"{x.get('label')}: {x.get('status')}" for x in (ds.get('flags') or [])) or 'No V12 dosha scan available')+'. These are candidate screens with variant definitions/cancellations. Never use them for death, disease, widowhood, fertility, lifespan or unavoidable-harm claims.'
    if mode=='remedy_scholar':
        sr=((chart.get('sumitacharya_v12',{}) or {}).get('source_remedies') or [])[:3]
        vr=((chart.get('vashist_v11',{}) or {}).get('source_remedies') or [])[:3]
        rows=sr+vr
        return 'AI Remedy Scholar — Keep source attribution visible and select at most 1–3 low-risk practices. Current source-aware candidates: '+(' | '.join(str(x.get('action','')) for x in rows[:5]) if rows else 'use the Source Upay vault')+'. Avoid proprietary copying, fear-driven spending, unsafe ritual handling or professional-advice replacement.'
    return base

@app.post('/api/chat')
def chat(data:ChatInput):
    ans=_openai_text(data.question,data.chart,data.language,'explainer')
    mode='Cloud AI' if ans else 'Built-in AI OS interpretation engine'
    return {'answer':ans or _fallback_ai(data.question,data.chart),'mode':mode}

@app.post('/api/ai/copilot')
def ai_copilot(data:AICopilotInput):
    allowed={x['key'] for x in ai_feature_catalog()}
    mode=data.mode if data.mode in allowed else 'explainer'
    ans=_openai_text(data.question,data.chart,data.language,mode)
    answer=ans or _fallback_copilot(mode,data.question,data.chart)
    source='Cloud AI' if ans else 'Built-in AI OS'
    if data.profile_id is not None and db.get_profile(data.profile_id):
        db.add_chat(data.profile_id,mode,data.question or mode,answer)
    return {'mode':mode,'source':source,'answer':answer,'safety_note':'Interpretive astrology support only; not medical, legal, financial or safety-critical advice.'}

@app.post('/api/palm/analyze')
async def palm_analyze(image:UploadFile=File(...),hand:str=Form('unknown'),language:str=Form('Hinglish')):
    raw=await image.read()
    if len(raw)>8_000_000:raise HTTPException(413,'Image too large; use under 8 MB')
    key=os.getenv('OPENAI_API_KEY');model=os.getenv('OPENAI_MODEL')
    if not key or not model or OpenAI is None:
        return {'mode':'Vision requires OpenAI key','answer':'Palm image received. Configure OPENAI_API_KEY to enable the optional visual palmistry explainer. Palmistry will be framed as a traditional/entertainment interpretation, not a factual prediction.'}
    try:
        mime=image.content_type or 'image/jpeg';b64=base64.b64encode(raw).decode('ascii');client=OpenAI(api_key=key)
        r=client.responses.create(model=model,instructions='You are an optional palmistry explainer inside Lal Kitab AI PRO. Describe only visible palm-line/shape features and traditional palmistry interpretations as entertainment/cultural belief. Do not infer health, lifespan, death, fertility, criminality, personality certainty, wealth guarantees or protected/sensitive traits. Be concise and use '+language+'.',input=[{'role':'user','content':[{'type':'input_text','text':f'Hand: {hand}. Explain the visible palm features conservatively.'},{'type':'input_image','image_url':f'data:{mime};base64,{b64}'}]}],max_output_tokens=700)
        return {'mode':'OpenAI Vision','answer':r.output_text.strip()}
    except Exception as e:raise HTTPException(500,'Vision analysis failed') from e


def _font():
    for f in ['/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']:
        if Path(f).exists():
            try:pdfmetrics.registerFont(TTFont('ReportFont',f));return 'ReportFont'
            except Exception:pass
    return 'Helvetica'

def _esc(x):
    return str(x or '').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

@app.post('/api/report.pdf')
def report_pdf(data:PdfInput):
    chart=data.chart;buf=io.BytesIO();font=_font();styles=getSampleStyleSheet()
    title=ParagraphStyle('title',parent=styles['Title'],fontName=font,textColor=colors.HexColor('#8D1722'),alignment=TA_CENTER,fontSize=22,spaceAfter=8)
    h2=ParagraphStyle('h2',parent=styles['Heading2'],fontName=font,textColor=colors.HexColor('#8D1722'),fontSize=14,spaceBefore=10,spaceAfter=6)
    h3=ParagraphStyle('h3',parent=styles['Heading3'],fontName=font,textColor=colors.HexColor('#5E3C24'),fontSize=11,spaceBefore=7,spaceAfter=4)
    body=ParagraphStyle('body',parent=styles['BodyText'],fontName=font,fontSize=9.2,leading=13)
    doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=13*mm,leftMargin=13*mm,topMargin=13*mm,bottomMargin=13*mm)
    story=[Paragraph('Lal Kitab AI PRO MULTI-SOURCE INTELLIGENCE OS v12 - Complete Analysis',title)]
    p=chart.get('profile',{});e=chart.get('engine',{})
    story += [Paragraph(f"<b>{_esc(p.get('name'))}</b><br/>DOB: {_esc(p.get('birth_date'))} {_esc(p.get('birth_time'))} &nbsp; Place: {_esc(p.get('city'))}<br/>Rule profile: {_esc(p.get('rule_profile_label'))}",body),Spacer(1,5),Paragraph(f"Engine: {_esc(e.get('ephemeris'))} | {_esc(e.get('zodiac'))} / {_esc(e.get('ayanamsa'))} | Ayanamsa {_esc(e.get('ayanamsa_degrees'))}°",body)]
    story.append(Paragraph('1. Planetary Passport',h2));td=[['Planet','House','Sign','Degree','Score','State / Labels']]
    for x in chart.get('placements',[]):td.append([x['planet'],f"H{x['house']}",x['sign'],f"{x['degree_in_sign']}°",str(x.get('score','')),x.get('state','')+'; '+', '.join(x.get('status',[]))])
    t=Table(td,colWidths=[24*mm,14*mm,25*mm,19*mm,15*mm,84*mm],repeatRows=1);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#8D1722')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,-1),font),('FONTSIZE',(0,0),(-1,-1),7.8),('GRID',(0,0),(-1,-1),0.3,colors.HexColor('#D5C4AD')),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#FFF8ED'),colors.white])]))
    story.append(t)
    story.append(Paragraph('2. Special Teva & State Lab',h2))
    for x in chart.get('special_teva',[]):story.append(Paragraph(f"<b>{_esc(x['label'])}</b> — {_esc(x['status'])}<br/>{_esc(x['evidence'])}<br/><i>{_esc(x['note'])}</i>",body))
    story.append(Paragraph('3. Masnui Reference Scan',h2))
    for x in chart.get('masnui',[]):story.append(Paragraph(f"<b>{_esc(x['pair'])}</b> — {_esc(x['reference'])}; {_esc(x['note'])}",body))
    story.append(Paragraph('4. Rin Review',h2))
    for x in chart.get('rin',[]):story.append(Paragraph(f"<b>{_esc(x['name'])}</b> ({_esc(x['name_hi'])}) — {_esc(x['status'])}: {_esc(x['evidence'])}",body))
    story.append(PageBreak());story.append(Paragraph('5. House Intelligence',h2))
    for x in chart.get('houses',[]):story.append(Paragraph(f"<b>House {x['house']}: {_esc(x['meaning'])}</b> — {', '.join(x['planets']) if x['planets'] else 'Unoccupied'}",body))
    story.append(Paragraph('6. Remedy Guidance',h2))
    for x in chart.get('placements',[]):
        story.append(Paragraph(f"<b>{x['planet']} / {x['planet_hi']}</b>",h3))
        for r in x.get('remedies',[]):story.append(Paragraph('• '+_esc(r),body))
    story.append(Paragraph('7. PRO Prediction Matrix',h2))
    for x in chart.get('predictions',[]):
        story.append(Paragraph(f"<b>{_esc(x.get('label'))}: {_esc(x.get('score'))}/100 — {_esc(x.get('band'))} • Evidence confidence {_esc(x.get('confidence'))}%</b><br/>Evidence: {_esc('; '.join((e.get('label') if isinstance(e,dict) else str(e)) for e in x.get('evidence',[])[:6]))}<br/><i>{_esc(x.get('practical') or x.get('guidance'))}</i>",body))
    story.append(Paragraph('7A. Active 4-Level Dasha Hierarchy',h2))
    dp=chart.get('dasha_pro') or vimshottari_full(chart)
    for x in dp.get('active_chain',[]):
        story.append(Paragraph(f"<b>{_esc(x.get('level'))}: {_esc(x.get('lord'))}</b> — {_esc(x.get('start'))} to {_esc(x.get('end'))} • Lal Kitab H{_esc(x.get('lal_kitab_house'))} • natal index {_esc(x.get('natal_score'))}/100<br/>{_esc(x.get('focus'))}<br/><i>Support: {_esc(x.get('support'))}; Watch: {_esc(x.get('watch'))}</i>",body))
    story.append(Paragraph('7B. Detailed Current Prediction Synthesis',h2))
    fp=full_prediction_studio(chart,years=5)
    for x in sorted(fp.get('domains',[]),key=lambda z:z.get('current_score',50),reverse=True):
        story.append(Paragraph(f"<b>{_esc(x.get('label'))}: {_esc(x.get('current_score'))}/100 — {_esc(x.get('band'))}</b><br/>{_esc(x.get('narrative'))}",body))
    story.append(Paragraph('8. Priority Remedy Vault Picks',h2))
    for r in chart.get('remedy_recommendations',[])[:18]:
        story.append(Paragraph(f"• <b>{_esc(r.get('planet') or ('House '+str(r.get('house'))))}</b> — {_esc(r.get('action'))} <i>({_esc(r.get('category'))})</i>",body))
    rm=chart.get('remedy_catalog',{});story.append(Paragraph(f"Catalog available in software: {_esc(rm.get('total'))} safety-filtered entries across 108 planet-house combinations.",body))
    story.append(Paragraph('9. Multi-Year PRO Forecast',h2))
    pro=chart.get('pro_predictions',{})
    for y in pro.get('forecast',[])[:10]:
        if y.get('error'): continue
        tops=', '.join(f"{x.get('label')} {x.get('score')}" for x in y.get('top',[])[:2])
        watch=', '.join(f"{x.get('label')} {x.get('score')}" for x in y.get('watch',[])[:1])
        story.append(Paragraph(f"<b>{_esc(y.get('year'))}</b> • age ref {_esc(y.get('age_reference'))} • H{_esc((y.get('house_cycle') or {}).get('house'))}<br/>Stronger emphasis: {_esc(tops)}<br/>Watch: {_esc(watch)}",body))
    story.append(Paragraph('10. Event-Theme Windows',h2))
    ew=chart.get('event_windows',{})
    for x in ew.get('top_windows',[])[:6]:
        story.append(Paragraph(f"<b>{_esc(x.get('label'))}: {_esc(x.get('score'))}/100 — {_esc(x.get('band'))}</b><br/>Verification: {_esc(x.get('verification_question'))}",body))
    for x in ew.get('management_flags',[])[:3]:
        story.append(Paragraph(f"<b>Management flag — {_esc(x.get('label'))}: {_esc(x.get('score'))}/100</b><br/>{_esc(x.get('verification_question'))}",body))
    story.append(Paragraph('11. Prediction Consensus & Contradictions',h2))
    pc=chart.get('prediction_consensus',{})
    for x in pc.get('high_consensus',[])[:6]:
        story.append(Paragraph(f"<b>{_esc(x.get('label'))}: score {_esc(x.get('score'))}/100 • consensus {_esc(x.get('consensus'))}% • {_esc(x.get('dominant'))}</b><br/>Support layers: {_esc(', '.join(x.get('support_layers',[])) or '—')}<br/>Caution layers: {_esc(', '.join(x.get('caution_layers',[])) or '—')}",body))
    for x in pc.get('contradictions',[])[:4]:
        story.append(Paragraph(f"<b>Mixed evidence — {_esc(x.get('label'))}</b>: support {_esc(', '.join(x.get('support_layers',[])))}; caution {_esc(', '.join(x.get('caution_layers',[])))}",body))
    story.append(Paragraph('12. Smart Remedy Protocol',h2))
    rp=chart.get('remedy_plan',{})
    for i,r in enumerate(rp.get('primary',[])[:3],1):
        story.append(Paragraph(f"<b>Core {i}: {_esc(r.get('planet'))} {('H'+str(r.get('house'))) if r.get('house') else ''}</b> — {_esc(r.get('action'))}<br/><i>{_esc(r.get('why_selected'))}</i>",body))
    for rule in rp.get('protocol_rules',[])[:5]: story.append(Paragraph('• '+_esc(rule),body))
    story.append(Paragraph('13. Command Center & Scenario Spotlight',h2))
    cmd=chart.get('command_center') or command_center(chart,datetime.now().year)
    kp=cmd.get('kpis',{})
    story.append(Paragraph(f"Domain balance {_esc(kp.get('domain_balance'))}/100 • evidence coverage {_esc(kp.get('evidence_coverage'))}/100 • consensus {_esc(kp.get('consensus_index'))}/100 • contradictions {_esc(kp.get('contradictions'))}",body))
    for x in cmd.get('scenario_spotlight',[])[:5]:
        story.append(Paragraph(f"• <b>{_esc(x.get('label'))}: {_esc(x.get('index'))}/100</b> — {_esc(x.get('band'))}",body))
    for x in cmd.get('attention_flags',[])[:5]:
        story.append(Paragraph(f"<b>{_esc(x.get('title'))}</b> — {_esc(x.get('detail'))}",body))
    story.append(Paragraph('14. Vedic Auxiliary Kundli Suite',h2))
    va=chart.get('vedic_aux',{}); lag=va.get('lagna',{}); pan=va.get('panchang',{}); das=va.get('vimshottari',{})
    story.append(Paragraph(f"Lagna: {_esc(lag.get('sign'))} {_esc(lag.get('degree_in_sign'))}° • Nakshatra: {_esc((pan.get('nakshatra') or {}).get('name'))} pada {_esc((pan.get('nakshatra') or {}).get('pada'))} • Tithi: {_esc((pan.get('tithi') or {}).get('paksha'))} {_esc((pan.get('tithi') or {}).get('name'))} • Yoga: {_esc((pan.get('yoga') or {}).get('name'))} • Karana: {_esc((pan.get('karana') or {}).get('name'))}<br/>Vimshottari active reference: {_esc((das.get('active') or {}).get('lord'))} ({_esc((das.get('active') or {}).get('start'))} to {_esc((das.get('active') or {}).get('end'))}).<br/><i>{_esc(va.get('method_note'))}</i>",body))
    story.append(Paragraph('15. Turning-Point & Life Timeline Preview',h2))
    for x in (chart.get('turning_points') or {}).get('turning_points',[])[:8]:
        story.append(Paragraph(f"• {_esc(x.get('year'))}: software-index delta {_esc(x.get('delta'))}; leading emphasis {_esc(', '.join(z.get('label','') for z in x.get('top',[])[:1]))}",body))
    story.append(Paragraph('16. Timing Reference',h2));tim=chart.get('timing',{});hc=tim.get('house_cycle_36',{})
    story.append(Paragraph(f"Current age: {_esc(tim.get('age'))}; 36-year house-cycle position: {_esc(hc.get('cycle_position'))}; active reference house: H{_esc(hc.get('house'))} ({_esc(hc.get('meaning'))}).<br/>{_esc(tim.get('planet_cycle_35_note'))}",body))
    story.append(Paragraph('17. Multi-Source Research Labs',h2))
    av=chart.get('astro_v9',{}); yg=av.get('yogini',{}); sh=av.get('shadbala_research',{}); vg=av.get('vargas',{})
    story.append(Paragraph(f"16-Varga profile: {_esc(vg.get('profile'))}; enabled charts: {_esc(len(vg.get('calculated',[])))}.<br/>Yogini starting reference: {_esc(yg.get('starting_yogini'))}; active: {_esc((yg.get('active') or {}).get('yogini'))} / {_esc((yg.get('active') or {}).get('lord'))}.",body))
    for x in (sh.get('rows') or [])[:9]:
        comps=', '.join(f"{k} {v}" for k,v in (x.get('components') or {}).items())
        story.append(Paragraph(f"• <b>{_esc(x.get('planet'))}: {_esc(x.get('index'))}/100</b> — {_esc(comps)}",body))
    story.append(Paragraph('18. Method & Safety Boundary',h2))
    v11=chart.get('vashist_v11',{}) or {}
    if v11:
        story.append(PageBreak())
        story.append(Paragraph('13. V11 Vashist Source Intelligence',h2))
        lm=v11.get('luck_meter',{}) or {}
        story.append(Paragraph('Luck Meter: '+_esc(lm.get('score','—'))+'/100 — '+_esc(lm.get('band','')),body))
        pd=v11.get('problem_detector',{}) or {}
        for x in (pd.get('top_attention') or [])[:6]:
            story.append(Paragraph('• '+_esc(x.get('planet'))+' H'+_esc(x.get('house'))+' attention '+_esc(x.get('attention_score'))+'/100 — '+_esc(x.get('house_theme','')),body))
        story.append(Spacer(1,4*mm))
        story.append(Paragraph('Source-aware remedy records are paraphrased, linked to public Astroscience/GD Vashist sources where applicable, and are not an official reproduction of proprietary Vashist Jyotish rules, paid files, books or video transcripts.',body))
    sv12=chart.get('sumitacharya_v12',{}) or {}
    if sv12:
        story.append(PageBreak())
        story.append(Paragraph('14. V12 Shri Sumitacharya Public-Source Intelligence',h2))
        story.append(Paragraph('Independent research layer inspired by the public breadth of Sumitacharya.in services: detailed Kundali, multi-year life areas, marriage matching, business/Vastu, graha/dosha review and remedies. It does not copy paid reports, consultations, protected article text or video transcripts.',body))
        ds=sv12.get('dosha_research',{}) or {}
        for x in (ds.get('top_attention') or [])[:4]:
            story.append(Paragraph('• <b>'+_esc(x.get('label'))+': '+_esc(x.get('status'))+'</b> — '+_esc('; '.join(x.get('evidence') or [])),body))
        bn=sv12.get('baby_name',{}) or {}
        story.append(Paragraph('Traditional naming aid: '+_esc(bn.get('nakshatra'))+' pada '+_esc(bn.get('pada'))+' → starting sound '+_esc(bn.get('traditional_starting_sound','—'))+'.',body))
        rp=sv12.get('report_108',{}) or {}
        story.append(Paragraph('108-Insight Builder: '+_esc(rp.get('total_insights',108))+' independent insight slots; this is not a copy of a paid 108-page report.',body))
    story.append(Paragraph('Calculated astronomy, traditional source/reference rules, public-source references, software synthesis scores and AI explanation are separate layers. Event-theme scores and compatibility indexes are not probabilities; rectification is exploratory; the Smart Remedy Protocol is a prioritization tool, not proof of causation.<br/><br/>'+_esc(chart.get('disclaimer','')),body))
    doc.build(story);pdf=buf.getvalue()
    return Response(content=pdf,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename=lal-kitab-ai-pro-v18-premium-report.pdf'})


def _v18_report_font():
    for f in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']:
        if os.path.exists(f):
            try:
                pdfmetrics.registerFont(TTFont('V18ReportFont',f)); return 'V18ReportFont'
            except Exception: pass
    return 'Helvetica'

def _v18_report_pages(chart:Dict, report_type:str='full') -> tuple[int,List[Dict]]:
    target={'quick':12,'prediction':30,'full':100,'remedy':15,'business':20,'marriage':20}.get(report_type,100)
    items=[]
    # Planet passport
    for p in chart.get('placements',[])[:9]:
        items.append({'title':f"Planet Passport — {p.get('planet')}",'body':f"Lal Kitab house H{p.get('house')} • sign {p.get('sign','—')} • software strength {p.get('score','—')}/100 • status {', '.join(map(str,p.get('status') or [])) or '—'}. This page is a structured chart interpretation, not a guaranteed event claim."})
    # Houses
    for h in chart.get('houses',[])[:12]:
        items.append({'title':f"House {h.get('house')} — {h.get('meaning','Life Area')}",'body':f"House theme: {h.get('meaning','—')}. Occupants: {', '.join(h.get('planets',[]) or []) or 'none listed'}. Review this house together with Dasha, transits, Vargas and the selected Lal Kitab rule profile rather than reading it in isolation."})
    # Vargas
    try:
        vg=shodashavarga_full(chart)
        for v in vg.get('calculated',[])[:16]:
            items.append({'title':f"Varga {v.get('code',v.get('name',''))} — {v.get('name','Divisional Chart')}",'body':f"Divisional-chart research page. Use this chart as a supporting lens with D1 and timing layers. Software profile: {vg.get('profile','—')}. Varga interpretation is kept separate from Lal Kitab fixed-house logic."})
    except Exception: pass
    # Dasha levels
    try:
        dp=vimshottari_full(chart)
        for d in dp.get('active_chain',[])[:4]:
            items.append({'title':f"Active {d.get('level')} — {d.get('lord')}",'body':f"Period {d.get('start')} → {d.get('end')} • natal support {d.get('natal_score','—')}/100 • Lal Kitab H{d.get('lal_kitab_house','—')}. Focus: {d.get('focus','—')}. Support: {d.get('support','—')}. Watch: {d.get('watch','—')}."})
    except Exception: pass
    # 16 domains
    try:
        fp=full_prediction_studio(chart,years=10)
        for d in fp.get('domains',[])[:16]:
            items.append({'title':f"Prediction Domain — {d.get('label')}",'body':f"Current emphasis {d.get('current_score','—')}/100 — {d.get('band','—')}. {d.get('narrative','')} Practical lens: {d.get('practical','')}. Supporting and caution evidence should be read together."})
        for m in fp.get('next_12_months',[])[:12]:
            items.append({'title':f"12-Month Roadmap — {m.get('month',m.get('label','Month'))}",'body':f"Monthly focus snapshot: {m.get('focus',m.get('theme',''))}. Score/index: {m.get('score','—')}. This is a planning emphasis window, not an event guarantee."})
        for y in (fp.get('next_years',[]) or [])[:10]:
            items.append({'title':f"Year Roadmap — {y.get('year')}",'body':f"Annual emphasis snapshot. Stronger areas: {', '.join(str(x.get('label',x)) for x in (y.get('top') or [])[:3]) or '—'}. Watch areas: {', '.join(str(x.get('label',x)) for x in (y.get('watch') or [])[:2]) or '—'}."})
    except Exception: pass
    # Event radar
    try:
        er=event_radar(chart,5)
        for e in er.get('top_windows',[])[:12]:
            items.append({'title':f"Event Radar — {e.get('year')} {e.get('label')}",'body':f"Support index {e.get('score')}/100 — {e.get('band')}. Verification question: {e.get('verification_question','—')}. Treat this as an astrology planning signal rather than certainty."})
    except Exception: pass
    # Remedies
    try:
        rp=remedy_priority_plan(chart,primary_limit=3)
        for i,r in enumerate(rp.get('primary',[])[:3],1):
            items.append({'title':f"Priority Remedy {i} — {r.get('planet','')}",'body':f"{r.get('action','')}. Why selected: {r.get('why_selected','')}. Follow safety, practicality and conflict checks; do not use astrology remedies in place of medical, legal or financial professional care."})
    except Exception: pass
    # Council/source compare
    try:
        ac=astro_council(chart)
        for a in ac.get('agents',[]):
            items.append({'title':f"Astro Council — {a.get('agent')}",'body':f"Council score {a.get('score')}/100 — {a.get('stance')}. Why: {a.get('why')}. Independent layers remain visible so disagreement is not hidden."})
        sc=source_conflict_viewer(chart,5)
        for r in sc.get('rows',[])[:10]:
            items.append({'title':f"Source Compare — {r.get('label')}",'body':f"Core {r.get('core')} • GD Vashist public-source layer {r.get('vashist_public_layer')} • Sumitacharya public-source layer {r.get('sumitacharya_public_layer')} • spread {r.get('spread')} — {r.get('status')}."})
    except Exception: pass
    # 25-year chain provides enough unique pages for 100-page full report
    try:
        lc=luck_chain(chart,25)
        for r in lc.get('years',[]):
            items.append({'title':f"25-Year Luck Chain — {r.get('year')}",'body':f"Interpretive support index {r.get('score')}/100 — {r.get('band')} • momentum {r.get('momentum','—')} • state {r.get('chain_state','—')}. This is an independently computed software visualization, not a proprietary practitioner algorithm."})
    except Exception: pass
    # Dosha research
    try:
        dr=dosha_research_scanner(chart)
        for x in dr.get('flags',[])[:8]:
            items.append({'title':f"Dosha Research — {x.get('label')}",'body':f"Status: {x.get('status')}. Evidence: {'; '.join(x.get('evidence') or [])}. {x.get('note','')} This is a conservative research flag, not a deterministic verdict."})
    except Exception: pass
    # Fill to requested count - cover is page 1, content pages target-1
    needed=max(1,target-1)
    if not items:
        items=[{'title':'Chart Research Note','body':'No detailed data available for this section.'}]
    base=list(items); i=0
    while len(items)<needed:
        x=base[i%len(base)]
        items.append({'title':f"Research Cross-Check {len(items)+1} — {x['title']}",'body':x['body']+' Cross-check this observation against active timing, source separation and real-life context before acting.'})
        i+=1
    return target,items[:needed]

@app.post('/api/v18/report.pdf')
def v18_report_pdf(data:V18ReportInput):
    chart=data.chart; rtype=(data.report_type or 'full').lower()
    if rtype in ('full','professional'):
        pdf=build_professional_pdf(chart,asset_dir=str(BASE_DIR))
        return Response(content=pdf,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename=lal-kitab-ai-pro-v18-1-professional-kundli.pdf'})
    pages,items=_v18_report_pages(chart,rtype)
    buf=io.BytesIO(); font=_v18_report_font()
    doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=17*mm,leftMargin=17*mm,topMargin=18*mm,bottomMargin=16*mm)
    title=ParagraphStyle('v18title',fontName=font,fontSize=23,leading=28,textColor=colors.HexColor('#9A6A19'),spaceAfter=8*mm)
    h=ParagraphStyle('v18h',fontName=font,fontSize=16,leading=21,textColor=colors.HexColor('#8B5E16'),spaceAfter=5*mm)
    body=ParagraphStyle('v18body',fontName=font,fontSize=10.5,leading=16,textColor=colors.HexColor('#222222'),spaceAfter=4*mm)
    small=ParagraphStyle('v18small',fontName=font,fontSize=8.5,leading=12,textColor=colors.HexColor('#555555'))
    story=[Paragraph('Lal Kitab AI PRO — Enterprise Intelligence OS v18',title),
           Paragraph(_esc((chart.get('profile') or {}).get('name','Client'))+' • '+_esc((chart.get('profile') or {}).get('birth_date',''))+' '+_esc((chart.get('profile') or {}).get('birth_time',''))+' • '+_esc((chart.get('profile') or {}).get('city','')),body),
           Spacer(1,8*mm),Paragraph(f'{pages}-Page {rtype.title()} Research Report',h),
           Paragraph('Includes Kundli structure, timing, prediction domains, event radar, remedies, source comparison and explainability. Astrology outputs are interpretive guidance, not guarantees or substitutes for qualified medical, legal or financial advice.',body),
           Spacer(1,12*mm),Paragraph('Generated by V18 Reports & Print Center',small),PageBreak()]
    for idx,item in enumerate(items,2):
        story.append(Paragraph(f"Page {idx} of {pages}",small))
        story.append(Spacer(1,5*mm))
        story.append(Paragraph(_esc(item.get('title')),h))
        story.append(Paragraph(_esc(item.get('body')),body))
        story.append(Spacer(1,8*mm))
        story.append(Paragraph('Evidence discipline: calculated placements, traditional/reference rules, public-source summaries, software synthesis and AI narrative remain distinct layers.',small))
        if idx<pages: story.append(PageBreak())
    doc.build(story)
    pdf=buf.getvalue()
    return Response(content=pdf,media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename=lal-kitab-ai-pro-v18-{rtype}-{pages}p.pdf'})

app.mount('/static',StaticFiles(directory=str(STATIC_DIR)),name='static')
@app.get('/')
def home():return FileResponse(STATIC_DIR/'index.html')

if __name__=='__main__':
    import uvicorn
    uvicorn.run('app:app',host='0.0.0.0',port=int(os.getenv('PORT','8000')),reload=False)
