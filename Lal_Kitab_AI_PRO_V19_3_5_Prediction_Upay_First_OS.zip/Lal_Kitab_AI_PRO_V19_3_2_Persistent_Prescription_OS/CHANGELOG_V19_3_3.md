# V19.3.3 — Prediction Correction + Canonical Source Registry

- Preserves V19.3.1 source grounding and V19.3.2 persistence.
- Corrects user-facing prediction ordering to use active Vimshottari timing over natal/Lal-Kitab evidence.
- Experimental annual rotation / birthday-comparison removed from PRIMARY current-domain score; retained as research-only.
- Static prediction rows preserved under `predictions_static_research`.
- Current timing synthesis exposed under `current_prediction_studio`.
- Remedy plan re-ranked after current prediction synthesis.
- Added canonical 1939/1940/1941/1942/1952 source registry with A_CANDIDATE vs verified attribution guard.
- B.M. Goswami/Vashisth kept as later 1952-based explanatory source, not original-tier authority.
