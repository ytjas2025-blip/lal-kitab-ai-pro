# V19.3.4 — Source Consensus & Provenance Guard

- Preserves V19.3.1 source grounding, V19.3.2 persistence and V19.3.3 prediction correction.
- Expanded source registry with provenance/integrity references for 1941/1952 and bibliographic cross-checks.
- Added provenance_group so mirrors from the same scan/publication family cannot inflate consensus.
- Added Source Consensus Engine with agreement, conflict and provisional states.
- A_VERIFIED still requires exact page/image verification; A_CANDIDATE does not count as verified primary evidence.
- SOURCE_CONFLICT is returned when meaningful independent evidence disagrees.
- Added GET /api/v19.3.4/source-registry and POST /api/v19.3.4/source-consensus.
- Source weights are evidence-support rankings, not scientific probabilities.
