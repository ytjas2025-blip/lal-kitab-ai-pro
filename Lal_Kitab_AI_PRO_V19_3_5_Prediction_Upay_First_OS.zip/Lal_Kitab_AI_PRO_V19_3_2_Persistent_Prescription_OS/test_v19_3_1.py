from upay_intelligence_v19_3_1 import upay_intelligence, catalog_stats
from app import health

chart={
 'placements':[{'planet':p,'house':h} for p,h in {'Sun':9,'Moon':3,'Mars':9,'Mercury':9,'Jupiter':8,'Venus':10,'Saturn':2,'Rahu':4,'Ketu':10}.items()],
 'remedy_plan':{'primary':[{'planet':'Saturn'}]},
 'critical_alert_center':{'alerts':[{'evidence':['Saturn pressure','Rahu paperwork']}]} }

assert health()['version'] in {'19.3.1','19.3.2','19.3.3','19.3.4','19.3.5'}  # cumulative version compatibility
assert catalog_stats()['total']>=143
r=upay_intelligence(chart,'money',{'zeroOnly':True,'noRiver':True,'noFamilyContact':True})
assert r['version']=='19.3.1'
assert r['conflict_guard']['status']=='ON'
assert r['prescription']['must_do']
assert r['prescription']['must_do']['cost'].startswith('₹0')
assert len(r['prescription']['alternatives'])<=2
assert 'why_selected' in r['prescription']['must_do']
print('V19.3.1 PASS', r['prescription']['must_do']['title'], catalog_stats()['total'])
