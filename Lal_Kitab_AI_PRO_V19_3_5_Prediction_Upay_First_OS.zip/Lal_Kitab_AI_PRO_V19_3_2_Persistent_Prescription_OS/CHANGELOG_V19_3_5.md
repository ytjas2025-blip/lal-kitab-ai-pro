# V19.3.5 — Prediction + Upay First OS

- Replaces the first/home experience with an asynchronous current-action briefing.
- The first screen now answers: strongest current prediction, main area to manage, active Dasha chain, and selected Upay / No Remedy Needed.
- Home uses `/api/v10/full-predictions` directly instead of stale dashboard snapshots.
- Upay is generated from the current chart concern via the V19.3.1 source-grounded remedy engine.
- The remedy engine is explicitly allowed to return No Remedy Needed; no forced remedy.
- Prediction cards expose current score, band, base score, Dasha adjustment, confidence, narrative, and practical action.
- Adds direct routes to 15-day radar, 16-area predictions, 12-month/5-year forecast, full Upay, and Kundli.
- V19.3.1 source stack, V19.3.2 persistence, V19.3.3 prediction correction, and V19.3.4 consensus/provenance guard remain intact.
