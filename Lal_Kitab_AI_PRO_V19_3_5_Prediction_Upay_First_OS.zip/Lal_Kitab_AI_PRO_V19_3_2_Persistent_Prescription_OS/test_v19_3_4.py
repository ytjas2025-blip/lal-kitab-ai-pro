from app import BirthInput, _chart_from_model
from upay_intelligence_v19_3_1 import SOURCE_REGISTRY, SOURCE_REGISTRY_POLICY
from source_consensus_v19_3_4 import consensus

chart=_chart_from_model(BirthInput(**{
    "name":"Jasmeet Singh Bawa","birth_date":"1989-07-20","birth_time":"15:07:30",
    "city":"Ludhiana","latitude":30.901,"longitude":75.8573,"timezone_offset":5.5,
    "rule_profile":"1940-foundation"
}))
houses={p["planet"]:p["house"] for p in chart["placements"]}
assert houses=={"Sun":9,"Moon":3,"Mars":9,"Mercury":9,"Jupiter":8,"Venus":10,"Saturn":2,"Rahu":4,"Ketu":10}, houses
assert SOURCE_REGISTRY_POLICY["independence_guard"]
assert any(x["id"]=="lk1952_hindi_provenance" and x["status"]=="INCOMPLETE_COPY_WARNING" for x in SOURCE_REGISTRY)
# Same provenance family must de-duplicate.
r=consensus("demo",[
 {"source_id":"lk1941_archive","claim":"rule A"},
 {"source_id":"lk1941_archive_page","claim":"rule A"},
 {"source_id":"lk1941_proverbs","claim":"rule A"},
],SOURCE_REGISTRY)
assert r["independent_provenance_groups"]==1, r
assert r["status"]=="PROVISIONAL", r
# Candidate mirrors cannot manufacture HIGH confidence.
r2=consensus("demo2",[
 {"source_id":"lk1941_archive","claim":"rule A"},
 {"source_id":"lk1952_rahnuma","claim":"rule A"},
],SOURCE_REGISTRY)
assert r2["confidence"] in {"MEDIUM","LOW_MEDIUM"}, r2
print("V19.3.4 PASS", len(SOURCE_REGISTRY), r["status"], r2["status"])
