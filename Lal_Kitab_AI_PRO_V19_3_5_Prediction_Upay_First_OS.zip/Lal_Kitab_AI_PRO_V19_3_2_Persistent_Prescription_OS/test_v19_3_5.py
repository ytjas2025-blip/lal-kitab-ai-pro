from pathlib import Path
from engine import chart_payload
from app import _full_enrich
from prediction_v10 import full_prediction_studio
from upay_intelligence_v19_3_1 import upay_intelligence

birth={'name':'Jasmeet Singh Bawa','birth_date':'1989-07-20','birth_time':'15:07:30','city':'Ludhiana','timezone_offset':5.5,'latitude':30.901,'longitude':75.8573,'rule_profile':'1940-foundation'}
chart=_full_enrich(chart_payload(birth),years=12)
expected={'Sun':9,'Moon':3,'Mars':9,'Mercury':9,'Jupiter':8,'Venus':10,'Saturn':2,'Rahu':4,'Ketu':10}
got={x['planet']:x['house'] for x in chart['placements'] if x['planet'] in expected}
assert got==expected,(got,expected)

pred=full_prediction_studio(chart,years=5)
chain=[(x['level'],x['lord']) for x in pred['active_dasha']['active_chain']]
assert len(chain)==4
assert pred['domains'] and all('current_score' in x for x in pred['domains'])
concern=(pred.get('watch') or pred.get('strongest'))[0]['label']
up=upay_intelligence(chart,concern,{},24)
assert up.get('prescription',{}).get('must_do') is not None

ui=Path('static/index.html').read_text()
for token in ['What should I do now?','STRONGEST CURRENT PREDICTION','MAIN AREA TO MANAGE','Upay Decision','NO REMEDY NEEDED','renderActionBriefing']:
    assert token in ui, token
print('V19.3.5 PASS', chain, concern, up['prescription']['must_do']['title'])
