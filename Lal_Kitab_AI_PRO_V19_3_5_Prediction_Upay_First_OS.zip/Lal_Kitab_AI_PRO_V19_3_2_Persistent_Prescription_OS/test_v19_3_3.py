from app import BirthInput, _chart_from_model
from upay_intelligence_v19_3_1 import SOURCE_REGISTRY, SOURCE_REGISTRY_POLICY

chart=_chart_from_model(BirthInput(**{
    "name":"Jasmeet Singh Bawa","birth_date":"1989-07-20","birth_time":"15:07:30",
    "city":"Ludhiana","latitude":30.901,"longitude":75.8573,"timezone_offset":5.5,
    "rule_profile":"1940-foundation"
}))
# Calculation lock
houses={p["planet"]:p["house"] for p in chart["placements"]}
assert houses=={"Sun":9,"Moon":3,"Mars":9,"Mercury":9,"Jupiter":8,"Venus":10,"Saturn":2,"Rahu":4,"Ketu":10}, houses
# Current prediction must be dasha-aware and static rows retained for audit.
assert chart.get("current_prediction_studio",{}).get("active_dasha")
assert chart.get("predictions_static_research")
assert chart.get("predictions")
assert all("current_score" in x for x in chart["predictions"])
# Source registry must never pre-promote candidates to verified.
assert any(x["edition_year"]==1941 and x["tier"]=="A_CANDIDATE" for x in SOURCE_REGISTRY)
assert any(x["edition_year"]==1952 and x["tier"]=="A_CANDIDATE" for x in SOURCE_REGISTRY)
assert SOURCE_REGISTRY_POLICY["A_VERIFIED_rule"]
print("V19.3.3 PASS", chart["current_prediction_studio"]["as_of"], len(SOURCE_REGISTRY))
