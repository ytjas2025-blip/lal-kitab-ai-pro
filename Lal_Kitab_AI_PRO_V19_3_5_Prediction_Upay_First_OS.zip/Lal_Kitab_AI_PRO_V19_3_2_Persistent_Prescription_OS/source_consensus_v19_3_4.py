from __future__ import annotations

"""V19.3.4 Source Consensus Engine.

It scores evidence quality and provenance independence, not truth probability.
Mirrors from the same underlying scan/publication family are de-duplicated.
"""
from typing import Any, Dict, List

TIER_WEIGHT={
    "A_VERIFIED":1.00,"A_CANDIDATE":0.72,"B":0.62,"B_REFERENCE":0.48,
    "C":0.34,"D":0.20,"E":0.10,
}
VERIFY_FACTOR={
    "PAGE_VERIFIED":1.00,"EXACT_PAGE_IMAGE_VERIFIED":1.00,"VERIFIED":0.95,
    "PAGE_VERIFICATION_REQUIRED":0.72,"ARCHIVAL_SOURCE":0.70,
    "ORIGINAL_VS_TRANSLITERATION_COMPARISON":0.62,"CROSS_CHECK_ONLY":0.45,
    "SUPPORTING":0.45,"SECONDARY_REFERENCE_PAGE_MAPPING_REQUIRED":0.40,
    "1952_BASED_SECONDARY_CONFIRMED":0.38,"SERIES_STRUCTURE_REFERENCE":0.25,
    "INCOMPLETE_COPY_WARNING":0.18,"ERRORS_POSSIBLE_SEARCH_AID_ONLY":0.15,
}

def _claim_key(value: Any)->str:
    if isinstance(value,(dict,list,tuple)):
        import json
        return json.dumps(value,sort_keys=True,ensure_ascii=False)
    return str(value).strip().lower()

def consensus(rule_id:str, evidence:List[Dict[str,Any]], registry:List[Dict[str,Any]])->Dict[str,Any]:
    by_id={x.get("id"):x for x in registry}
    groups={}
    rejected=[]
    for ev in evidence:
        sid=ev.get("source_id")
        src=by_id.get(sid)
        if not src:
            rejected.append({"source_id":sid,"reason":"UNKNOWN_SOURCE"}); continue
        claim=_claim_key(ev.get("claim"))
        if not claim:
            rejected.append({"source_id":sid,"reason":"EMPTY_CLAIM"}); continue
        prov=src.get("provenance_group") or sid
        w=TIER_WEIGHT.get(src.get("tier"),0.1)*VERIFY_FACTOR.get(ev.get("verification_status") or src.get("status"),0.30)
        # Keep strongest observation per provenance family so mirrors do not vote twice.
        cur=groups.get(prov)
        row={"source_id":sid,"provenance_group":prov,"claim":ev.get("claim"),"claim_key":claim,"weight":round(w,4),"tier":src.get("tier"),"verification_status":ev.get("verification_status") or src.get("status"),"page":ev.get("page"),"note":ev.get("note","")}
        if cur is None or row["weight"]>cur["weight"]:
            groups[prov]=row
    unique=list(groups.values())
    buckets={}
    for row in unique:
        b=buckets.setdefault(row["claim_key"],{"claim":row["claim"],"weight":0.0,"groups":[]})
        b["weight"]+=row["weight"]; b["groups"].append(row["provenance_group"])
    ranked=sorted(buckets.values(),key=lambda x:x["weight"],reverse=True)
    total=sum(x["weight"] for x in ranked) or 0.0
    top=ranked[0] if ranked else None
    verified_groups=sum(1 for x in unique if x["tier"]=="A_VERIFIED" and x["verification_status"] in {"PAGE_VERIFIED","EXACT_PAGE_IMAGE_VERIFIED","VERIFIED"})
    conflict=len(ranked)>1 and ranked[1]["weight"]>=max(0.25,(top["weight"] if top else 0)*0.55)
    if not top:
        status="NO_EVIDENCE"; confidence="NONE"
    elif conflict:
        status="SOURCE_CONFLICT"; confidence="CONFLICTED"
    elif verified_groups>=2 and len(top["groups"])>=2:
        status="STRONG_CONSENSUS"; confidence="HIGH"
    elif verified_groups>=1:
        status="VERIFIED_SUPPORT"; confidence="MEDIUM_HIGH"
    elif len(top["groups"])>=2 and top["weight"]>=1.0:
        status="CROSS_SOURCE_SUPPORT"; confidence="MEDIUM"
    else:
        status="PROVISIONAL"; confidence="LOW_MEDIUM"
    return {
        "version":"19.3.4", "rule_id":rule_id, "status":status, "confidence":confidence,
        "winning_claim":None if conflict or not top else top["claim"],
        "agreement_share":round((top["weight"]/total),3) if top and total else 0.0,
        "independent_provenance_groups":len(unique), "verified_primary_groups":verified_groups,
        "claims":[{"claim":x["claim"],"weight":round(x["weight"],4),"provenance_groups":x["groups"]} for x in ranked],
        "evidence_used":unique,"evidence_rejected":rejected,
        "guard":"Weights rank source support, not scientific probability. Same-family mirrors are deduplicated; conflicts remain visible.",
    }
