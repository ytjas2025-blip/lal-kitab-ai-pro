# GitHub Upload Guide

This package is prepared for GitHub as **Lal Kitab AI PRO V19.3.1**.

## Recommended repository name

`lal-kitab-ai-pro-v19-3-1`

## Upload from GitHub website

1. Create a new empty GitHub repository.
2. Do not initialize it with another README, `.gitignore`, or license.
3. Extract this ZIP on your computer.
4. Upload the **contents** of the extracted `Lal_Kitab_AI_PRO_V19_3_1_GitHub` folder.
5. Commit the files to the `main` branch.

## Upload with Git

```bash
git init
git branch -M main
git add .
git commit -m "Release Lal Kitab AI PRO V19.3.1"
git remote add origin https://github.com/YOUR_USERNAME/lal-kitab-ai-pro-v19-3-1.git
git push -u origin main
```

## Local setup

```bash
python -m venv .venv
```

Activate the environment, then:

```bash
pip install -r requirements.txt
cp .env.example .env
python app.py
```

Or use the included platform launcher.

## Security note

Do not commit `.env`, API keys, local SQLite databases, or generated runtime files. They are excluded by `.gitignore`.
