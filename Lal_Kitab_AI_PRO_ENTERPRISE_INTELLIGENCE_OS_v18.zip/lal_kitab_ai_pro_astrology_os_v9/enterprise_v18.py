from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from prediction_pro import forecast_year, event_windows_for_year
from prediction_v10 import vimshottari_full, full_prediction_studio
from astro_v8 import monthly_focus, transit_snapshot
from vashist_v11 import luck_meter, luck_chain, category_prediction_pack
from sumitacharya_v12 import deep_prediction_studio as sumit_deep_prediction_studio, dosha_research_scanner
from remedies import remedy_priority_plan, vashist_source_recommended, sumitacharya_source_recommended

DOMAIN_TO_CATEGORY = {
    'career':'occupation','business':'business','money':'wealth','relationships':'married_life',
    'family':'children_family','property':'property_vehicle','travel_foreign':'foreign','learning':'education',
    'reputation':'public_status','leadership':'public_status','network':'business','creativity':'education',
}


def _n(v, default=50.0):
    try: return float(v)
    except Exception: return float(default)


def _band(score: float) -> str:
    if score >= 70: return 'Strong support'
    if score >= 60: return 'Supportive'
    if score >= 48: return 'Mixed / verify'
    return 'Protect basics / higher friction'


def _active_dasha(chart: Dict) -> List[Dict]:
    try: return vimshottari_full(chart).get('active_chain', [])
    except Exception: return []


def forecast_horizons(chart: Dict) -> Dict:
    now = datetime.now()
    fp = full_prediction_studio(chart, years=5)
    lm = luck_meter(chart, now.year)
    chain = luck_chain(chart, 25)
    monthly = monthly_focus(chart, now.year)
    months = monthly.get('months', monthly.get('rows', [])) if isinstance(monthly, dict) else []
    current_domains = sorted(fp.get('domains', []), key=lambda x:_n(x.get('current_score')), reverse=True)
    def domain_pick(n=4):
        return [{'key':x.get('key'),'label':x.get('label'),'score':x.get('current_score'),'band':x.get('band')} for x in current_domains[:n]]
    next_years = fp.get('next_years', []) or []
    return {
        'today': {'label':'Now','score':lm.get('score',50),'band':lm.get('band'),'top':domain_pick(4),
                  'note':'Current chart + active Dasha + annual evidence snapshot.'},
        'next_30_days': {'label':'Next 30 Days','months':months[:2], 'top':domain_pick(4),
                         'note':'Monthly-focus layer; not a day-by-day certainty model.'},
        'next_12_months': {'label':'Next 12 Months','months':fp.get('next_12_months',[])[:12], 'top':domain_pick(5)},
        'next_5_years': {'label':'Next 5 Years','years':next_years[:5]},
        'next_10_years': {'label':'Next 10 Years','years':chain.get('years',[])[:10], 'best':chain.get('best',[])[:3], 'watch':chain.get('watch',[])[:3]},
        'next_25_years': {'label':'Next 25 Years','years':chain.get('years',[])[:25], 'best':chain.get('best',[])[:5], 'watch':chain.get('watch',[])[:5]},
        'active_dasha': _active_dasha(chart),
        'certainty_note':'All scores are interpretive emphasis indexes, not event probabilities or guarantees.'
    }


def event_radar(chart: Dict, years: int=5) -> Dict:
    y0=datetime.now().year
    rows=[]
    for y in range(y0, y0+max(1,min(int(years),10))):
        ev=event_windows_for_year(chart,y)
        for item in (ev.get('top_windows') or ev.get('windows') or []):
            rows.append({
                'year':y,'key':item.get('key'),'label':item.get('label'),'score':_n(item.get('score')),
                'band':item.get('band') or _band(_n(item.get('score'))),
                'verification_question':item.get('verification_question',''),
                'evidence':item.get('evidence',[])[:5] if isinstance(item.get('evidence'),list) else []
            })
    rows=sorted(rows,key=lambda x:x['score'],reverse=True)
    return {
        'years':years,
        'top_windows':rows[:24],
        'strong_windows':[x for x in rows if x['score']>=68][:16],
        'watch_windows':sorted(rows,key=lambda x:x['score'])[:12],
        'note':'Radar highlights higher/lower astrology-support periods for planning and verification; it does not guarantee an event.'
    }


def source_conflict_viewer(chart: Dict, horizon: int=5) -> Dict:
    core=full_prediction_studio(chart,years=max(1,min(horizon,10)))
    vash=category_prediction_pack(chart,max(2,min(horizon,25)))
    sumit=sumit_deep_prediction_studio(chart,max(1,min(horizon,10)))
    vcat=vash.get('categories',{})
    sdom={x.get('key'):x for x in sumit.get('domains',[])}
    rows=[]
    for c in core.get('domains',[]):
        key=c.get('key'); core_score=_n(c.get('current_score'))
        cat=DOMAIN_TO_CATEGORY.get(key)
        vscore=_n(((vcat.get(cat) or {}).get('current') or {}).get('score'),core_score) if cat else core_score
        sscore=_n((sdom.get(key) or {}).get('current_score'),core_score)
        vals=[core_score,vscore,sscore]; spread=max(vals)-min(vals)
        rows.append({
            'key':key,'label':c.get('label',key),'core':round(core_score,1),'vashist_public_layer':round(vscore,1),
            'sumitacharya_public_layer':round(sscore,1),'spread':round(spread,1),
            'status':'Material disagreement' if spread>=18 else 'Some disagreement' if spread>=10 else 'Broad agreement',
            'core_narrative':c.get('narrative','')
        })
    rows.sort(key=lambda x:x['spread'],reverse=True)
    return {
        'rows':rows,'material_conflicts':[x for x in rows if x['spread']>=18],
        'agreement':[x for x in rows if x['spread']<10],
        'note':'These are independent software/source-reference layers. Practitioner public-source layers are not treated as proprietary algorithms or scientific validation.'
    }


def astro_council(chart: Dict, year: Optional[int]=None) -> Dict:
    y=year or datetime.now().year
    fy=forecast_year(chart,y)
    domains=fy.get('domains',{}) or {}
    domain_scores=[_n(v.get('score')) for v in domains.values()]
    core=sum(domain_scores)/max(1,len(domain_scores))
    dasha=_active_dasha(chart)
    if dasha:
        dw=sum(_n(x.get('weight'),1) for x in dasha) or 1
        dasha_score=sum(_n(x.get('natal_score'))*_n(x.get('weight'),1) for x in dasha)/dw
    else:dasha_score=50
    lm=luck_meter(chart,y)
    try:
        tr=transit_snapshot(chart)
        trows=tr.get('transits',tr.get('rows',[])) if isinstance(tr,dict) else []
        tvals=[_n(x.get('score',50)) for x in trows if isinstance(x,dict)]
        transit_score=sum(tvals)/len(tvals) if tvals else 50
    except Exception: transit_score=50
    sumit=sumit_deep_prediction_studio(chart,1)
    svals=[_n(x.get('current_score')) for x in sumit.get('domains',[])]
    sumit_score=sum(svals)/max(1,len(svals))
    agents=[
        {'agent':'Lal Kitab / Core Forecast','score':round(core,1),'stance':_band(core),'why':'Annual domain synthesis + house-cycle evidence.'},
        {'agent':'Vimshottari Timing','score':round(dasha_score,1),'stance':_band(dasha_score),'why':'Weighted active Mahadasha→Sookshma natal support.'},
        {'agent':'Transit Agent','score':round(transit_score,1),'stance':_band(transit_score),'why':'Current transit snapshot where available.'},
        {'agent':'GD Vashist Public-Source Layer','score':round(_n(lm.get('score')),1),'stance':lm.get('band') or _band(_n(lm.get('score'))),'why':'Independent house-first/luck-chain software layer.'},
        {'agent':'Sumitacharya Public-Source Layer','score':round(sumit_score,1),'stance':_band(sumit_score),'why':'Independent multi-area Dasha/Varga/source-aware synthesis.'},
    ]
    scores=[x['score'] for x in agents]; consensus=sum(scores)/len(scores); spread=max(scores)-min(scores)
    return {
        'year':y,'agents':agents,'chief_verdict':{'score':round(consensus,1),'band':_band(consensus),'disagreement_spread':round(spread,1),
        'confidence':'Higher convergence' if spread<10 else 'Moderate convergence' if spread<18 else 'Mixed evidence'},
        'minority_opinion':min(agents,key=lambda x:x['score']),
        'strongest_opinion':max(agents,key=lambda x:x['score']),
        'note':'Council keeps independent layers visible. It is an explainability/consensus tool, not proof that astrology predicts outcomes.'
    }


def prediction_change_explainer(chart: Dict, year_a: int, year_b: int) -> Dict:
    a=forecast_year(chart,year_a); b=forecast_year(chart,year_b)
    da=a.get('domains',{}) or {}; db=b.get('domains',{}) or {}
    rows=[]
    for k in sorted(set(da)|set(db)):
        av=_n((da.get(k) or {}).get('score')); bv=_n((db.get(k) or {}).get('score'))
        rows.append({'key':k,'label':(db.get(k) or da.get(k) or {}).get('label',k),'from':round(av,1),'to':round(bv,1),'delta':round(bv-av,1),
                     'direction':'Improves' if bv-av>=5 else 'Cools' if bv-av<=-5 else 'Stable / mixed'})
    rows.sort(key=lambda x:abs(x['delta']),reverse=True)
    return {'year_a':year_a,'year_b':year_b,'changes':rows,'largest_changes':rows[:8],
            'house_cycle_a':a.get('house_cycle'),'house_cycle_b':b.get('house_cycle'),
            'note':'Explains model-score change between annual snapshots; it does not imply a guaranteed real-world change.'}


def living_digital_twin(chart: Dict, profile_context: Optional[Dict]=None) -> Dict:
    fp=full_prediction_studio(chart,years=5)
    domains=sorted(fp.get('domains',[]),key=lambda x:_n(x.get('current_score')),reverse=True)
    council=astro_council(chart)
    conflict=source_conflict_viewer(chart,5)
    remedies=remedy_priority_plan(chart,primary_limit=3)
    source_upay=(vashist_source_recommended(chart,limit=5) or [])[:5] + (sumitacharya_source_recommended(chart,limit=5) or [])[:5]
    history=profile_context or {}
    return {
        'identity':{'name':(chart.get('profile') or {}).get('name'),'birth_date':(chart.get('profile') or {}).get('birth_date'),'birth_time':(chart.get('profile') or {}).get('birth_time'),'city':(chart.get('profile') or {}).get('city')},
        'active_dasha':_active_dasha(chart),
        'strongest_domains':domains[:5], 'watch_domains':list(reversed(domains[-5:])),
        'chief_council':council.get('chief_verdict'),
        'source_conflicts':conflict.get('material_conflicts',[])[:6],
        'primary_remedies':remedies.get('primary',[])[:3], 'source_upay':source_upay,
        'history':history,
        'calibration_state':{
            'outcomes_logged':history.get('outcomes_logged',0),'hit_rate_label':history.get('hit_rate_label','No outcome history yet'),
            'personalization':'History-aware' if history.get('outcomes_logged',0)>=5 else 'Chart-first / needs more outcome history'
        },
        'note':'Digital Twin stores a living astrology workspace. Outcome logs personalize record-keeping and weighting experiments; they do not scientifically validate astrology.'
    }


def report_center_catalog() -> Dict:
    return {
        'reports':[
            {'id':'quick','title':'Quick Consultation Report','pages':'8–15','sections':['Birth','Dasha','Top Predictions','Top Remedies']},
            {'id':'prediction','title':'Prediction Intelligence Report','pages':'25–40','sections':['16 Domains','12 Months','5 Years','Event Radar','Source Compare']},
            {'id':'full','title':'Full Research Kundli','pages':'100','sections':['Kundli','Vargas','Dasha','Transits','Predictions','25Y Roadmap','Remedies','Sources','Audit']},
            {'id':'remedy','title':'Remedy Protocol Booklet','pages':'10–20','sections':['Top 3','Source Upay','Conflicts','43-Day Tracker']},
            {'id':'business','title':'Business & Vastu Report','pages':'15–30','sections':['Business Climate','Timing','Partner Lens','Vastu Checklist']},
            {'id':'marriage','title':'Relationship / Marriage Report','pages':'15–30','sections':['Compatibility','Dasha Overlap','Family','Timing','Remedies']},
        ],
        'actions':['Preview','Download PDF','Print','Save to Client','Share summary'],
        'full_report_pages':100,
        'note':'The 100-page report is an original software-generated research report, not a reproduction of any practitioner’s paid report.'
    }


def enterprise_dashboard(chart: Dict, profile_context: Optional[Dict]=None) -> Dict:
    return {
        'version':'18.0.0',
        'digital_twin':living_digital_twin(chart,profile_context),
        'forecast_horizons':forecast_horizons(chart),
        'event_radar':event_radar(chart,5),
        'astro_council':astro_council(chart),
        'source_compare':source_conflict_viewer(chart,5),
        'dosha_research':dosha_research_scanner(chart),
        'reports':report_center_catalog(),
        'feature_note':'V18 Enterprise OS prioritizes explainability, source separation, history-aware case records, long-horizon planning and printable reports.'
    }
