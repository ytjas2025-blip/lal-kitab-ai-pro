# Adaptive Upay research notes

Public web research performed 2026-09-09. Commonly repeated Sun practices included sunrise arghya, Sunday wheat/jaggery/copper charity, mantra/devotional practice, and respect/service toward father/elders/teachers. Sources consulted included AstroSage Lal Kitab Sun house pages and several contemporary public astrology reference pages.

Important boundary: exact Lal Kitab remedy rules can be house- and combination-specific and public websites disagree. The UI therefore labels broad alternatives instead of presenting every alternative as an original Lal Kitab farman. Behavioural substitutes (discipline, mentor/elder respect when father is absent, safe charity, no-pollution substitutions) are explicitly software-derived/safety-normalized, not claimed as verbatim classical prescriptions.

Safety: never force contact with an absent/estranged/unsafe parent; never dump ritual items in rivers; no unsafe animal feeding; no hazardous fire/smoke; no ingestion of metals/unknown substances; no expensive gemstone default; no remedy substitutes for medical/legal/financial care.
