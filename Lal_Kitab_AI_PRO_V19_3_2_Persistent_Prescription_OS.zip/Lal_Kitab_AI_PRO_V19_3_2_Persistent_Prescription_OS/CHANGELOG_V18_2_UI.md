# V18.2 Premium UI Overhaul

- Rebuilt desktop navigation into a persistent research sidebar.
- New premium research workspace header and chart picker.
- Redesigned no-chart hero, loading state, cards, tables, forms and report surfaces.
- Mobile retains slide-out navigation and bottom quick actions.
- Added Calculation Guard visual language and clearer separation of astrology systems.
- No calculation formulas were changed in this UI-only build.
