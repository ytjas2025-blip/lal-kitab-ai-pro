from __future__ import annotations
import json, os, sqlite3, hashlib
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional

BASE_DIR=Path(__file__).resolve().parent
DB_PATH=BASE_DIR/'data'/'lal_kitab_pro.db'
DB_PATH.parent.mkdir(parents=True,exist_ok=True)
DATABASE_URL=os.getenv('DATABASE_URL','').strip()
USE_POSTGRES=DATABASE_URL.startswith('postgres://') or DATABASE_URL.startswith('postgresql://')

class PGCursor:
    def __init__(self, cur):
        self.cur=cur; self.lastrowid=None
    def execute(self, sql, params=()):
        q=sql.replace('?', '%s')
        is_insert=q.lstrip().upper().startswith('INSERT INTO')
        # Every INSERT in this app targets an id-backed table.
        if is_insert and ' RETURNING ' not in q.upper(): q=q.rstrip().rstrip(';')+' RETURNING id'
        self.cur.execute(q, tuple(params) if params is not None else None)
        if is_insert:
            try:
                row=self.cur.fetchone(); self.lastrowid=(row['id'] if isinstance(row,dict) else row[0]) if row else None
            except Exception:
                self.lastrowid=None
        return self
    def executemany(self, sql, seq):
        self.cur.executemany(sql.replace('?', '%s'), seq); return self
    def fetchone(self): return self.cur.fetchone()
    def fetchall(self): return self.cur.fetchall()
    @property
    def rowcount(self): return self.cur.rowcount

class PGConn:
    def __init__(self):
        import psycopg2
        from psycopg2.extras import RealDictCursor
        self.raw=psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor, connect_timeout=10)
    def execute(self,sql,params=()):
        return PGCursor(self.raw.cursor()).execute(sql,params)
    def executemany(self,sql,seq):
        return PGCursor(self.raw.cursor()).executemany(sql,seq)
    def __enter__(self): return self
    def __exit__(self,exc_type,exc,tb):
        try:
            if exc_type is None:self.raw.commit()
            else:self.raw.rollback()
        finally:self.raw.close()
        return False

def conn():
    if USE_POSTGRES:return PGConn()
    c=sqlite3.connect(DB_PATH)
    c.row_factory=sqlite3.Row
    return c

SQLITE_SCHEMA='''
CREATE TABLE IF NOT EXISTS profiles(id INTEGER PRIMARY KEY AUTOINCREMENT,client_uuid TEXT,profile_key TEXT,name TEXT NOT NULL,birth_date TEXT NOT NULL,birth_time TEXT NOT NULL,city TEXT,timezone_offset REAL,latitude REAL,longitude REAL,rule_profile TEXT,notes TEXT,chart_json TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS remedy_programs(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,planet TEXT NOT NULL,remedy TEXT NOT NULL,duration INTEGER NOT NULL DEFAULT 43,start_date TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS remedy_checkins(id INTEGER PRIMARY KEY AUTOINCREMENT,program_id INTEGER NOT NULL,day_no INTEGER NOT NULL,checkin_date TEXT NOT NULL,completed INTEGER NOT NULL DEFAULT 1,note TEXT,created_at TEXT NOT NULL,UNIQUE(program_id,day_no),FOREIGN KEY(program_id) REFERENCES remedy_programs(id));
CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,note TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS prediction_outcomes(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,year INTEGER NOT NULL,domain TEXT NOT NULL,predicted_score REAL,outcome TEXT NOT NULL,note TEXT,created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS followups(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,due_date TEXT NOT NULL,kind TEXT NOT NULL,note TEXT,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS chat_history(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER,mode TEXT NOT NULL,question TEXT NOT NULL,answer TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS consultation_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,title TEXT NOT NULL,summary TEXT,actions TEXT,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS favorite_insights(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,category TEXT NOT NULL,title TEXT NOT NULL,content TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER,appointment_at TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'consultation',fee REAL NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'scheduled',note TEXT,created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER,amount REAL NOT NULL,mode TEXT NOT NULL DEFAULT 'cash',reference TEXT,note TEXT,created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS team_members(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'Astrologer',phone TEXT,email TEXT,status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS profile_meta(profile_id INTEGER PRIMARY KEY,favorite INTEGER NOT NULL DEFAULT 0,tags TEXT NOT NULL DEFAULT '[]',last_opened_at TEXT,FOREIGN KEY(profile_id) REFERENCES profiles(id));
CREATE TABLE IF NOT EXISTS chart_snapshots(id INTEGER PRIMARY KEY AUTOINCREMENT,profile_id INTEGER NOT NULL,chart_json TEXT NOT NULL,reason TEXT NOT NULL DEFAULT 'autosave',created_at TEXT NOT NULL,FOREIGN KEY(profile_id) REFERENCES profiles(id));
'''

PG_SCHEMA='''
CREATE TABLE IF NOT EXISTS profiles(id BIGSERIAL PRIMARY KEY,client_uuid TEXT,profile_key TEXT,name TEXT NOT NULL,birth_date TEXT NOT NULL,birth_time TEXT NOT NULL,city TEXT,timezone_offset DOUBLE PRECISION,latitude DOUBLE PRECISION,longitude DOUBLE PRECISION,rule_profile TEXT,notes TEXT,chart_json TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS remedy_programs(id BIGSERIAL PRIMARY KEY,profile_id BIGINT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,planet TEXT NOT NULL,remedy TEXT NOT NULL,duration INTEGER NOT NULL DEFAULT 43,start_date TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS remedy_checkins(id BIGSERIAL PRIMARY KEY,program_id BIGINT NOT NULL REFERENCES remedy_programs(id) ON DELETE CASCADE,day_no INTEGER NOT NULL,checkin_date TEXT NOT NULL,completed INTEGER NOT NULL DEFAULT 1,note TEXT,created_at TEXT NOT NULL,UNIQUE(program_id,day_no));
CREATE TABLE IF NOT EXISTS notes(id BIGSERIAL PRIMARY KEY,profile_id BIGINT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,note TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS prediction_outcomes(id BIGSERIAL PRIMARY KEY,profile_id BIGINT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,year INTEGER NOT NULL,domain TEXT NOT NULL,predicted_score DOUBLE PRECISION,outcome TEXT NOT NULL,note TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS followups(id BIGSERIAL PRIMARY KEY,profile_id BIGINT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,due_date TEXT NOT NULL,kind TEXT NOT NULL,note TEXT,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS chat_history(id BIGSERIAL PRIMARY KEY,profile_id BIGINT REFERENCES profiles(id) ON DELETE SET NULL,mode TEXT NOT NULL,question TEXT NOT NULL,answer TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS consultation_sessions(id BIGSERIAL PRIMARY KEY,profile_id BIGINT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,title TEXT NOT NULL,summary TEXT,actions TEXT,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS favorite_insights(id BIGSERIAL PRIMARY KEY,profile_id BIGINT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,category TEXT NOT NULL,title TEXT NOT NULL,content TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS appointments(id BIGSERIAL PRIMARY KEY,profile_id BIGINT REFERENCES profiles(id) ON DELETE SET NULL,appointment_at TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'consultation',fee DOUBLE PRECISION NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'scheduled',note TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS payments(id BIGSERIAL PRIMARY KEY,profile_id BIGINT REFERENCES profiles(id) ON DELETE SET NULL,amount DOUBLE PRECISION NOT NULL,mode TEXT NOT NULL DEFAULT 'cash',reference TEXT,note TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS team_members(id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'Astrologer',phone TEXT,email TEXT,status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS profile_meta(profile_id BIGINT PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,favorite INTEGER NOT NULL DEFAULT 0,tags TEXT NOT NULL DEFAULT '[]',last_opened_at TEXT);
CREATE TABLE IF NOT EXISTS chart_snapshots(id BIGSERIAL PRIMARY KEY,profile_id BIGINT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,chart_json TEXT NOT NULL,reason TEXT NOT NULL DEFAULT 'autosave',created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_snapshots_profile ON chart_snapshots(profile_id);
CREATE INDEX IF NOT EXISTS idx_profiles_name ON profiles(lower(name));
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_profile_key ON profiles(profile_key) WHERE profile_key IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_client_uuid ON profiles(client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_remedy_profile ON remedy_programs(profile_id);
CREATE INDEX IF NOT EXISTS idx_outcome_profile ON prediction_outcomes(profile_id);
CREATE INDEX IF NOT EXISTS idx_followup_profile ON followups(profile_id);
'''

def init_db():
    if USE_POSTGRES:
        import psycopg2
        raw=psycopg2.connect(DATABASE_URL, connect_timeout=10)
        try:
            cur=raw.cursor()
            for stmt in [x.strip() for x in PG_SCHEMA.split(';') if x.strip()]:cur.execute(stmt)
            # Safe cumulative migration for databases created before V19.3.2.
            cur.execute('ALTER TABLE profiles ADD COLUMN IF NOT EXISTS client_uuid TEXT')
            cur.execute('ALTER TABLE profiles ADD COLUMN IF NOT EXISTS profile_key TEXT')
            cur.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_profile_key ON profiles(profile_key) WHERE profile_key IS NOT NULL')
            cur.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_client_uuid ON profiles(client_uuid) WHERE client_uuid IS NOT NULL')
            raw.commit()
        finally:raw.close()
    else:
        with conn() as c:
            c.executescript(SQLITE_SCHEMA)
            cols={r['name'] for r in c.execute('PRAGMA table_info(profiles)').fetchall()}
            if 'client_uuid' not in cols:c.execute('ALTER TABLE profiles ADD COLUMN client_uuid TEXT')
            if 'profile_key' not in cols:c.execute('ALTER TABLE profiles ADD COLUMN profile_key TEXT')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_profile_key ON profiles(profile_key) WHERE profile_key IS NOT NULL')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_client_uuid ON profiles(client_uuid) WHERE client_uuid IS NOT NULL')

def deterministic_profile_key(data:Dict[str,Any])->str:
    parts=[data.get('name'),data.get('birth_date'),data.get('birth_time'),data.get('city'),data.get('latitude'),data.get('longitude')]
    canonical='|'.join(str(x or '').strip().lower() for x in parts)
    return hashlib.sha256(canonical.encode('utf-8')).hexdigest()

def storage_status()->Dict[str,Any]:
    try:
        with conn() as c:
            n=c.execute('SELECT COUNT(*) n FROM profiles').fetchone()['n']
        return {'ok':True,'backend':'postgresql' if USE_POSTGRES else 'sqlite','database_connected':True,'persistent':bool(USE_POSTGRES),'persistence_mode':'cloud' if USE_POSTGRES else 'local-development-fallback','profiles':n,'message':'Cloud database connected' if USE_POSTGRES else 'Local SQLite fallback; not persistent across ephemeral server rebuilds'}
    except Exception as e:
        return {'ok':False,'backend':'postgresql' if USE_POSTGRES else 'sqlite','persistent':False,'error':str(e)[:240]}

def rowdict(row):return dict(row) if row else None

def save_profile(data:Dict[str,Any],chart:Dict[str,Any])->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    # Idempotent cloud save: stable client UUID first, deterministic birth key second.
    profile_key=deterministic_profile_key(data); client_uuid=(data.get('client_uuid') or '').strip() or None
    with conn() as c:
        existing=c.execute("SELECT id FROM profiles WHERE (? IS NOT NULL AND client_uuid=?) OR profile_key=? ORDER BY updated_at DESC LIMIT 1",(client_uuid,client_uuid,profile_key)).fetchone()
        if existing:
            pid=existing['id'];c.execute('UPDATE profiles SET client_uuid=COALESCE(?,client_uuid),profile_key=?,timezone_offset=?,latitude=?,longitude=?,rule_profile=?,notes=?,chart_json=?,updated_at=? WHERE id=?',(client_uuid,profile_key,data.get('timezone_offset'),data.get('latitude'),data.get('longitude'),data.get('rule_profile'),data.get('notes',''),json.dumps(chart,ensure_ascii=False),now,pid))
        else:
            cur=c.execute('''INSERT INTO profiles(client_uuid,profile_key,name,birth_date,birth_time,city,timezone_offset,latitude,longitude,rule_profile,notes,chart_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(client_uuid,profile_key,data.get('name'),data.get('birth_date'),data.get('birth_time'),data.get('city'),data.get('timezone_offset'),data.get('latitude'),data.get('longitude'),data.get('rule_profile'),data.get('notes',''),json.dumps(chart,ensure_ascii=False),now,now));pid=cur.lastrowid
        c.execute("INSERT INTO profile_meta(profile_id,favorite,tags,last_opened_at) VALUES(?,?,?,?) ON CONFLICT(profile_id) DO UPDATE SET last_opened_at=excluded.last_opened_at",(pid,0,'[]',now))
        c.execute('INSERT INTO chart_snapshots(profile_id,chart_json,reason,created_at) VALUES(?,?,?,?)',(pid,json.dumps(chart,ensure_ascii=False),'save',now))
    return get_profile(pid)

def list_profiles(search:str='')->List[Dict[str,Any]]:
    q="SELECT p.id,p.name,p.birth_date,p.birth_time,p.city,p.rule_profile,p.created_at,p.updated_at,COALESCE(m.favorite,0) favorite,COALESCE(m.tags,'[]') tags,m.last_opened_at FROM profiles p LEFT JOIN profile_meta m ON m.profile_id=p.id"
    args=[]
    if search:q+=" WHERE lower(p.name) LIKE ? OR lower(COALESCE(p.city,'')) LIKE ? OR lower(COALESCE(m.tags,'')) LIKE ?";needle=f'%{search.lower()}%';args=[needle,needle,needle]
    q+=" ORDER BY COALESCE(m.favorite,0) DESC, COALESCE(m.last_opened_at,p.updated_at) DESC"
    with conn() as c: rows=c.execute(q,args).fetchall()
    out=[]
    for r in rows:
        d=dict(r)
        try:d['tags']=json.loads(d.get('tags') or '[]')
        except:d['tags']=[]
        d['favorite']=bool(d.get('favorite'));out.append(d)
    return out

def get_profile(pid:int)->Optional[Dict[str,Any]]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        r=c.execute("SELECT p.*,COALESCE(m.favorite,0) favorite,COALESCE(m.tags,'[]') tags,m.last_opened_at FROM profiles p LEFT JOIN profile_meta m ON m.profile_id=p.id WHERE p.id=?",(pid,)).fetchone()
        if r:c.execute("INSERT INTO profile_meta(profile_id,favorite,tags,last_opened_at) VALUES(?,?,?,?) ON CONFLICT(profile_id) DO UPDATE SET last_opened_at=excluded.last_opened_at",(pid,0,'[]',now))
    if not r:return None
    d=dict(r);d['chart']=json.loads(d.pop('chart_json'));d['favorite']=bool(d.get('favorite'))
    try:d['tags']=json.loads(d.get('tags') or '[]')
    except:d['tags']=[]
    return d

def update_chart(pid:int,chart:Dict[str,Any],data:Optional[Dict[str,Any]]=None)->Optional[Dict[str,Any]]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        if data:c.execute('''UPDATE profiles SET name=?,birth_date=?,birth_time=?,city=?,timezone_offset=?,latitude=?,longitude=?,rule_profile=?,notes=?,chart_json=?,updated_at=? WHERE id=?''',(data.get('name'),data.get('birth_date'),data.get('birth_time'),data.get('city'),data.get('timezone_offset'),data.get('latitude'),data.get('longitude'),data.get('rule_profile'),data.get('notes',''),json.dumps(chart,ensure_ascii=False),now,pid))
        else:c.execute('UPDATE profiles SET chart_json=?,updated_at=? WHERE id=?',(json.dumps(chart,ensure_ascii=False),now,pid))
        c.execute('INSERT INTO chart_snapshots(profile_id,chart_json,reason,created_at) VALUES(?,?,?,?)',(pid,json.dumps(chart,ensure_ascii=False),'recalculate',now))
    return get_profile(pid)


def set_profile_meta(pid:int,favorite:Optional[bool]=None,tags:Optional[List[str]]=None)->Optional[Dict[str,Any]]:
    if not get_profile(pid):return None
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        c.execute("INSERT INTO profile_meta(profile_id,favorite,tags,last_opened_at) VALUES(?,?,?,?) ON CONFLICT(profile_id) DO NOTHING",(pid,0,'[]',now))
        if favorite is not None:c.execute('UPDATE profile_meta SET favorite=? WHERE profile_id=?',(1 if favorite else 0,pid))
        if tags is not None:
            clean=[]
            for x in tags:
                x=str(x).strip()[:32]
                if x and x not in clean:clean.append(x)
            c.execute('UPDATE profile_meta SET tags=? WHERE profile_id=?',(json.dumps(clean[:12],ensure_ascii=False),pid))
    return get_profile(pid)

def profile_360(pid:int)->Optional[Dict[str,Any]]:
    p=get_profile(pid)
    if not p:return None
    return {'profile':{k:v for k,v in p.items() if k!='chart'},'active_remedies':list_remedies(pid),'notes':list_notes(pid)[:20],'outcomes':list_prediction_outcomes(pid)[:20],'followups':list_followups(pid),'consultations':list_consultations(pid)[:10]}

def snapshot_history(pid:int,limit:int=20)->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT id,profile_id,reason,created_at FROM chart_snapshots WHERE profile_id=? ORDER BY created_at DESC LIMIT ?',(pid,int(limit))).fetchall()
    return [dict(r) for r in rows]

def export_backup()->Dict[str,Any]:
    with conn() as c:
        tables=['profiles','profile_meta','remedy_programs','remedy_checkins','notes','prediction_outcomes','followups','chat_history','consultation_sessions','favorite_insights','appointments','payments','team_members','chart_snapshots']
        data={}
        for t in tables:
            try:data[t]=[dict(r) for r in c.execute(f'SELECT * FROM {t}').fetchall()]
            except Exception:data[t]=[]
    return {'format':'lal-kitab-ai-pro-backup','version':'19.3.2','exported_at':datetime.now().isoformat(timespec='seconds'),'data':data}

def delete_profile(pid:int)->bool:
    with conn() as c:cur=c.execute('DELETE FROM profiles WHERE id=?',(pid,))
    return cur.rowcount>0

def stats()->Dict[str,Any]:
    with conn() as c:
        profiles=c.execute('SELECT COUNT(*) n FROM profiles').fetchone()['n'];active=c.execute("SELECT COUNT(*) n FROM remedy_programs WHERE status='active'").fetchone()['n'];notes=c.execute('SELECT COUNT(*) n FROM notes').fetchone()['n'];outcomes=c.execute('SELECT COUNT(*) n FROM prediction_outcomes').fetchone()['n'];followups=c.execute("SELECT COUNT(*) n FROM followups WHERE status='open'").fetchone()['n'];chats=c.execute('SELECT COUNT(*) n FROM chat_history').fetchone()['n'];sessions=c.execute("SELECT COUNT(*) n FROM consultation_sessions WHERE status='open'").fetchone()['n'];appointments=c.execute("SELECT COUNT(*) n FROM appointments WHERE status='scheduled'").fetchone()['n'];revenue=c.execute('SELECT COALESCE(SUM(amount),0) n FROM payments').fetchone()['n'];team=c.execute("SELECT COUNT(*) n FROM team_members WHERE status='active'").fetchone()['n']
    return {'profiles':profiles,'active_remedies':active,'notes':notes,'prediction_outcomes':outcomes,'open_followups':followups,'ai_chats':chats,'open_consultations':sessions,'scheduled_appointments':appointments,'payments_total':round(float(revenue or 0),2),'active_team':team}

def add_remedy(profile_id:int,planet:str,remedy:str,duration:int,start_date:str)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO remedy_programs(profile_id,planet,remedy,duration,start_date,status,created_at) VALUES(?,?,?,?,?,?,?)',(profile_id,planet,remedy,duration,start_date,'active',now));rid=cur.lastrowid
    return get_remedy(rid)

def get_remedy(rid:int)->Optional[Dict[str,Any]]:
    with conn() as c:r=c.execute('SELECT * FROM remedy_programs WHERE id=?',(rid,)).fetchone();checks=c.execute('SELECT * FROM remedy_checkins WHERE program_id=? ORDER BY day_no',(rid,)).fetchall()
    if not r:return None
    d=dict(r);d['checkins']=[dict(x) for x in checks];d['completed_days']=sum(x['completed'] for x in d['checkins']);d['progress']=round(100*d['completed_days']/max(d['duration'],1),1);return d

def list_remedies(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c:ids=[r['id'] for r in c.execute('SELECT id FROM remedy_programs WHERE profile_id=? ORDER BY created_at DESC',(profile_id,)).fetchall()]
    return [get_remedy(i) for i in ids]

def checkin(rid:int,day_no:int,date:str,note:str='',completed:bool=True)->Optional[Dict[str,Any]]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        c.execute('''INSERT INTO remedy_checkins(program_id,day_no,checkin_date,completed,note,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(program_id,day_no) DO UPDATE SET checkin_date=excluded.checkin_date,completed=excluded.completed,note=excluded.note''',(rid,day_no,date,1 if completed else 0,note,now));rem=c.execute('SELECT duration FROM remedy_programs WHERE id=?',(rid,)).fetchone()
        if rem:
            done=c.execute('SELECT COUNT(*) n FROM remedy_checkins WHERE program_id=? AND completed=1',(rid,)).fetchone()['n']
            if done>=rem['duration']:c.execute("UPDATE remedy_programs SET status='completed' WHERE id=?",(rid,))
    return get_remedy(rid)

def add_note(profile_id:int,note:str)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO notes(profile_id,note,created_at) VALUES(?,?,?)',(profile_id,note,now));r=c.execute('SELECT * FROM notes WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)
def list_notes(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT * FROM notes WHERE profile_id=? ORDER BY created_at DESC',(profile_id,)).fetchall()
    return [dict(r) for r in rows]

def add_prediction_outcome(profile_id:int,year:int,domain:str,predicted_score:float,outcome:str,note:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds');outcome=outcome if outcome in {'hit','partial','miss','unknown'} else 'unknown'
    with conn() as c:cur=c.execute('INSERT INTO prediction_outcomes(profile_id,year,domain,predicted_score,outcome,note,created_at) VALUES(?,?,?,?,?,?,?)',(profile_id,int(year),domain,float(predicted_score),outcome,note,now));r=c.execute('SELECT * FROM prediction_outcomes WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)
def list_prediction_outcomes(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT * FROM prediction_outcomes WHERE profile_id=? ORDER BY year DESC,created_at DESC',(profile_id,)).fetchall()
    return [dict(r) for r in rows]
def outcome_stats(profile_id:Optional[int]=None)->Dict[str,Any]:
    with conn() as c:rows=c.execute('SELECT outcome,COUNT(*) n FROM prediction_outcomes GROUP BY outcome').fetchall() if profile_id is None else c.execute('SELECT outcome,COUNT(*) n FROM prediction_outcomes WHERE profile_id=? GROUP BY outcome',(profile_id,)).fetchall()
    counts={r['outcome']:r['n'] for r in rows};total=sum(counts.values());return {'total':total,'counts':counts,'hit_rate_label':('Not enough tracked outcomes' if total<5 else f"{round(100*(counts.get('hit',0)+0.5*counts.get('partial',0))/total)}% tracked-match index"),'note':'Outcome tracking is retrospective user feedback, not proof that astrology is predictive.'}

def add_followup(profile_id:int,due_date:str,kind:str,note:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO followups(profile_id,due_date,kind,note,status,created_at) VALUES(?,?,?,?,?,?)',(profile_id,due_date,kind,note,'open',now));r=c.execute('SELECT * FROM followups WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)
def list_followups(profile_id:Optional[int]=None,status:str='open')->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT * FROM followups WHERE status=? ORDER BY due_date ASC',(status,)).fetchall() if profile_id is None else c.execute('SELECT * FROM followups WHERE profile_id=? AND status=? ORDER BY due_date ASC',(profile_id,status)).fetchall()
    return [dict(r) for r in rows]
def close_followup(fid:int)->bool:
    with conn() as c:cur=c.execute("UPDATE followups SET status='done' WHERE id=?",(fid,))
    return cur.rowcount>0

def add_chat(profile_id:int|None,mode:str,question:str,answer:str)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO chat_history(profile_id,mode,question,answer,created_at) VALUES(?,?,?,?,?)',(profile_id,mode,question,answer,now));r=c.execute('SELECT * FROM chat_history WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)
def list_chats(profile_id:Optional[int]=None,limit:int=100)->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT * FROM chat_history ORDER BY created_at DESC LIMIT ?',(int(limit),)).fetchall() if profile_id is None else c.execute('SELECT * FROM chat_history WHERE profile_id=? ORDER BY created_at DESC LIMIT ?',(profile_id,int(limit))).fetchall()
    return [dict(r) for r in rows]

def add_consultation(profile_id:int,title:str,summary:str='',actions:Optional[List[str]]=None)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO consultation_sessions(profile_id,title,summary,actions,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(profile_id,title,summary,json.dumps(actions or [],ensure_ascii=False),'open',now,now));r=c.execute('SELECT * FROM consultation_sessions WHERE id=?',(cur.lastrowid,)).fetchone()
    d=dict(r);d['actions']=json.loads(d.get('actions') or '[]');return d
def list_consultations(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT * FROM consultation_sessions WHERE profile_id=? ORDER BY updated_at DESC',(profile_id,)).fetchall()
    out=[]
    for r in rows:d=dict(r);d['actions']=json.loads(d.get('actions') or '[]');out.append(d)
    return out

def add_favorite_insight(profile_id:int,category:str,title:str,content:str)->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO favorite_insights(profile_id,category,title,content,created_at) VALUES(?,?,?,?,?)',(profile_id,category,title,content,now));r=c.execute('SELECT * FROM favorite_insights WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)
def list_favorite_insights(profile_id:int)->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT * FROM favorite_insights WHERE profile_id=? ORDER BY created_at DESC',(profile_id,)).fetchall()
    return [dict(r) for r in rows]

def add_appointment(profile_id:int|None,appointment_at:str,kind:str='consultation',fee:float=0,note:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO appointments(profile_id,appointment_at,kind,fee,status,note,created_at) VALUES(?,?,?,?,?,?,?)',(profile_id,appointment_at,kind,float(fee or 0),'scheduled',note,now));r=c.execute('SELECT * FROM appointments WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)
def list_appointments(status:Optional[str]=None,profile_id:Optional[int]=None)->List[Dict[str,Any]]:
    q='SELECT a.*,p.name profile_name FROM appointments a LEFT JOIN profiles p ON p.id=a.profile_id';cond=[];args=[]
    if status:cond.append('a.status=?');args.append(status)
    if profile_id is not None:cond.append('a.profile_id=?');args.append(profile_id)
    if cond:q+=' WHERE '+' AND '.join(cond)
    q+=' ORDER BY a.appointment_at ASC'
    with conn() as c:rows=c.execute(q,args).fetchall()
    return [dict(r) for r in rows]
def update_appointment_status(appointment_id:int,status:str)->bool:
    status=status if status in {'scheduled','completed','cancelled','no_show'} else 'scheduled'
    with conn() as c:cur=c.execute('UPDATE appointments SET status=? WHERE id=?',(status,appointment_id))
    return cur.rowcount>0

def add_payment(profile_id:int|None,amount:float,mode:str='cash',reference:str='',note:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO payments(profile_id,amount,mode,reference,note,created_at) VALUES(?,?,?,?,?,?)',(profile_id,float(amount),mode,reference,note,now));r=c.execute('SELECT * FROM payments WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)
def list_payments(profile_id:Optional[int]=None,limit:int=200)->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT x.*,p.name profile_name FROM payments x LEFT JOIN profiles p ON p.id=x.profile_id ORDER BY x.created_at DESC LIMIT ?',(int(limit),)).fetchall() if profile_id is None else c.execute('SELECT x.*,p.name profile_name FROM payments x LEFT JOIN profiles p ON p.id=x.profile_id WHERE x.profile_id=? ORDER BY x.created_at DESC LIMIT ?',(profile_id,int(limit))).fetchall()
    return [dict(r) for r in rows]
def payment_stats()->Dict[str,Any]:
    with conn() as c:total=c.execute('SELECT COALESCE(SUM(amount),0) n FROM payments').fetchone()['n'];month=c.execute("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE substr(created_at,1,7)=?",(datetime.now().strftime('%Y-%m'),)).fetchone()['n'];cnt=c.execute('SELECT COUNT(*) n FROM payments').fetchone()['n']
    return {'total':round(float(total or 0),2),'this_month':round(float(month or 0),2),'count':cnt}

def add_team_member(name:str,role:str='Astrologer',phone:str='',email:str='')->Dict[str,Any]:
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:cur=c.execute('INSERT INTO team_members(name,role,phone,email,status,created_at) VALUES(?,?,?,?,?,?)',(name,role,phone,email,'active',now));r=c.execute('SELECT * FROM team_members WHERE id=?',(cur.lastrowid,)).fetchone()
    return dict(r)
def list_team(status:Optional[str]=None)->List[Dict[str,Any]]:
    with conn() as c:rows=c.execute('SELECT * FROM team_members WHERE status=? ORDER BY created_at DESC',(status,)).fetchall() if status else c.execute('SELECT * FROM team_members ORDER BY created_at DESC').fetchall()
    return [dict(r) for r in rows]
