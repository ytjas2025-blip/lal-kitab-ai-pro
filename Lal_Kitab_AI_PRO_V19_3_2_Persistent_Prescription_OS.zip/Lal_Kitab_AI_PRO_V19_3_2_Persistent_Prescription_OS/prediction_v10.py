from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from astro_v8 import DASHA_ORDER, DASHA_YEARS, NAKSHATRAS, monthly_focus, transit_snapshot
from prediction_pro import DOMAIN_RULES, forecast_year, event_windows_for_year

MEAN_YEAR_DAYS = 365.2425

PLANET_THEMES = {
    "Sun": {"focus":"authority, confidence, visibility, father/mentors and responsibility", "support":"leadership, clarity, public responsibility", "watch":"ego clashes, rigid decisions, status anxiety"},
    "Moon": {"focus":"mind, home, emotional rhythm, care and adaptability", "support":"connection, intuition, public responsiveness", "watch":"mood-led decisions, inconsistency, over-sensitivity"},
    "Mars": {"focus":"action, competition, courage, land/technical matters and conflict handling", "support":"initiative, stamina, decisive execution", "watch":"haste, confrontation, injury-prone behaviour or impulsive commitments"},
    "Mercury": {"focus":"learning, trade, communication, documents, analysis and negotiation", "support":"skills, commerce, writing, calculation, networking", "watch":"overthinking, mixed messages, paperwork errors"},
    "Jupiter": {"focus":"guidance, learning, expansion, ethics, children/mentors and long-range planning", "support":"judgment, teaching, support systems, perspective", "watch":"over-promising, complacency, excessive optimism"},
    "Venus": {"focus":"relationships, comforts, aesthetics, agreements, vehicles and value choices", "support":"diplomacy, design, partnership, enjoyment", "watch":"overspending, avoidance, relationship idealisation"},
    "Saturn": {"focus":"duty, structure, delay, persistence, systems, work and accountability", "support":"discipline, endurance, mature planning", "watch":"heaviness, delay, fear, overwork or pessimism"},
    "Rahu": {"focus":"ambition, unconventional paths, technology, foreign links and intense desire", "support":"innovation, reach, experimentation, non-traditional opportunities", "watch":"obsession, shortcuts, confusion, image over substance"},
    "Ketu": {"focus":"detachment, pruning, research, introspection and specialised focus", "support":"simplification, depth, pattern recognition", "watch":"withdrawal, abrupt disengagement, lack of continuity"},
}


def _dt(v: str) -> datetime:
    return datetime.fromisoformat(v)


def _iso(d: datetime) -> str:
    return d.date().isoformat()


def _planet_score(chart: Dict, lord: str) -> float:
    p = next((x for x in chart.get("placements", []) if x.get("planet") == lord), None)
    if not p:
        return 50.0
    try:
        return float(p.get("score", 50))
    except Exception:
        return 50.0


def _planet_house(chart: Dict, lord: str) -> Optional[int]:
    p = next((x for x in chart.get("placements", []) if x.get("planet") == lord), None)
    try:
        return int(p.get("house")) if p else None
    except Exception:
        return None


def _sequence_from(lord: str) -> List[str]:
    i = DASHA_ORDER.index(lord)
    return DASHA_ORDER[i:] + DASHA_ORDER[:i]


def _children(parent_start: datetime, parent_end: datetime, start_lord: str) -> List[Dict]:
    total_seconds = (parent_end - parent_start).total_seconds()
    cur = parent_start
    rows = []
    seq = _sequence_from(start_lord)
    for idx, lord in enumerate(seq):
        if idx == len(seq) - 1:
            end = parent_end
        else:
            end = cur + timedelta(seconds=total_seconds * DASHA_YEARS[lord] / 120.0)
        rows.append({"lord": lord, "start": _iso(cur), "end": _iso(end), "days": round((end-cur).total_seconds()/86400.0, 2)})
        cur = end
    return rows


def _active(rows: List[Dict], when: datetime) -> Optional[Dict]:
    for r in rows:
        s = _dt(r["start"])
        # inclusive date display; use end+1 day for date-only periods
        e = _dt(r["end"]) + timedelta(days=1)
        if s <= when < e:
            return r
    return None


def vimshottari_full(chart: Dict, when: Optional[str] = None) -> Dict:
    profile = chart.get("profile", {})
    placements = chart.get("placements", [])
    moon = next((p for p in placements if p.get("planet") == "Moon"), None)
    if not moon or not profile.get("birth_date"):
        return {"error":"Moon/birth data unavailable"}

    moon_lon = float(moon["longitude"])
    nak_size = 360.0 / 27.0
    nak_idx = int(moon_lon // nak_size)
    within = moon_lon - nak_idx * nak_size
    start_lord = DASHA_ORDER[nak_idx % 9]
    total_years = DASHA_YEARS[start_lord]
    elapsed_years = total_years * (within / nak_size)
    remaining_years = total_years - elapsed_years

    birth = datetime.fromisoformat(profile["birth_date"] + "T00:00:00")
    full_first_start = birth - timedelta(days=elapsed_years * MEAN_YEAR_DAYS)
    first_end = full_first_start + timedelta(days=total_years * MEAN_YEAR_DAYS)

    rows = []
    cur_start, cur_end = full_first_start, first_end
    seq_idx = DASHA_ORDER.index(start_lord)
    horizon = birth + timedelta(days=125 * MEAN_YEAR_DAYS)
    while cur_start < horizon and len(rows) < 16:
        lord = DASHA_ORDER[seq_idx % 9]
        if rows:
            cur_end = cur_start + timedelta(days=DASHA_YEARS[lord] * MEAN_YEAR_DAYS)
        rows.append({
            "lord": lord, "start": _iso(cur_start), "end": _iso(cur_end),
            "years": DASHA_YEARS[lord], "visible_from": _iso(max(cur_start, birth)),
            "partial_at_birth": cur_start < birth < cur_end,
        })
        cur_start = cur_end
        seq_idx += 1

    tz = float(profile.get("timezone_offset", 5.5))
    if when:
        now = datetime.fromisoformat(when)
    else:
        now = datetime.utcnow() + timedelta(hours=tz)

    md = _active(rows, now) or rows[0]
    md_start, md_end = _dt(md["start"]), _dt(md["end"])
    ads = _children(md_start, md_end, md["lord"])
    ad = _active(ads, now) or ads[0]
    pds = _children(_dt(ad["start"]), _dt(ad["end"]), ad["lord"])
    pd = _active(pds, now) or pds[0]
    sds = _children(_dt(pd["start"]), _dt(pd["end"]), pd["lord"])
    sd = _active(sds, now) or sds[0]

    def enrich(x: Dict, level: str, weight: float) -> Dict:
        lord = x["lord"]
        theme = PLANET_THEMES.get(lord, {})
        score = _planet_score(chart, lord)
        return {
            **x, "level":level, "natal_score":round(score,1), "lal_kitab_house":_planet_house(chart,lord),
            "focus":theme.get("focus",""), "support":theme.get("support",""), "watch":theme.get("watch",""),
            "weight":weight,
        }

    active_chain = [enrich(md,"Mahadasha",1.0), enrich(ad,"Antardasha",0.65), enrich(pd,"Pratyantar",0.38), enrich(sd,"Sookshma",0.20)]
    upcoming = []
    # next 8 boundary changes among current MD AD/PD table
    for level, rr in [("Antardasha",ads),("Pratyantar",pds),("Sookshma",sds)]:
        for r in rr:
            if _dt(r["start"]) > now:
                upcoming.append({**r,"level":level})
    upcoming = sorted(upcoming, key=lambda x:x["start"])[:10]

    return {
        "as_of": now.isoformat(timespec="minutes"),
        "birth_nakshatra": NAKSHATRAS[nak_idx], "starting_lord":start_lord,
        "balance_at_birth_years":round(remaining_years,3),
        "active_chain":active_chain,
        "mahadasha":rows,
        "current_mahadasha_antardasha":ads,
        "current_antardasha_pratyantar":pds,
        "current_pratyantar_sookshma":sds,
        "upcoming_boundaries":upcoming,
        "method_note":"Vimshottari hierarchy uses the standard 120-year proportional subdivision rule. Dates are software reference dates using a mean-year conversion. This Vedic timing layer is kept separate from Lal Kitab fixed-house rules.",
    }


def _dasha_domain_adjustment(chart: Dict, domain_key: str, chain: List[Dict]) -> Tuple[float, List[Dict]]:
    rule = DOMAIN_RULES.get(domain_key, {})
    pw = rule.get("planets", {})
    hw = rule.get("houses", {})
    adj = 0.0
    evidence = []
    for item in chain:
        lord = item["lord"]
        if lord not in pw:
            continue
        nat = float(item.get("natal_score",50))
        centered = (nat - 50.0)/50.0
        lord_rel = float(pw.get(lord,0))
        house = item.get("lal_kitab_house")
        house_rel = float(hw.get(house,0)) if house else 0.0
        contribution = centered * lord_rel * (4.5 * float(item.get("weight",1.0)))
        if house_rel:
            contribution += (1.2 if nat >= 50 else -1.0) * min(1.5,house_rel) * float(item.get("weight",1.0))
        adj += contribution
        evidence.append({"level":item["level"],"lord":lord,"natal_score":nat,"house":house,"delta":round(contribution,1)})
    return round(adj,1), evidence


def _band(score: float) -> str:
    if score >= 72: return "Strong supportive emphasis"
    if score >= 62: return "Supportive / workable"
    if score >= 50: return "Mixed but manageable"
    if score >= 40: return "Higher-friction / manage carefully"
    return "Low emphasis / protect fundamentals"


def _narrative(label: str, score: float, base: Dict, dasha_ev: List[Dict]) -> str:
    if score >= 62:
        tone = f"{label} is one of the more supported areas in the current combined model."
    elif score < 45:
        tone = f"{label} carries more friction in the current combined model, so pacing and verification matter."
    else:
        tone = f"{label} is mixed: there is usable support, but it is not a clean one-way signal."
    support = "; ".join(x.get("label","") for x in (base.get("support") or [])[:2])
    caut = "; ".join(x.get("label","") for x in (base.get("cautions") or [])[:2])
    ds = ", ".join(f"{x['level']} {x['lord']} ({x['delta']:+.1f})" for x in dasha_ev[:3])
    practical = base.get("practical","")
    return f"{tone} Dasha overlay: {ds or 'neutral for this domain'}. Supporting evidence: {support or 'mixed evidence'}. Caution evidence: {caut or 'no major caution flag in top evidence'}. Practical lens: {practical}"


def full_prediction_studio(chart: Dict, when: Optional[str] = None, years: int = 5) -> Dict:
    dasha = vimshottari_full(chart, when)
    chain = dasha.get("active_chain",[])
    details=[]
    base_rows = {x.get("key"):x for x in chart.get("predictions",[])}
    for key, rule in DOMAIN_RULES.items():
        base = base_rows.get(key) or forecast_year(chart, datetime.now().year)["domains"].get(key,{})
        base_score=float(base.get("score",50))
        adj, dev = _dasha_domain_adjustment(chart,key,chain)
        score=max(0,min(100,round(base_score+adj,1)))
        details.append({
            "key":key,"label":rule["label"],"base_score":round(base_score,1),"dasha_adjustment":adj,
            "current_score":score,"band":_band(score),"confidence":base.get("confidence",50),
            "support":(base.get("support") or [])[:5],"cautions":(base.get("cautions") or [])[:5],
            "dasha_evidence":dev,"narrative":_narrative(rule["label"],score,base,dev),
            "practical":rule.get("practical","")
        })
    ranked=sorted(details,key=lambda x:x["current_score"],reverse=True)

    tz=float(chart.get("profile",{}).get("timezone_offset",5.5))
    now=datetime.fromisoformat(when) if when else datetime.utcnow()+timedelta(hours=tz)
    current_year=now.year
    months=[]
    mf=monthly_focus(chart,current_year)
    for m in mf.get("months",[]):
        if m["month"] < now.month: continue
        months.append(m)
    if len(months)<12:
        nxt=monthly_focus(chart,current_year+1)
        months += nxt.get("months",[])[:12-len(months)]
    months=months[:12]

    year_rows=[]
    for y in range(current_year,current_year+max(1,min(int(years),10))):
        fy=forecast_year(chart,y)
        ev=event_windows_for_year(chart,y)
        year_rows.append({
            "year":y,"age_reference":fy.get("age_reference"),"house_cycle":fy.get("house_cycle"),
            "top":fy.get("top",[])[:4],"watch":fy.get("watch",[])[:3],
            "events":ev.get("top_windows",[])[:4],"management_flags":ev.get("management_flags",[])[:2]
        })

    try: live = transit_snapshot(chart, when)
    except Exception: live = {}

    remedies=(chart.get("remedy_plan") or {}).get("primary",[])[:3]
    return {
        "as_of":dasha.get("as_of"),"active_dasha":dasha,"domains":details,
        "strongest":ranked[:5],"watch":sorted(details,key=lambda x:x["current_score"])[:5],
        "next_12_months":months,"next_years":year_rows,"live_transit":live,
        "top_remedies":remedies,
        "method_note":"V10 Prediction Studio fuses the existing Lal Kitab-inspired domain model with a separately-labelled Vimshottari Mahadasha/Antardasha/Pratyantar/Sookshma timing overlay, annual/36-year layers and monthly sidereal transit focus. Scores remain interpretive emphasis indexes, not event probabilities.",
        "safety_note":"The software does not make deterministic claims about death, disease, pregnancy, crime, court outcomes, gambling wins or exact investment returns. High-stakes decisions require real-world professional advice and verification.",
    }
