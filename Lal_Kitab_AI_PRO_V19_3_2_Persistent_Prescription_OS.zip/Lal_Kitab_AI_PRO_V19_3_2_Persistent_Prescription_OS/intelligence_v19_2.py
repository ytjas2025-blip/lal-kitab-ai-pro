"""V19.2 Verified Visual Intelligence layer.
Deterministic chart facts are consumed from engine.py and never re-written here.
Traditional astrology interpretation only; no certain medical/legal/financial/relationship claims.
"""
from typing import Dict, List

PARASHARI_ASPECTS={
    'Sun':[7],'Moon':[7],'Mercury':[7],'Venus':[7],
    'Mars':[4,7,8],'Jupiter':[5,7,9],'Saturn':[3,7,10],
    # Rahu/Ketu intentionally omitted from the default classical profile because schools differ.
}

PLANET_THEMES={
 'Sun':['authority','leadership','reputation','father','visibility'],
 'Moon':['mind','home','family','public response','emotional rhythm'],
 'Mars':['courage','competition','property','conflict','initiative'],
 'Mercury':['speech','business','documents','learning','analysis'],
 'Jupiter':['wisdom','education','finance','guidance','expansion'],
 'Venus':['relationships','comfort','vehicles','art','agreements'],
 'Saturn':['discipline','delay','work','responsibility','structure'],
 'Rahu':['ambition','foreign','technology','unusual paths','amplification'],
 'Ketu':['research','detachment','spirituality','separation','specialization'],
}

HOUSE_THEMES={1:'self/body',2:'family/wealth/speech',3:'effort/siblings/communication',4:'home/property/mother',5:'education/creativity/children',6:'service/debt/disputes',7:'partnership/marriage',8:'transformation/shared assets/research',9:'fortune/mentors/long travel',10:'career/status/action',11:'gains/network/fulfilment',12:'expense/foreign/isolation'}

SAFE_REMEDIES={
 'Sun':['Maintain a disciplined sunrise routine or brief prayer if it fits your beliefs.','Support father/mentor/elder figures where appropriate; avoid expensive fear-based remedies.'],
 'Moon':['Prioritize sleep/routine and calm communication; optional simple meditation or prayer.','Choose low-cost seva/charity rather than objects claimed to guarantee outcomes.'],
 'Mars':['Channel energy into exercise, disciplined action and conflict de-escalation.','Optional Hanuman-oriented prayer/seva if personally meaningful; never substitute it for safety measures.'],
 'Mercury':['Double-check documents, messages and contracts; strengthen learning habits.','Optional education-related charity/seva as a traditional practice.'],
 'Jupiter':['Seek qualified mentors and keep ethical financial/educational discipline.','Optional teaching/food/education charity within your means.'],
 'Venus':['Use relationship communication and budgeting around luxury/comfort spending.','Optional arts/women-support/charity practice consistent with your values.'],
 'Saturn':['Use consistency, punctuality, service and debt/document discipline.','Optional low-cost seva for elderly/working people; no guaranteed Saturn remedy claims.'],
 'Rahu':['Verify unusual opportunities, contracts and online claims independently.','Use grounding routines and non-harmful charity; avoid occult/fear-based costly prescriptions.'],
 'Ketu':['Keep plans documented and avoid impulsive withdrawal from commitments.','Optional meditation/seva; use practical professional support when a real issue exists.'],
}

def _by_planet(chart):
    return {p.get('planet'):p for p in chart.get('placements',[]) if p.get('planet')}

def _house(h, offset):
    return ((int(h)-1 + int(offset)-1)%12)+1

def parashari_drishti(chart:Dict)->Dict:
    by=_by_planet(chart); occupants={h:[] for h in range(1,13)}
    for p in by.values(): occupants[int(p['house'])].append(p['planet'])
    rows=[]; received={p:[] for p in by}
    for planet,steps in PARASHARI_ASPECTS.items():
        if planet not in by: continue
        src=int(by[planet]['house'])
        for step in steps:
            target=_house(src,step)
            rec=occupants[target]
            row={'planet':planet,'from_house':src,'aspect':step,'to_house':target,'to_planets':rec,'house_theme':HOUSE_THEMES[target]}
            rows.append(row)
            for rp in rec: received.setdefault(rp,[]).append({'from':planet,'aspect':step,'from_house':src})
    mutual=[]
    pairs=set()
    for r in rows:
        for rp in r['to_planets']:
            reverse=any(x['planet']==rp and r['planet'] in x['to_planets'] for x in rows)
            if reverse:
                key=tuple(sorted([r['planet'],rp]))
                if key not in pairs: pairs.add(key); mutual.append({'planets':list(key),'label':f'{key[0]} ↔ {key[1]} mutual drishti'})
    return {'profile':'Classical Parashari default','rows':rows,'received':received,'mutual':mutual,'node_note':'Rahu/Ketu drishti is intentionally excluded from the default profile because traditions differ.'}

def graha_intelligence(chart:Dict)->Dict:
    by=_by_planet(chart); dr=parashari_drishti(chart); result=[]
    for planet,p in by.items():
        casts=[x for x in dr['rows'] if x['planet']==planet]
        receives=dr['received'].get(planet,[])
        result.append({
          'planet':planet,'sign':p.get('sign'),'house':p.get('house'),'degree':p.get('degree_in_sign'),'retrograde':bool(p.get('retrograde')),
          'score':p.get('score'),'themes':PLANET_THEMES.get(planet,[]),'casts':casts,'receives':receives,
          'remedies':SAFE_REMEDIES.get(planet,[]),'status':'Activated natal hub' if casts or receives else 'Natal placement',
          'proof':f"{planet} in {p.get('sign')} • H{p.get('house')} • {p.get('degree_in_sign')}°"
        })
    return {'planets':result,'mutual_drishti':dr['mutual'],'method':'Uses verified natal placements plus classical Parashari drishti. Dasha/transit/Varga weighting remains a separate evidence layer.'}

# Compact rule-based Yoga/Dosha screens. These are candidates, not final verdicts.
def yoga_dosha_universe(chart:Dict)->Dict:
    by=_by_planet(chart); ph={k:int(v['house']) for k,v in by.items()}
    yog=[]; dos=[]
    def add_y(key,name,present,evidence,effect):
        yog.append({'key':key,'name':name,'status':'Candidate present' if present else 'Not detected by base rule','evidence':evidence if present else [],'effects':effect,'activation':'Requires Dasha/transit/Varga confirmation','remedies':['No corrective remedy is automatically required for a Yoga; use supportive discipline and source-specific guidance only when justified.']})
    # Gaj Kesari: Jupiter in kendra from Moon (1/4/7/10 relative)
    if 'Moon' in ph and 'Jupiter' in ph:
        rel=((ph['Jupiter']-ph['Moon'])%12)+1; gk=rel in {1,4,7,10}
        add_y('gaj_kesari','Gaj Kesari Yoga',gk,[f'Moon H{ph["Moon"]}',f'Jupiter H{ph["Jupiter"]}',f'Relative house {rel}'],['traditional themes: judgement, reputation, learning, guidance; strength depends on dignity/affliction'])
    # Chandra-Mangal relation by conjunction or mutual 7th
    cm='Moon' in ph and 'Mars' in ph and (((ph['Mars']-ph['Moon'])%12)+1 in {1,7})
    add_y('chandra_mangal','Chandra-Mangal Yoga / relation',cm,[f'Moon H{ph.get("Moon")}',f'Mars H{ph.get("Mars")}'],['initiative and financial/activity themes; can also increase emotional reactivity when pressured'])
    # Budha-Aditya by same house
    ba='Sun' in ph and 'Mercury' in ph and ph['Sun']==ph['Mercury']
    add_y('budha_aditya','Budha-Aditya Yoga',ba,[f'Sun + Mercury H{ph.get("Sun")}'],['intellect, administration, communication; combustion and dignity modify results'])
    # Guru-Mangal by conjunction or mutual 7th
    gm='Jupiter' in ph and 'Mars' in ph and (((ph['Mars']-ph['Jupiter'])%12)+1 in {1,7})
    add_y('guru_mangal','Guru-Mangal relation',gm,[f'Jupiter H{ph.get("Jupiter")}',f'Mars H{ph.get("Mars")}'],['enterprise, strategy, action guided by judgement; dignity and house ownership matter'])
    # Manglik from Lagna and Moon base screen
    mars=ph.get('Mars'); moon=ph.get('Moon')
    lagna_manglik=mars in {1,2,4,7,8,12} if mars else False
    moon_rel=((mars-moon)%12)+1 if mars and moon else None
    moon_manglik=moon_rel in {1,2,4,7,8,12} if moon_rel else False
    dos.append({'key':'manglik','name':'Manglik / Mangal Dosha','status':'Present from Lagna' if lagna_manglik else ('Present from Moon reference' if moon_manglik else 'Not detected by base Lagna/Moon screen'),'evidence':[f'Mars H{mars}']+([f'Mars is {moon_rel} from Moon'] if moon_rel else []),'effects':['traditional relationship-friction / impatience indicator only; not a guaranteed marriage outcome'],'cancellation':'Full cancellation/partner matching requires an expanded rule profile.','remedies':SAFE_REMEDIES['Mars']})
    # Guru Chandal conjunction
    gc=('Jupiter' in ph and any(n in ph and ph[n]==ph['Jupiter'] for n in ['Rahu','Ketu']))
    dos.append({'key':'guru_chandal','name':'Guru Chandal candidate','status':'Candidate present' if gc else 'Not detected by base conjunction rule','evidence':[f'Jupiter H{ph.get("Jupiter")}'] if gc else [],'effects':['traditional judgement/belief amplification or unconventional learning themes; degree/dignity matter'],'cancellation':'Check exact degrees, dignity, benefic support and Dasha.','remedies':SAFE_REMEDIES['Jupiter']})
    # Grahan conjunction
    grahan=[]
    for lum in ['Sun','Moon']:
        for node in ['Rahu','Ketu']:
            if lum in ph and node in ph and ph[lum]==ph[node]: grahan.append(f'{lum}+{node} H{ph[lum]}')
    dos.append({'key':'grahan','name':'Grahan-type conjunction','status':'Candidate present' if grahan else 'Not detected by base conjunction rule','evidence':grahan,'effects':['traditional visibility/emotional-pressure modifier; exact degree separation is essential'],'cancellation':'Check degree separation, dignity, Vargas and timing.','remedies':['Use ordinary health/safety/professional support for real-life issues; optional prayer/meditation may be spiritual support only.']})
    return {'yogas':yog,'doshas':dos,'note':'V19.2 base scanner intentionally labels candidates. Full classical cancellation, dignity, Vargas, Dasha and source-profile adjudication must confirm the final result.'}

def v19_2_dashboard(chart:Dict)->Dict:
    return {'version':'19.2.0','graha_intelligence':graha_intelligence(chart),'drishti':parashari_drishti(chart),'yoga_dosha':yoga_dosha_universe(chart),'ui':{'font_scale':'Large-first','body_px':18,'card_px':20,'heading_px':34,'hero_px':50,'motion':['Off','Subtle','Cinematic'],'visuals':['Graha bars','Bhava bars','Drishti map','Mutual aspect graph','Yoga cards','Dosha X-Ray','Dasha timeline','Varga matrix','Alert radar','Astro Time Machine shell']}}
