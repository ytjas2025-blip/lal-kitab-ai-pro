# Remedy Source Hierarchy — V19.2.9

Tier A — Early Lal Kitab source family (1941/1952): only explicitly verified rules are labelled as such.
Tier B — Structured supporting editions/commentaries such as Arun Sanhita.
Tier C — Traditional secondary commentary (e.g. Girdhari Lal Sharma/B.M. Gosvami-type references after verification).
Tier D — Modern public remedy compilations: idea pool only; not promoted to classical authority.
Tier E — Modern seva / behavioural / safety substitutes created for feasibility and harm reduction.

Core software rule: source presence does not equal recommendation. The engine must check chart relevance, conflict, safety, feasibility, and then show only a small prescription.
