# Rule Source & Method Notes — V6

Lal Kitab has multiple editions, translations and teaching lineages. Public modern references also disagree on details such as Pakka Ghar tables, sleeping-house rules, Rin categories and annual progression. V6 therefore treats those as **source-aware rule profiles**, not invisible universal truths.

## Separation of layers
1. **Calculated astronomy** — Swiss Ephemeris/Moshier, Lahiri sidereal longitude, sign, degree and retrograde flag.
2. **Traditional/reference layer** — fixed-house Lal Kitab framework, Pakka/Uchcha/Neecha references, relationships, Drishti, Masnui, technical Teva and Rin review.
3. **Software synthesis** — 16-domain scores, event-theme windows, consensus, compatibility and rectification ranking.
4. **Narrative layer** — built-in/OpenAI explanation.

## Annual / Varshphal boundary
V6 keeps the age-based Lal Kitab annual house-rotation layer separate from the astronomical birthday comparison. It does not silently blend Tajika solar-return methods into the Lal Kitab annual progression workflow.

Modern explanatory references consulted while designing the method boundary include:
- Paramarsh: Lal Kitab Varshphal — annual progression described separately from Tajika.
- PanchangBodh: Lal Kitab Varshphal — age-based annual-house transformation example.
- xalen-lalkitab documentation: annual chart built by rotating the birth chart by year/age.

These public references are not treated as a substitute for primary editions.

## Rin boundary
Modern sources disagree on how many Rin categories to emphasize (examples range from three/six/seven to nine). V6 keeps a nine-category review workspace but does **not** claim a single simplified placement test is a canonical diagnosis. Rin is presented as traditional symbolic terminology, not proof of wrongdoing or literal debt.

## Compatibility boundary
The V6 Compatibility Lab is a software synthesis based on domain alignment and low-weight planet-house resonance. It is not claimed to be a classical Lal Kitab marriage-matching canon, and its index is not a probability of relationship success.

## Rectification boundary
The V6 Birth-Time Rectification Assistant ranks nearby candidate times against user-supplied known-event years using the same explainable forecast engine. It is exploratory only. A low discrimination spread is explicitly shown when the model cannot distinguish candidate times.

## Safety boundary
No deterministic output is generated for death, disease diagnosis, pregnancy/fertility, crime, court results, gambling wins, exact investment returns or other safety-critical outcomes. High-stakes decisions must use appropriate professional and real-world evidence.

## V11 — GD Vashist / Astroscience public-source layer
V11 adds a public-source research layer based on the official Astroscience remedy hub, public planet-by-house remedy pages, public methodology/service pages, and selected public videos from the official Gurudev GD Vashist YouTube channel.

The public descriptions emphasize house placement and ascendant context, category-focused predictions, and multi-year horizons. V11 uses these ideas to structure its own independent **Luck Meter, Kismat Ki Saankdi, 2/5/7/10/25-year Category Prediction Files, Problem Detector, and source-aware remedy browser**.

This is **not** a claim that the software implements Gurudev GD Vashist's proprietary rule library, paid Lal Kitab Amrit files, books, or private algorithms. Public source URLs are stored for attribution/context; generated scores and protocols are this software's own synthesis.

## V12 — Shri Sumitacharya public-source layer
V12 adds a second public-source research layer based on Sumitacharya.in public pages and the official Shri Sumitacharya Ji Maharaj YouTube channel. Public service descriptions emphasize detailed birth-chart/divisional-chart analysis, yogas/doshas, 5+ year life-area forecasts, marriage matching, business + Vastu, baby-name services and traditional remedy classes.

V12 uses that **publicly described scope** to build its own independent Deep Prediction workspace, conservative Dosha Research Lab, 108-Insight Builder, Baby Name Lab, Business + Vastu checklist and 1,200 source-aware upay cards. It does not reproduce a paid 108-page report, proprietary rules, consultation outputs or video transcripts.

The public Trijata article is implemented only as a conservative research flag using a subset of publicly described conditions. The software explicitly refuses death, widowhood, disease, fertility and lifespan inferences from that or any other dosha label.

The source website's Terms state that astrology content/services are for entertainment, guidance and informational purposes and are not substitutes for professional advice; V12 preserves the same high-stakes boundary.
