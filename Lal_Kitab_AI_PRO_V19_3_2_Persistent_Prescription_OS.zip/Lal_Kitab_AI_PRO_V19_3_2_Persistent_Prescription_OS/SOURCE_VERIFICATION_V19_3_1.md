# Source Verification — V19.3.1

## Early-source principles currently verified in build

### Lal Kitab (Teesra Hissa), 1941
- Attribution/title metadata verified from the supplied 521-page Hindi transliteration.
- Introductory framing treats conduct/character as important; the software therefore keeps Karma/Behaviour Correction as a first-class category, not merely material ritual.
- The introduction explicitly cautions against blindly applying remedies to every planet because an otherwise benefic planet's positive effect may be disturbed. The software maps this principle to Remedy Conflict Guard 2.0 and permits a `No Remedy Needed` result.

## Deliberate limitation
V19.3.1 does **not** claim that every modern seva action is a verbatim remedy from the 1941/1952 books. Modern seva, safety and behavioural alternatives remain Tier E and are labelled as such. Exact `edition → page → planet → house → condition → remedy → contraindication` mapping is only promoted to Tier A after page-level verification.
