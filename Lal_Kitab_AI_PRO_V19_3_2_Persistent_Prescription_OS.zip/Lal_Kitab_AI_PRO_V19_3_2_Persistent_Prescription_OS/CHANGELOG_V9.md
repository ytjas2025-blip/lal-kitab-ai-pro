# CHANGELOG — V9 ASTRO INTELLIGENCE OS

## Major new modules

- Upgraded mobile-first **Command Center v9** with an Intelligence Strip and one-tap research/AI shortcuts.
- **Full 16-Varga Lab**: D1, D2, D3, D4, D7, D9, D10, D12, D16, D20, D24, D27, D30, D40, D45 and D60 workspace under a named formula profile.
- **Yogini Dasha** 36-year auxiliary timeline with birth balance and active-reference period.
- **Shad Bala Research Lab** with six visible component indexes: Sthana, Dig, Kala, Cheshta, Naisargika and Drik. This is intentionally not labelled as classical virupa/rupa Shadbala.
- **Muhurta AI Planner** for date-range ranking using Panchang/Tara references plus the software's natal annual context.
- **Animated Transit Wheel** with a 31-day default slider and up to 93-day backend series.
- **Why-this-Prediction Rule Graph** connecting planets, houses, domains and selected remedies.
- **Voice Consultation** using browser speech recognition and optional browser text-to-speech.
- **Practice Command Center**: appointments, fee ledger/payments and team roster in local SQLite.
- **WhatsApp-ready Client Summary** generator.
- AI Copilot expanded from 8 to **12 modes**, adding Muhurta, Research, Compatibility and Business planning lenses.

## Retained from V8.1

- 2,700 safety-normalized remedy records and Smart Top-3 protocol.
- 16 explainable prediction domains and 11 event themes.
- Prediction consensus / contradiction audit.
- 12-month focus, 1–90 life timeline, scenario lab and year comparison.
- Relationship/business/family compatibility.
- Birth-time sensitivity + known-event rectification assistant.
- Lal Kitab fixed-house Teva, Rin, Masnui, Soya/Jagta, Pakka Ghar profiles and separate 35/36-year timing layers.
- D1/D9/Moon/Chalit/D10/D12 Vedic auxiliary charts, Panchang and Vimshottari.
- Client CRM, remedy tracker, consultations, follow-ups, prediction outcomes and AI history.

## Method boundary

Higher Varga mapping conventions, Ashtakavarga bindu tables, KP sub-lord systems and some classical strength computations can vary by lineage/source. V9 names its active formula profile and keeps research indexes separate rather than presenting them as universally verified classical totals.
