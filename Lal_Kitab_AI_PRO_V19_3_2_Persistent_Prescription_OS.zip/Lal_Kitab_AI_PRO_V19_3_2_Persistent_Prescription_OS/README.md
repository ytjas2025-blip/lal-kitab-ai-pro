# Lal Kitab AI PRO — V19.2.9

# Lal Kitab AI PRO — MULTI-SOURCE INTELLIGENCE OS v12

Mobile-first Lal Kitab + Vedic auxiliary astrology workstation with deep Dasha/prediction analysis, a **4,800-record remedy vault**, and two separately-labelled public-source research labs: **GD Vashist/Astroscience** and **Shri Sumitacharya**.

## V12 highlights

- **4,800 remedy records** total.
- 900 GD Vashist/Astroscience public-source-aware cards retained from V11.
- **1,200 new Shri Sumitacharya public-source-aware cards**.
- Source links, source class, safety class, chart relevance and attribution on source-aware upay.
- **Shri Sumitacharya Source Intelligence Lab**.
- **Sumit Deep Prediction Workspace**: D1/Varga + 4-level Vimshottari + annual/house-cycle/transit + 16 life domains.
- **Vedic Dosha Research Lab**: conservative Manglik, Sade Sati, Kaal Sarpa and Trijata candidate screens with explicit exclusions for death/disease/lifespan claims.
- **108-Insight Deep Kundli Builder** — 108 original insight slots; not a copy of a paid 108-page report.
- **Baby Name Lab** using traditional Nakshatra + Pada starting sounds.
- **Business Astrology + Vastu checklist**; actual premises direction/floor-plan data is required for full Vastu analysis.
- Marriage single-chart panel plus existing two-chart Compatibility Lab.
- **18-entry official/public source library** for Sumitacharya.in and the official YouTube channel, covering report, consultation, business/Vastu, marriage, baby-name, grah-shanti and service indexes.
- **15 AI Copilot modes**, including Source Compare, Dosha Auditor and Remedy Scholar.

## Deep prediction stack

- Vimshottari **Mahadasha → Antardasha → Pratyantar → Sookshma**.
- 16 detailed life-area predictions with supporting/caution evidence.
- Next 12 months focus.
- Next 5 years deep forecast + event-theme windows.
- 12-year base forecast and GD Vashist category horizons up to 25 years.
- 35-year planetary and 36-year Lal Kitab house-cycle reference layers kept separate.
- Prediction consensus, contradiction audit, scenario lab and birth-time rectification.

## Charts / research workspaces

- D1 Lagna, D9 Navamsha, Moon, Bhav Chalit, D10, D12.
- Lal Kitab fixed-house Teva and sacred Lal Kitab chart.
- 16-Varga Lab: D1, D2, D3, D4, D7, D9, D10, D12, D16, D20, D24, D27, D30, D40, D45, D60.
- Panchang, Vimshottari, Yogini, Raj Yoga candidates, Bhav Madhya, Friendship, Karakamsha, Swamsa, KP workspace, Avakhada.
- Muhurta AI, transit wheel, rule graph, life timeline, compatibility, family matrix and practice CRM.

## Multi-source boundary

This software is **not an official product, licensed clone, or endorsement** of either GD Vashist/Astroscience or Shri Sumitacharya/Sumitacharya Gurukul unless separately licensed.

The software indexes public URLs and stores independently written, paraphrased, safety-normalized research cards. It does not bulk-copy paid books, paid reports, consultations, proprietary calculations, copyrighted article text, or full YouTube transcripts.

Calculated astronomy, Lal Kitab reference rules, Vedic auxiliary calculations, source metadata, software synthesis and AI narrative are kept visibly separate.

## Safety boundary

Astrology is treated as a traditional belief / guidance / entertainment system. It is not professional medical, legal or investment advice. The app blocks or reframes death/widowhood/lifespan/disease certainty, fertility certainty, guaranteed financial outcomes, dangerous fasting/fire, pollution, animal harm, ingestion risks, unlawful acts and financially exploitative remedies.

## Run locally

Windows: double-click `run_windows.bat` after installing Python 3.11+.

macOS/Linux:
```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```

Open `http://127.0.0.1:8000`.

See `CHANGELOG_V12.md`, `SUMITACHARYA_SOURCE_NOTES.md`, `RULE_SOURCE_NOTES.md` and `REMEDY_VAULT_NOTES.md`.

## V18 Enterprise Intelligence
V18 adds Astro Digital Twin, Event Radar, Astro Council, Source Compare, What Changed?, 25-year forecast horizons, Remedy Engine 7.0 (7,200 records) and a dedicated Reports & Print Center including a full 100-page original research PDF.


## V18.1 Professional Report Engine
The Full report is now a dense, client-ready Kundli PDF with real D1/D9/Varga charts, planetary and house tables, 4-level Vimshottari, Yogini, annual/transit analysis, 16 prediction domains, actual 12-month forecast, 5-year Event Radar, Lal Kitab placement analysis, priority remedies, dosha research, research Shad Bala, 25-year chain and source comparison. Page count is dynamic; filler pages are not used.

## V19.2 Verified Visual Intelligence
V19.2 adds Graha Intelligence 360°, Drishti Intelligence, Yoga + Dosha X-Ray, expanded Critical Alert Center, large-first typography, and animation-ready visual modules while retaining the V19 calculation guard and golden regression fixture.
