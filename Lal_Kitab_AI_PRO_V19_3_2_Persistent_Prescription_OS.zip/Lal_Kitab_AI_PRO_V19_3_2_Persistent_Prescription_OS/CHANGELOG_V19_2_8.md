# V19.2.8 — Adaptive Upay Alternatives

- Added lifestyle-fit Upay preference engine: no sunrise, father unavailable/unsafe contact, no donation, no mantra, no temple, low/no-cost.
- Added multiple practical alternatives per graha instead of one rigid ritual.
- Sun example: Surya jal can switch to mantra, wheat/jaggery charity, mentor/elder respect, or morning discipline.
- Father absent/deceased/estranged: never forces contact; uses respectful elder/teacher/mentor/service/discipline substitutes.
- Alternatives are labelled as common traditional, devotional, safe modern substitute, or software-derived behavioural support.
- Pollution, unsafe animal feeding, hazardous fire/smoke, medical replacement, coercive family contact, expensive gemstones and guaranteed-outcome claims remain blocked.
- User constraints persist in browser preferences.
