# V18.1 Professional Report Edition

- Replaced forced 100-page filler report with dense professional Kundli generator.
- D1 and D9 charts, planetary positions, 12 houses, planet passports.
- Full Vimshottari chain to Sookshma, Yogini Dasha, annual view, current transits.
- 16 detailed prediction domains, actual 12-month forecast, 5-year roadmap and Event Radar.
- Lal Kitab placement analysis, priority remedies, dosha research, research Shad Bala.
- Actual 16 Varga charts and 25-year Luck Chain.
- Premium ivory/black/gold print design with headers, footers and compact tables.
- Retains V18.0.1 mobile-startup fix.
