"""V19.3.2 persistence contract smoke test (SQLite fallback; PostgreSQL uses same db API)."""
import os, tempfile, importlib
os.environ.pop('DATABASE_URL',None)
import db
# isolate test DB
_tmp=tempfile.TemporaryDirectory(); db.DB_PATH=db.Path(_tmp.name)/'persistence.db'; db.init_db()
data={'name':'Persistence Test','birth_date':'2000-01-01','birth_time':'12:00','city':'Delhi','timezone_offset':5.5,'latitude':28.6139,'longitude':77.209,'rule_profile':'1940-foundation','client_uuid':'test-stable-uuid'}
chart={'test':True,'calculation_guard':{'status':'VERIFIED PIPELINE'}}
p=db.save_profile(data,chart); pid=p['id']
assert len(db.list_profiles())==1 and db.get_profile(pid)['chart']['test']
# same UUID must update, never duplicate
data2=dict(data); data2['notes']='updated'; p2=db.save_profile(data2,{'test':True,'revision':2}); assert p2['id']==pid and len(db.list_profiles())==1
r=db.add_remedy(pid,'Saturn','Behaviour correction test',2,'2026-09-09'); db.checkin(r['id'],1,'2026-09-09','done')
assert db.get_remedy(r['id'])['completed_days']==1
# reopen DB connection semantics are exercised by every db function; data remains on disk.
assert db.get_profile(pid)['chart']['revision']==2
assert db.delete_profile(pid) and db.get_profile(pid) is None
print('V19.3.2 PERSISTENCE TEST: PASS')
