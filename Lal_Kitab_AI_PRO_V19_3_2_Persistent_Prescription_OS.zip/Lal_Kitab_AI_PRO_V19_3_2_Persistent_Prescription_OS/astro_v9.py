from __future__ import annotations

"""V9 advanced astrology planning/research layers.

This module intentionally keeps three kinds of output separate:
1) astronomical/sidereal calculations,
2) traditional astrology formula workspaces,
3) software planning/interpretation indexes.

Astrology is a traditional belief system. Nothing here is a scientific
probability model or a substitute for professional medical/legal/financial
advice.
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import math

from engine import calc_planets, CITY_PRESETS
from prediction_pro import forecast_year, DOMAIN_RULES
from astro_v8 import (
    SIGN_TO_NO, SIGNS, PLANET_SHORT, NAKSHATRAS,
    vedic_auxiliary, panchang_from_chart, _sign_no_from_lon,
    _whole_sign_house, _navamsha_sign, _dasamsa_sign,
    _dwadasamsa_sign, VEDIC_EXALT, VEDIC_DEBIL, COMBUST_LIMIT,
)

# ---------------------------------------------------------------------------
# Divisional chart workspace
# ---------------------------------------------------------------------------

VARGA_LABELS = {
    1: "D1 Rashi", 2: "D2 Hora", 3: "D3 Drekkana", 4: "D4 Chaturthamsa",
    7: "D7 Saptamsa", 9: "D9 Navamsha", 10: "D10 Dasamsa",
    12: "D12 Dwadasamsa", 16: "D16 Shodasamsa", 20: "D20 Vimsamsa",
    24: "D24 Chaturvimsamsa", 27: "D27 Saptavimsamsa", 30: "D30 Trimsamsa",
    40: "D40 Khavedamsa", 45: "D45 Akshavedamsa", 60: "D60 Shashtiamsa",
}


def _norm_sign(n: int) -> int:
    return ((int(n) - 1) % 12) + 1


def _modality(sign_no: int) -> str:
    if sign_no in {1, 4, 7, 10}:
        return "movable"
    if sign_no in {2, 5, 8, 11}:
        return "fixed"
    return "dual"


def _element(sign_no: int) -> str:
    return ["fire", "earth", "air", "water"][(sign_no - 1) % 4]


def _varga_sign(sign_no: int, degree: float, division: int) -> int:
    """Common Parashari-style software mapping.

    Some higher varga mapping conventions differ across lineages/software.
    V9 exposes the chosen mapping profile instead of claiming one universal
    authority. D1/D2/D3/D4/D7/D9/D10/D12/D30 are implemented with commonly
    used formulas; higher vargas use a transparent common software profile.
    """
    s = int(sign_no); d = float(degree) % 30
    if division == 1:
        return s
    if division == 2:  # Hora: Sun/Leo and Moon/Cancer
        first = d < 15
        if s % 2 == 1:
            return 5 if first else 4
        return 4 if first else 5
    if division == 3:  # Drekkana: same, 5th, 9th
        part = min(2, int(d / 10))
        return _norm_sign(s + 4 * part)
    if division == 4:  # same, 4th, 7th, 10th
        part = min(3, int(d / 7.5))
        return _norm_sign(s + 3 * part)
    if division == 7:
        part = min(6, int(d / (30 / 7)))
        start = s if s % 2 == 1 else _norm_sign(s + 6)
        return _norm_sign(start + part)
    if division == 9:
        return _navamsha_sign(s, d)
    if division == 10:
        return _dasamsa_sign(s, d)
    if division == 12:
        return _dwadasamsa_sign(s, d)
    if division == 16:
        part = min(15, int(d / (30 / 16)))
        start = {"movable": 1, "fixed": 5, "dual": 9}[_modality(s)]
        return _norm_sign(start + part)
    if division == 20:
        part = min(19, int(d / 1.5))
        start = {"movable": 1, "fixed": 9, "dual": 5}[_modality(s)]
        return _norm_sign(start + part)
    if division == 24:
        part = min(23, int(d / 1.25))
        # Common Siddhamsa software convention: odd from Leo, even from Cancer.
        start = 5 if s % 2 == 1 else 4
        return _norm_sign(start + part)
    if division == 27:
        part = min(26, int(d / (30 / 27)))
        start = {"fire": 1, "earth": 4, "air": 7, "water": 10}[_element(s)]
        return _norm_sign(start + part)
    if division == 30:
        # Classical unequal Trimsamsa portions by odd/even sign.
        if s % 2 == 1:
            bands = [(5, 1), (10, 11), (18, 9), (25, 3), (30, 7)]
        else:
            bands = [(5, 2), (12, 6), (20, 12), (25, 10), (30, 8)]
        for limit, mapped in bands:
            if d < limit or math.isclose(d, limit):
                return mapped
        return bands[-1][1]
    if division == 40:
        part = min(39, int(d / 0.75))
        start = 1 if s % 2 == 1 else 7
        return _norm_sign(start + part)
    if division == 45:
        part = min(44, int(d / (30 / 45)))
        start = {"movable": 1, "fixed": 5, "dual": 9}[_modality(s)]
        return _norm_sign(start + part)
    if division == 60:
        part = min(59, int(d / 0.5))
        # Transparent common software profile. Schools vary on reversal rules.
        start = s if s % 2 == 1 else _norm_sign(s + 6)
        return _norm_sign(start + part)
    raise ValueError(f"Unsupported varga D{division}")


def _houses_from_varga_rows(rows: List[Dict], asc_sign: int) -> List[Dict]:
    out = []
    for h in range(1, 13):
        sign_no = _norm_sign(asc_sign + h - 1)
        ps = []
        for p in rows:
            if _whole_sign_house(p["sign_no"], asc_sign) == h:
                ps.append({
                    "planet": p["planet"], "short": PLANET_SHORT.get(p["planet"], p["planet"][:2]),
                    "degree": p.get("degree"), "retrograde": bool(p.get("retrograde")), "flags": p.get("flags", []),
                })
        out.append({"house": h, "sign_no": sign_no, "sign": SIGNS[sign_no - 1][0], "planets": ps})
    return out


def shodashavarga_full(chart: Dict) -> Dict:
    va = chart.get("vedic_aux") or vedic_auxiliary(chart)
    lag = va.get("lagna", {})
    asc_sign = int(lag.get("sign_no", 1))
    asc_deg = float(lag.get("degree_in_sign", 0))
    pdetails = va.get("planet_details", [])
    divisions = [1, 2, 3, 4, 7, 9, 10, 12, 16, 20, 24, 27, 30, 40, 45, 60]
    charts = {}
    compact = []
    for div in divisions:
        a = _varga_sign(asc_sign, asc_deg, div)
        rows = []
        for p in pdetails:
            ps = _varga_sign(int(p["sign_no"]), float(p["degree_in_sign"]), div)
            rows.append({
                "planet": p["planet"], "sign_no": ps, "degree": p["degree_in_sign"],
                "retrograde": "Retrograde" in (p.get("flags") or []), "flags": [],
            })
        houses = _houses_from_varga_rows(rows, a)
        key = f"D{div}"
        charts[key] = {"division": div, "label": VARGA_LABELS[div], "asc_sign_no": a, "asc_sign": SIGNS[a - 1][0], "houses": houses}
        compact.append({"key": key, "label": VARGA_LABELS[div], "asc_sign_no": a, "asc_sign": SIGNS[a - 1][0], "status": "Calculated"})
    return {
        "profile": "Parashari-common-v9",
        "calculated": compact,
        "charts": charts,
        "method_note": "V9 enables all 16 standard varga workspaces. Higher-varga conventions can vary by lineage/software; the active mapping profile is shown and should be audited before professional use.",
    }

# ---------------------------------------------------------------------------
# Yogini Dasha
# ---------------------------------------------------------------------------

YOGINIS = [
    ("Mangala", "Moon", 1), ("Pingala", "Sun", 2), ("Dhanya", "Jupiter", 3),
    ("Bhramari", "Mars", 4), ("Bhadrika", "Mercury", 5), ("Ulka", "Saturn", 6),
    ("Siddha", "Venus", 7), ("Sankata", "Rahu", 8),
]


def yogini_dasha(chart: Dict, cycles: int = 3) -> Dict:
    va = chart.get("vedic_aux") or vedic_auxiliary(chart)
    p = va.get("panchang", {})
    nak_no = int((p.get("nakshatra") or {}).get("number", 1))
    # Common rule: (nakshatra number + 3) modulo 8; zero => Sankata.
    rem = (nak_no + 3) % 8
    idx = 7 if rem == 0 else rem - 1
    moon = next((x for x in va.get("planet_details", []) if x.get("planet") == "Moon"), None)
    progress = 0.0
    if moon:
        nak_size = 360 / 27
        lon = float(moon.get("longitude", 0)) % 360
        progress = (lon % nak_size) / nak_size
    name, lord, yrs = YOGINIS[idx]
    balance = max(0.01, yrs * (1 - progress))
    birth = datetime.fromisoformat(chart.get("profile", {}).get("birth_date", "2000-01-01"))
    rows = []
    cur = birth
    end = cur + timedelta(days=balance * 365.2425)
    rows.append({"yogini": name, "lord": lord, "start": cur.date().isoformat(), "end": end.date().isoformat(), "years": round(balance, 2), "partial_at_birth": True})
    i = (idx + 1) % 8
    target = cycles * 36
    while (end - birth).days < target * 365.2425:
        nm, ld, yy = YOGINIS[i]
        nxt = end + timedelta(days=yy * 365.2425)
        rows.append({"yogini": nm, "lord": ld, "start": end.date().isoformat(), "end": nxt.date().isoformat(), "years": yy, "partial_at_birth": False})
        end = nxt; i = (i + 1) % 8
        if len(rows) > 40:
            break
    today = datetime.now().date()
    active = next((r for r in rows if datetime.fromisoformat(r["start"]).date() <= today < datetime.fromisoformat(r["end"]).date()), None)
    return {
        "birth_nakshatra_no": nak_no, "starting_yogini": name, "balance_at_birth_years": round(balance, 2),
        "active": active, "periods": rows,
        "method_note": "Common 36-year Yogini Dasha sequence. It is a Vedic auxiliary timing system, kept separate from Lal Kitab cycles.",
    }

# ---------------------------------------------------------------------------
# Shadbala-style research index (not classical virupa total)
# ---------------------------------------------------------------------------

NAISARGIKA = {"Sun": 60, "Moon": 51, "Venus": 43, "Jupiter": 34, "Mercury": 26, "Mars": 17, "Saturn": 9, "Rahu": 15, "Ketu": 15}
DIG_HOUSE = {"Sun": 10, "Mars": 10, "Jupiter": 1, "Mercury": 1, "Moon": 4, "Venus": 4, "Saturn": 7, "Rahu": 7, "Ketu": 1}


def _distance_houses(a: int, b: int) -> int:
    d = abs(a - b)
    return min(d, 12 - d)


def shadbala_research(chart: Dict) -> Dict:
    va = chart.get("vedic_aux") or vedic_auxiliary(chart)
    rows = []
    by = {x["planet"]: x for x in va.get("planet_details", [])}
    sun = by.get("Sun", {})
    for name, p in by.items():
        h = int(p.get("house", 1)); sign = int(p.get("sign_no", 1)); flags = p.get("flags") or []
        # Sthana index: dignity + angular/trinal placement + vargottama.
        sthana = 50
        if name in VEDIC_EXALT and sign == VEDIC_EXALT[name]: sthana += 28
        if name in VEDIC_DEBIL and sign == VEDIC_DEBIL[name]: sthana -= 28
        if h in {1, 4, 7, 10}: sthana += 8
        if h in {1, 5, 9}: sthana += 8
        if "Vargottama" in flags: sthana += 8
        sthana = max(0, min(100, sthana))
        # Dig index peaks in a planet's conventional directional house.
        target = DIG_HOUSE.get(name, 1)
        dig = max(0, 100 - _distance_houses(h, target) * 16)
        # Kala index: simplified diurnal/nocturnal and weekday context.
        birth_time = chart.get("profile", {}).get("birth_time", "12:00")
        hour = int(str(birth_time).split(":")[0])
        day = 6 <= hour < 18
        diurnal = name in {"Sun", "Jupiter", "Saturn"}
        nocturnal = name in {"Moon", "Mars", "Venus"}
        kala = 62 if (day and diurnal) or ((not day) and nocturnal) else 48
        if name == "Mercury": kala = 56
        # Cheshta index: retrograde boosts apparent-motion reference; combustion lowers it.
        cheshta = 55
        if "Retrograde" in flags and name not in {"Rahu", "Ketu"}: cheshta += 25
        if "Combust ref" in flags: cheshta -= 22
        cheshta = max(0, min(100, cheshta))
        nais = max(0, min(100, round(NAISARGIKA.get(name, 25) / 60 * 100)))
        # Drik reference: simple angular relation density to benefic/malefic planets.
        support = 0; caution = 0
        benefics = {"Jupiter", "Venus", "Mercury", "Moon"}
        malefics = {"Mars", "Saturn", "Rahu", "Ketu", "Sun"}
        lon = float(p.get("longitude", 0))
        for other, op in by.items():
            if other == name: continue
            sep = abs((float(op.get("longitude", 0)) - lon) % 360)
            sep = min(sep, 360 - sep)
            near_aspect = min(abs(sep - x) for x in (0, 60, 90, 120, 180)) <= 6
            if near_aspect:
                if other in benefics: support += 1
                if other in malefics: caution += 1
        drik = max(0, min(100, 50 + 8 * support - 8 * caution))
        comps = {"sthana": round(sthana), "dig": round(dig), "kala": round(kala), "cheshta": round(cheshta), "naisargika": round(nais), "drik": round(drik)}
        total = round(sum(comps.values()) / 6, 1)
        rows.append({"planet": name, "index": total, "components": comps, "house": h, "sign": p.get("sign"), "flags": flags})
    return {
        "rows": sorted(rows, key=lambda x: x["index"], reverse=True),
        "method_note": "V9 Shadbala Research Index displays six named component indexes on a 0–100 software scale. It is not the classical virupa/rupa Shadbala total and must not be presented as such.",
    }

# ---------------------------------------------------------------------------
# Muhurta planning assistant
# ---------------------------------------------------------------------------

CATEGORY_RULES = {
    "general": {"domains": [], "weekday": []},
    "business": {"domains": ["business", "money", "leadership"], "weekday": [2, 3, 4]},
    "job": {"domains": ["career", "reputation", "discipline"], "weekday": [0, 2, 3, 5]},
    "property": {"domains": ["property", "money", "family"], "weekday": [0, 3, 4]},
    "travel": {"domains": ["foreign", "network"], "weekday": [0, 2, 3, 4]},
    "education": {"domains": ["education", "creativity"], "weekday": [2, 3, 4]},
    "relationship": {"domains": ["relationship", "family"], "weekday": [0, 4]},
    "launch": {"domains": ["business", "reputation", "creativity", "network"], "weekday": [2, 3, 4]},
}


def _moon_tara_score(natal_nak: int, transit_nak: int) -> Tuple[float, str]:
    # 9-fold Tara cycle. A compact planning signal only.
    pos = ((transit_nak - natal_nak) % 27) % 9 + 1
    names = {1:"Janma",2:"Sampat",3:"Vipat",4:"Kshema",5:"Pratyari",6:"Sadhaka",7:"Naidhana",8:"Mitra",9:"Parama Mitra"}
    good = {2: 8, 4: 7, 6: 9, 8: 7, 9: 9}
    caution = {3: -7, 5: -6, 7: -9}
    return float(good.get(pos, caution.get(pos, 0))), names[pos]


def muhurta_finder(chart: Dict, start_date: str, end_date: str, category: str = "general", max_results: int = 12) -> Dict:
    start = datetime.fromisoformat(start_date).date(); end = datetime.fromisoformat(end_date).date()
    if end < start:
        start, end = end, start
    if (end - start).days > 60:
        end = start + timedelta(days=60)
    profile = chart.get("profile", {})
    tz = float(profile.get("timezone_offset", 5.5))
    natal_va = chart.get("vedic_aux") or vedic_auxiliary(chart)
    natal_nak = int(((natal_va.get("panchang") or {}).get("nakshatra") or {}).get("number", 1))
    rules = CATEGORY_RULES.get(category, CATEGORY_RULES["general"])
    rows = []
    d = start
    while d <= end:
        calc = calc_planets("Muhurta", d.isoformat(), "12:00", tz)
        temp_chart = {"profile": {**profile, "birth_date": d.isoformat(), "birth_time": "12:00"}, "placements": calc["placements"]}
        pan = panchang_from_chart(temp_chart["profile"], calc["placements"])
        score = 50.0; reasons=[]; cautions=[]
        wd = d.weekday()
        if wd in rules.get("weekday", []): score += 6; reasons.append(f"weekday alignment: {pan.get('vara')}")
        tithi_no = int((pan.get("tithi") or {}).get("number", 1))
        if tithi_no in {2,3,5,7,10,11,12,13}: score += 4; reasons.append("generally workable tithi reference")
        if tithi_no in {4,8,9,14,15,30}: score -= 4; cautions.append("tithi requires tradition-specific review")
        tr_nak = int((pan.get("nakshatra") or {}).get("number", 1))
        tara_delta, tara_name = _moon_tara_score(natal_nak, tr_nak)
        score += tara_delta; (reasons if tara_delta > 0 else cautions if tara_delta < 0 else reasons).append(f"Tara: {tara_name}")
        # Add natal annual domain synthesis relevant to category.
        fy = forecast_year(chart, d.year)
        dom_scores = []
        for key in rules.get("domains", []):
            if key in fy.get("domains", {}): dom_scores.append(float(fy["domains"][key].get("score", 50)))
        if dom_scores:
            avg = sum(dom_scores)/len(dom_scores)
            score += (avg-50)*0.18
            reasons.append(f"natal annual {category} context {round(avg)}/100")
        score=max(0,min(100,score))
        rows.append({
            "date": d.isoformat(), "weekday": pan.get("vara"), "score": round(score,1), "band": "Supportive" if score>=64 else "Balanced" if score>=48 else "Review",
            "tithi": f"{(pan.get('tithi') or {}).get('paksha','')} {(pan.get('tithi') or {}).get('name','')}",
            "nakshatra": (pan.get("nakshatra") or {}).get("name"), "tara": tara_name,
            "reasons": reasons[:5], "cautions": cautions[:4],
        })
        d += timedelta(days=1)
    ranked = sorted(rows, key=lambda x: x["score"], reverse=True)[:max(1,min(int(max_results),20))]
    return {
        "category": category, "start_date": start.isoformat(), "end_date": end.isoformat(), "ranked": ranked, "all_days": rows,
        "method_note": "Muhurta AI is a planning assistant combining Panchang/Tara reference signals with the software's natal annual context. It does not guarantee outcomes and should not be used alone for medical, legal, financial or safety-critical timing.",
    }

# ---------------------------------------------------------------------------
# Transit wheel/time series
# ---------------------------------------------------------------------------


def transit_series(chart: Dict, start_date: str, days: int = 31) -> Dict:
    start = datetime.fromisoformat(start_date).date()
    days = max(1, min(int(days), 93))
    tz = float(chart.get("profile", {}).get("timezone_offset", 5.5))
    series = []
    for i in range(days):
        d = start + timedelta(days=i)
        calc = calc_planets("Transit series", d.isoformat(), "12:00", tz)
        planets = [{"planet": p["planet"], "short": PLANET_SHORT.get(p["planet"],p["planet"][:2]), "longitude": round(float(p["longitude"]),3), "sign": p["sign"], "degree": p["degree_in_sign"], "retrograde": bool(p.get("retrograde"))} for p in calc["placements"]]
        series.append({"date": d.isoformat(), "planets": planets})
    return {"start_date": start.isoformat(), "days": days, "series": series, "method_note": "Sidereal transit positions sampled at local-noon reference time for visual exploration."}

# ---------------------------------------------------------------------------
# Explainable rule graph
# ---------------------------------------------------------------------------


def rule_graph(chart: Dict, year: Optional[int] = None) -> Dict:
    year = int(year or datetime.now().year)
    fy = forecast_year(chart, year)
    nodes = []; edges = []; seen=set()
    def add_node(nid: str, label: str, kind: str, score=None, detail=""):
        if nid in seen: return
        seen.add(nid); nodes.append({"id":nid,"label":label,"kind":kind,"score":score,"detail":detail})
    for p in chart.get("placements", []):
        pid=f"planet:{p['planet']}"; add_node(pid,p['planet'],"planet",p.get("score"),f"H{p.get('house')} {p.get('sign')}")
        hid=f"house:{p.get('house')}"; add_node(hid,f"House {p.get('house')}","house",None,"")
        edges.append({"from":pid,"to":hid,"type":"occupies","weight":1})
    domains = fy.get("domains", {})
    for key, v in domains.items():
        did=f"domain:{key}"; add_node(did,v.get("label",key),"domain",v.get("score"),v.get("band", ""))
        rule = DOMAIN_RULES.get(key, {})
        for pname in rule.get("planets", []):
            if f"planet:{pname}" in seen: edges.append({"from":f"planet:{pname}","to":did,"type":"supports-domain","weight":2})
        for h in rule.get("houses", []):
            hid=f"house:{h}"; add_node(hid,f"House {h}","house")
            edges.append({"from":hid,"to":did,"type":"domain-house","weight":1})
    remedy = chart.get("remedy_plan", {})
    for i, r in enumerate((remedy.get("primary") or [])[:3],1):
        rid=f"remedy:{i}"; add_node(rid,f"Remedy {i}","remedy",None,str(r.get("action",""))[:140])
        p=r.get("planet")
        if p and f"planet:{p}" in seen: edges.append({"from":f"planet:{p}","to":rid,"type":"reviewed-by","weight":1})
    return {"year":year,"nodes":nodes,"edges":edges,"method_note":"Graph visualizes software evidence links; an edge means the rule engine references that item, not causal proof."}

# ---------------------------------------------------------------------------
# Share / consultation summary
# ---------------------------------------------------------------------------


def whatsapp_summary(chart: Dict, year: Optional[int] = None) -> Dict:
    year=int(year or datetime.now().year)
    fy=forecast_year(chart,year)
    top=fy.get("top",[])[:3]; watch=fy.get("watch",[])[:2]
    rp=(chart.get("remedy_plan") or {}).get("primary",[])[:3]
    name=chart.get("profile",{}).get("name","Client")
    lines=[f"*Lal Kitab AI — {name}*",f"Year focus: {year}",""]
    if top:
        lines.append("*Stronger themes:* "+", ".join(f"{x.get('label')} ({x.get('score')}/100)" for x in top))
    if watch:
        lines.append("*Watch/manage:* "+", ".join(f"{x.get('label')} ({x.get('score')}/100)" for x in watch))
    if rp:
        lines.append("") ; lines.append("*Top low-risk remedy plan:*")
        for i,r in enumerate(rp,1): lines.append(f"{i}. {r.get('action')}")
    lines += ["","Traditional astrology guidance only — not a guarantee or substitute for professional advice."]
    return {"text":"\n".join(lines),"year":year,"name":name}


def v9_feature_catalog() -> List[Dict]:
    return [
        {"key":"vargas16","label":"16 Varga Lab","status":"enabled"},
        {"key":"yogini","label":"Yogini Dasha","status":"enabled"},
        {"key":"shadbala_research","label":"Six-component Strength Research","status":"enabled"},
        {"key":"muhurta","label":"Muhurta AI Planner","status":"enabled"},
        {"key":"transit_wheel","label":"Animated Transit Wheel","status":"enabled"},
        {"key":"rule_graph","label":"Why-this-Prediction Rule Graph","status":"enabled"},
        {"key":"voice","label":"Browser Voice Consultation","status":"enabled"},
        {"key":"practice_crm","label":"Appointments + Payments + Team Console","status":"enabled"},
        {"key":"share","label":"WhatsApp-ready Client Summary","status":"enabled"},
    ]
