# Shri Sumitacharya Public-Source Notes — V12

## Public sources indexed

V12 currently exposes **18 public source entries** spanning official site/service indexes, public methodology/service pages and official YouTube references.

- Official website: https://sumitacharya.in/
- 100+ page personalized Kundali report overview: https://sumitacharya.in/unlock-your-destiny-comprehensive-100-page-personalized-kundali-report-by-shri-sumitacharya-ji-maharaj/
- 108-page Janam Kundali service: https://sumitacharya.in/product/janam-kundali-108-pages-shri-sumitacharya/
- Marriage Kundali Milan: https://sumitacharya.in/product/kundali-milan-marriage-sumitacharya-best-astrologer/
- Business Astrology + Vastu: https://sumitacharya.in/product/grow-business-with-astrology-strategic-help-for-offices-shops/
- Astrology Services archive (includes Baby Birth Report / Lucky Name): https://sumitacharya.in/product-category/astrology-services/
- Consultation / Form Users archive: https://sumitacharya.in/product-category/form-users/
- Vedic Astrology service tag: https://sumitacharya.in/product-tag/vedic-astrology/
- Astrology Services archive page 2: https://sumitacharya.in/product-category/astrology-services/page/2/
- Official shop/service index: https://sumitacharya.in/shop/
- Grah Dosh Shanti: https://sumitacharya.in/product/grah-dosh-shanti-puja-shri-sumitacharya-ji-maharaj-hawan/
- Pooja archive: https://sumitacharya.in/product-category/pooja/
- Shukra Grah Shanti public page: https://sumitacharya.in/product/shukra-grah-shanti-online-pooja-shri-sumitacharya-ji/
- Trijata Dosh public article: https://sumitacharya.in/trijata-dosh-hawan-nivaran/
- Terms and Conditions / disclaimer: https://sumitacharya.in/terms-and-conditions/
- Official YouTube channel: https://www.youtube.com/@Sumitacharyajimaharaj
- Public LIVE “Jeevan Ke Samadhan”: https://www.youtube.com/watch?v=PiEaqkiOADY
- Public “Predictions for 2025”: https://www.youtube.com/watch?v=0nzQFw1VQQQ

## What was implemented

Public descriptions show a broad workflow around detailed birth-chart analysis, divisional charts, yogas/doshas, multi-year career/business/finance/relationship themes, marriage matching, business/Vastu, baby-name services and remedy classes such as mantras, gemstones, charity, lifestyle adjustments and graha-shanti rituals. V12 uses these **topic categories and workflow breadth** to organize an independent software layer.

## What was NOT copied

- Paid 108-page / 100+ page report content.
- Paid consultation notes or remedies.
- Proprietary calculations or decision rules.
- Copyrighted article bodies.
- Full YouTube transcripts.
- High-stakes predictions about death, widowhood, disease, lifespan, fertility, crime, legal cases or investment returns.

## Trijata implementation boundary

The public article lists research conditions involving the 7th house/lord, the 8th house, Saturn with Rahu/Ketu, weak Lagna lord, karaka planets and 6/8/12 connections. V12 uses a conservative **candidate-screen** only and explicitly refuses the article's high-stakes outcome implications. The software does not infer spouse longevity, death, widowhood, disease or unavoidable misfortune.

## Affiliation

V12 is an independent research/software implementation and is not affiliated with, licensed by, or endorsed by Shri Sumitacharya Ji Maharaj or Sumitacharya Gurukul unless separately licensed.
