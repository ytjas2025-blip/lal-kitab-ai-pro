"""V19.2.3 near-term 15-day traditional astrology radar.
Combines natal alert structure with date-specific sidereal transit snapshots and active Vimshottari lords.
Outputs interpretive watch/support windows, never event probabilities or guarantees.
"""
from datetime import datetime, timedelta, timezone
from typing import Dict
from astro_v8 import transit_snapshot
from critical_alerts_v19 import SITUATIONS, REMEDIES, OPPORTUNITIES

SEV={'Quiet':0,'Low':1,'Watch':2,'Elevated':3}

def _local_now(chart):
    off=float((chart.get('profile') or {}).get('timezone_offset',5.5) or 5.5)
    return datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=off))).replace(tzinfo=None)

def _active_lords(chart):
    return [str(x.get('lord')) for x in ((chart.get('dasha_pro') or {}).get('active_chain') or []) if x.get('lord')]

def _transit_hits(chart, when, houses, planets):
    try: rows=(transit_snapshot(chart,when) or {}).get('placements',[]) or []
    except Exception: rows=[]
    hits=[]
    for p in rows:
        if p.get('planet') in planets and int(p.get('natal_whole_sign_house',0) or 0) in houses:
            hits.append(f"Transit {p.get('planet')} H{p.get('natal_whole_sign_house')}")
    return hits

def _natal_hits(chart,houses,planets):
    return [f"Natal {p.get('planet')} H{p.get('house')}" for p in chart.get('placements',[]) if p.get('planet') in planets and int(p.get('house',0) or 0) in houses]

def sudden_radar(chart:Dict, days:int=15)->Dict:
    days=max(1,min(int(days),15)); start=_local_now(chart); dasha=_active_lords(chart)
    daily=[]
    for i in range(days):
        dt=start+timedelta(days=i); candidates=[]
        for key,label,cat,houses,planets in SITUATIONS:
            nh=_natal_hits(chart,set(houses),planets); th=_transit_hits(chart,dt,set(houses),planets)
            dh=[f"Active Dasha: {x}" for x in dasha if x in planets]
            # Transit agreement is required for a prominent near-term watch; natal alone is background.
            score=min(6,len(nh)+2*len(th)+(1 if dh else 0))
            if th and score>=4: level='Elevated'
            elif th and score>=2: level='Watch'
            elif th or (nh and dh): level='Low'
            else: level='Quiet'
            candidates.append({'key':key,'label':label,'category':cat,'level':level,'score':score,
                'evidence':(nh[:2]+th[:3]+dh[:1]),'upay':REMEDIES.get(cat,[])[:2]})
        candidates.sort(key=lambda x:(SEV[x['level']],x['score']),reverse=True)
        # opportunities: require transit support too
        opp=[]
        for key,label,houses,planets in OPPORTUNITIES:
            nh=_natal_hits(chart,set(houses),planets); th=_transit_hits(chart,dt,set(houses),planets); dh=[x for x in dasha if x in planets]
            s=len(nh)+2*len(th)+(1 if dh else 0)
            if th and s>=3: opp.append({'key':key,'label':label,'strength':'Supportive','evidence':(nh[:2]+th[:3]+([f"Active Dasha: {dh[0]}"] if dh else []))})
        opp.sort(key=lambda x:len(x['evidence']),reverse=True)
        daily.append({'date':dt.strftime('%Y-%m-%d'),'day':dt.strftime('%a'),'top_watch':candidates[0],
                      'watches':[x for x in candidates if x['level'] in ('Elevated','Watch')][:3],
                      'opportunities':opp[:2]})
    # Group consecutive days by top situation, max 4 days for readable micro-windows.
    windows=[]
    for row in daily:
        t=row['top_watch']; signature=t['key'] if t['level']!='Quiet' else 'quiet'
        if windows and windows[-1]['signature']==signature and len(windows[-1]['dates'])<4:
            windows[-1]['dates'].append(row['date']); windows[-1]['evidence']=list(dict.fromkeys(windows[-1]['evidence']+t['evidence']))[:6]
            if SEV[t['level']]>SEV[windows[-1]['level']]: windows[-1]['level']=t['level']
        else:
            windows.append({'signature':signature,'label':t['label'] if signature!='quiet' else 'No major near-term watch','category':t.get('category','general'),
                            'level':t['level'] if signature!='quiet' else 'Quiet','dates':[row['date']],'evidence':t['evidence'] if signature!='quiet' else [],
                            'upay':t.get('upay',[]) if signature!='quiet' else []})
    # top overall situations, deduped
    flat={}
    for row in daily:
        for x in ([row['top_watch']] + row['watches']):
            if x.get('level') == 'Quiet': continue
            old=flat.get(x['key'])
            if not old or x['score']>old['score']: flat[x['key']]={**x,'date':row['date']}
    top=sorted(flat.values(),key=lambda x:(SEV[x['level']],x['score']),reverse=True)[:5]
    oppflat={}
    for row in daily:
        for x in row['opportunities']:
            if x['key'] not in oppflat: oppflat[x['key']]={**x,'date':row['date']}
    return {'as_of':start.strftime('%Y-%m-%d %H:%M'),'days':days,'top_situations':top,'top_opportunities':list(oppflat.values())[:5],
            'windows':windows,'daily':daily,'active_dasha_lords':dasha,
            'method_note':'Near-term radar requires date-specific transit agreement with natal structure; active Vimshottari lords add timing support. It is an interpretive planning aid, not an event probability model.',
            'safety':'Traditional astrological indicators only. Health, legal, financial, relationship and safety decisions require real-world evidence and qualified professional advice.'}
