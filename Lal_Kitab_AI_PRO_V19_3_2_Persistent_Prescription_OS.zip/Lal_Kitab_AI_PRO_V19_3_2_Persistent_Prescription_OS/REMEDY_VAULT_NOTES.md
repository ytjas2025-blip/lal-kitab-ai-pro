# Remedy Vault Notes — V12

## Count
The V12 vault contains **4,800 indexed records**.

## Source-aware extensions
V12 keeps the existing safety-normalized core and adds two separately-labelled public-source research families:

- **900 GD Vashist/Astroscience source-aware cards** from V11.
- **1,200 Shri Sumitacharya public-source-aware cards** in V12.

The 1,200 V12 cards contain 1,080 planet×house planning cards (9 planets × 12 houses × 10 independent protocols) plus 120 source/method/safety/category cards. Each can carry `source_name`, `source_url`, `source_kind`, `source_class`, safety level and chart-relevance score.

They are **independent paraphrases and software protocols**, not official prescriptions, paid-report extracts, copyrighted article text, private consultation remedies or full video transcripts.

## Smart Remedy Protocol
The planner:
- scores chart relevance,
- prefers a small Top-3 core protocol,
- diversifies planets/categories where possible,
- provides backups,
- flags duplicate-category overload,
- supports separately-ranked GD Vashist and Shri Sumitacharya public-source cards,
- recommends a 14-day check followed by a 43-day review where appropriate.

## Safety filter
The software blocks or replaces operational guidance involving:
- water/land pollution,
- animal harm or unsafe feeding,
- unsafe fire/smoke,
- ingestion of metals/ash/unknown substances,
- replacing medical treatment,
- expensive/borrowed-money astrological purchases,
- self-harm or extreme deprivation,
- illegal activity,
- guaranteed financial/health/relationship outcomes.

## Source boundary
A public URL may be stored with a short independently-written summary. Paid books/reports, proprietary rule databases, consultations and complete transcripts are not bulk-copied. Users can open the original source for context.
