"""V19 Critical Alerts & Opportunity Intelligence.
Traditional astrology screening only: never deterministic medical/legal/financial/relationship claims.
"""
from typing import Dict,List

SITUATIONS = [
("health_stress","Health / hospital-type stress","health",[6,8,12],["Mars","Saturn","Rahu","Ketu"]),
("surgery_watch","Surgery / procedure-type traditional watch","health",[6,8,12],["Mars","Ketu","Saturn"]),
("injury_caution","Accident / injury caution","health",[3,6,8,12],["Mars","Saturn","Rahu"]),
("recovery_support_needed","Recovery / recuperation pressure","health",[6,8,12],["Saturn","Ketu"]),
("legal_pressure","Legal / court / dispute pressure","legal",[6,7,8,12],["Saturn","Mars","Rahu"]),
("confinement","Confinement / restrictive circumstances","legal",[6,8,12],["Saturn","Rahu","Ketu"]),
("police_compliance","Police / compliance / investigation vigilance","legal",[6,8,10,12],["Saturn","Rahu","Mars"]),
("authority","Government / authority pressure","legal",[6,8,10,12],["Sun","Saturn","Rahu"]),
("tax_docs","Tax / documentation / compliance stress","legal",[6,8,10,12],["Mercury","Saturn","Rahu"]),
("financial_loss","Capital / financial pressure","money",[2,8,11,12],["Saturn","Rahu","Ketu"]),
("debt","Debt / EMI / cash-flow pressure","money",[6,8,12],["Saturn","Mars","Rahu"]),
("fraud","Fraud / documentation vigilance","money",[2,8,12],["Mercury","Rahu","Ketu"]),
("theft","Theft / valuables vigilance","money",[2,8,12],["Rahu","Ketu","Mars"]),
("cyber_fraud","Cyber / online transaction vigilance","money",[3,8,11,12],["Mercury","Rahu"]),
("sudden_expense","Sudden expense / repair pressure","money",[8,12],["Mars","Saturn","Rahu"]),
("investment_risk","High-risk investment / speculation caution","money",[5,8,12],["Rahu","Mars","Saturn"]),
("payment_block","Payment / receivables delay","money",[2,6,8,11],["Saturn","Mercury","Rahu"]),
("business_pressure","Business / partnership pressure","career",[7,10,11,12],["Saturn","Rahu","Ketu"]),
("business_restructure","Business restructuring / shutdown pressure","career",[8,10,12],["Saturn","Ketu","Rahu"]),
("partner_conflict","Business partner conflict","career",[7,8,12],["Mars","Saturn","Rahu"]),
("career_break","Career break / role-change pressure","career",[6,10,11,12],["Saturn","Ketu","Rahu"]),
("job_loss_watch","Job-loss / termination-type pressure","career",[6,8,10,12],["Saturn","Ketu","Rahu"]),
("boss_conflict","Boss / workplace politics pressure","career",[6,10],["Sun","Mars","Saturn","Rahu"]),
("reputation","Reputation / controversy pressure","career",[1,8,10,12],["Sun","Saturn","Rahu"]),
("scandal_exposure","Hidden matter / scandal exposure vigilance","career",[8,10,12],["Sun","Mercury","Rahu"]),
("relationship_strain","Relationship strain / separation pressure","relationship",[7,8,12],["Venus","Mars","Saturn","Rahu","Ketu"]),
("secrecy_attraction","Relationship secrecy / unconventional attraction","relationship",[5,7,8,12],["Venus","Mars","Rahu"]),
("trust_jealousy","Trust / jealousy / boundary pressure","relationship",[5,7,8],["Venus","Mars","Rahu"]),
("family_opposition","Family opposition to relationship","relationship",[2,4,7],["Moon","Mars","Saturn","Rahu"]),
("family_conflict","Family / domestic tension","family",[2,4,7,8],["Moon","Mars","Saturn","Rahu"]),
("sibling_conflict","Sibling / communication conflict","family",[3,6,8],["Mars","Saturn","Rahu"]),
("inheritance_dispute","Inheritance / shared-asset dispute","property",[2,4,8,12],["Saturn","Mars","Rahu"]),
("property_dispute","Property / ancestral asset dispute","property",[4,8,12],["Mars","Saturn","Rahu"]),
("construction_delay","Construction / renovation delay","property",[4,8,12],["Saturn","Mars","Rahu"]),
("vehicle_expense","Vehicle / machinery repair vigilance","property",[4,8,12],["Mars","Saturn","Rahu"]),
("travel_delay","Travel / visa / relocation delay","travel",[3,9,12],["Saturn","Rahu","Ketu"]),
("forced_relocation","Forced / stressful relocation pressure","travel",[4,8,12],["Saturn","Rahu","Ketu"]),
("education_pressure","Education / examination pressure","education",[4,5,9],["Mercury","Jupiter","Saturn","Rahu"]),
("study_break","Education interruption / course-change pressure","education",[4,5,8,12],["Mercury","Saturn","Ketu"]),
("decision_confusion","Decision confusion / overthinking pressure","mind",[1,4,8,12],["Moon","Mercury","Rahu","Ketu"]),
("isolation","Isolation / withdrawal phase","mind",[4,8,12],["Moon","Saturn","Ketu"]),
("aggression","Conflict / aggression window","mind",[3,6,7,8],["Mars","Saturn","Rahu"]),
]
OPPORTUNITIES=[
("career_breakthrough","Career breakthrough / recognition",[9,10,11],["Sun","Jupiter","Mercury"]),
("wealth_support","Income / wealth-support window",[2,5,9,11],["Jupiter","Venus","Mercury"]),
("property_support","Property / home-support window",[4,9,11],["Mars","Venus","Jupiter"]),
("relationship_support","Marriage / relationship-support window",[5,7,9,11],["Venus","Jupiter","Moon"]),
("foreign_support","Foreign / relocation opportunity",[3,9,12],["Jupiter","Rahu","Mercury"]),
("education_support","Education / certification support",[4,5,9],["Mercury","Jupiter"]),
]
REMEDIES={
"health":["Prioritize real medical evaluation for symptoms; astrology is not diagnosis.","Use a simple, non-harmful prayer/meditation or seva practice consistent with your beliefs."],
"legal":["Keep documents, deadlines and compliance in order; use a qualified lawyer for an actual dispute.","Prefer non-harmful charity/seva over fear-based or expensive remedies."],
"money":["Reduce unnecessary leverage and verify large transactions independently.","Use a simple budget/charity discipline; do not treat a remedy as financial protection."],
"career":["Document agreements and keep a practical fallback plan.","Choose a low-cost discipline/seva practice linked to the selected source profile."],
"relationship":["Use communication, boundaries and evidence; never treat an astrology flag as proof of infidelity.","Prefer counselling/communication plus a non-harmful spiritual practice if desired."],
"family":["De-escalate conflict and keep financial/property agreements documented.","Use family seva/charity or prayer as an optional traditional practice."],
"property":["Verify title, contracts, insurance and approvals with professionals.","Avoid destructive, illegal, animal-harm or unknown-substance remedies."],
"travel":["Recheck documents, insurance, schedules and transport safety.","Optional prayer/charity may be used as spiritual support, not as a safety substitute."],
"education":["Use a study plan, mock tests and professional guidance where useful.","Optional learning-related charity/seva can be used as a traditional practice."],
"mind":["Use sleep, routine, conflict de-escalation and qualified mental-health support if there is a real concern.","Optional meditation/prayer can be spiritual support, not a substitute for care."],
}

def _index(placements): return {p.get('planet'):p for p in placements}
def _score(by,houses,planets):
    hits=[]; score=0
    for pl in planets:
        p=by.get(pl)
        if p and int(p.get('house',0)) in houses:
            score+=1; hits.append(f"{pl} H{p.get('house')}")
    return score,hits

def critical_alert_center(chart:Dict)->Dict:
    by=_index(chart.get('placements',[])); alerts=[]
    for key,label,cat,houses,planets in SITUATIONS:
        score,hits=_score(by,set(houses),planets)
        level='No meaningful natal flag' if score==0 else 'Low' if score==1 else 'Watch' if score==2 else 'Elevated'
        alerts.append({'key':key,'label':label,'category':cat,'level':level,'evidence':hits,'evidence_quality':'Weak' if score<2 else 'Moderate' if score==2 else 'Strong natal cluster','remedies':REMEDIES.get(cat,[])[:2], 'note':'Traditional screening flag only. Dasha, transit, divisional and cancellation layers must agree before prioritizing an alert.'})
    opp=[]
    for key,label,houses,planets in OPPORTUNITIES:
        score,hits=_score(by,set(houses),planets); level='Background' if score==0 else 'Supportive' if score==1 else 'Strong natal support'
        opp.append({'key':key,'label':label,'level':level,'evidence':hits})
    ranked=sorted(alerts,key=lambda x:{'Elevated':3,'Watch':2,'Low':1,'No meaningful natal flag':0}[x['level']],reverse=True)
    return {'top_alerts':ranked[:5],'alerts':alerts,'opportunities':opp,'severity_scale':['No meaningful natal flag','Low','Watch','Elevated'],'safety':'These are traditional astrological indicators, not certain events. Never infer a crime, affair, diagnosis, surgery, loss or legal outcome from an alert.'}
