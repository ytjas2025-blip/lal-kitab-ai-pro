# V19 — Cumulative Intelligence Build

- Preserves V18/V18.2 modules and premium UI.
- Fixes natal house mapping: zodiac sign number is no longer treated as house number.
- Adds explicit `sign_no`, `natural_zodiac_index`, `whole_sign_house`; `house` is now the Lagna-relative whole-sign natal house for compatibility.
- Adds sidereal Lahiri Lagna calculation from birth time + coordinates.
- Adds golden regression fixture: 20 Jul 1989 15:07:30 Ludhiana — Scorpio Lagna; Sun H9, Moon H3, Mars H9, Mercury H9, Jupiter H8, Venus H10, Saturn H2, Rahu H4, Ketu H10.
- Adds Critical Alerts + Remedies engine with health-stress, injury, legal/confinement, authority, money/debt/fraud, business/career, reputation, relationship/secrecy, family, property, travel, education and sudden-expense screens plus positive opportunity scanner.
- Sensitive alerts are non-deterministic and include practical safety guidance; astrology never establishes diagnosis, crime, affair, legal outcome or guaranteed financial loss.
- Adds Visual Intelligence Studio metadata: Graha bars, Bhava bars, Drishti/relationship networks, Yoga Galaxy, Dosha X-Ray, Dasha waterfall, Varga matrix, Sade Sati cinema, Astro Time Machine, Prediction MRI, Astroverse 360 and 3D-ready visual modules.
- Enlarges UI typography and retains reduced-motion/performance design requirements.
- Adds Calculation Guard metadata to keep sign / whole-sign house / Bhav Chalit / KP / Lal Kitab interpretation separate.

## Important
Many extraordinary visualization/research ideas discussed are represented as modular roadmap surfaces; they are not falsely claimed as fully implemented calculations. Classical Shadbala, Ashtakavarga, full KP sub-lord judgement, all yoga/dosha variants, global historical timezone/location coverage and all 3D animations still require verified deterministic implementations/data before production claims.
