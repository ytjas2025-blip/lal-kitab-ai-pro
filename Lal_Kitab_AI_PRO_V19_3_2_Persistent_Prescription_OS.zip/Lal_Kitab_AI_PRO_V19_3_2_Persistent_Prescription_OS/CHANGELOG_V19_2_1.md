# V19.2.1 Mobile Persistence & Intelligence Fix

- New Kundli generation now auto-saves to server profile storage.
- Device-side birth-data backup added for restore after free-server restart.
- Saved Kundlis screen merges server profiles with device backups.
- Home dashboard now surfaces Predictions, Critical Alerts, and Top Upay immediately.
- Mobile bottom navigation changed to Home / Kundli / Predictions / Remedies / Alerts.
- Opening a saved profile lands on the intelligence dashboard.
- UI branding updated to V19.2.1.
