# CHANGELOG — V7 COMMAND CENTER

## Added
- Completely redesigned Astrologer Command Center dashboard.
- 6 live dashboard KPI cards.
- 16-domain signal heatmap.
- Attention / contradiction center.
- Next-year momentum comparison.
- Scenario Spotlight.
- Scenario & Decision Lab with 9 presets.
- Year-vs-Year Comparator.
- Consultation Brief Generator.
- Prediction Outcome Tracker (Hit / Partial / Miss / Unclear).
- Outcome statistics with conservative minimum-data messaging.
- Follow-up Center with due date, kind, notes and completion status.
- Dashboard CRM counts for tracked outcomes and open follow-ups.
- V7 Command Center / Scenario section in the PDF report.
- New `/api/dashboard/command`, `/api/scenarios/compare`, `/api/years/compare`, `/api/consultation/brief`, `/api/outcomes/*` and `/api/followups/*` APIs.

## Retained
- 2,700 remedy vault records.
- 108 graha × house matrix.
- 16 prediction domains and 11 event themes.
- Smart remedy Top-3 protocol, conflict checks and 43-day tracker.
- Compatibility, family matrix, prediction consensus, rule audit and rectification.
- Local SQLite client CRM, notes, AI Astrologer, Palm AI and PDF export.

## Safety / method changes
- Scenario scores explicitly state they are not recommendations or probabilities.
- Outcome history is labelled retrospective user feedback, not scientific validation.
- Dashboard attention flags expose contradictory evidence rather than resolving it into false certainty.
