from __future__ import annotations

"""V12 Shri Sumitacharya public-source-aware intelligence layer.

This module does not reproduce paid consultations, 108-page reports, copyrighted
article text, proprietary calculations, or full video transcripts. It links
public sources and creates an independent, explainable software synthesis from
calculated chart data. Astrology outputs are guidance/entertainment and are not
professional medical, legal, or financial advice.
"""

from datetime import datetime
from typing import Dict, List, Optional

from prediction_v10 import full_prediction_studio, vimshottari_full
from prediction_pro import forecast_year, event_windows_for_year
from remedies import sumitacharya_source_recommended

BASE = "https://sumitacharya.in"
CHANNEL = "https://www.youtube.com/@Sumitacharyajimaharaj"

SOURCES = [
    {"id":"sumit-home","kind":"official_site","title":"Shri Sumitacharya Ji Maharaj — official website","url":BASE+"/","themes":["108-page kundali","consultation","business + vastu","online pooja"],"note":"Public service overview; used for source discovery only."},
    {"id":"sumit-100-report","kind":"official_article","title":"100+ Page Personalized Kundali Report overview","url":BASE+"/unlock-your-destiny-comprehensive-100-page-personalized-kundali-report-by-shri-sumitacharya-ji-maharaj/","themes":["birth chart","divisional charts","yogas/doshas","5+ year career","business","finance","relationships","remedies"],"note":"V12 builds an independent 108-insight outline rather than copying a paid report."},
    {"id":"sumit-108-product","kind":"official_service","title":"108 Page Janam Kundali service","url":BASE+"/product/janam-kundali-108-pages-shri-sumitacharya/","themes":["detailed report","life areas","remedies"],"note":"Service metadata only; paid report contents are not ingested."},
    {"id":"sumit-marriage","kind":"official_service","title":"Marriage Kundali Milan","url":BASE+"/product/kundali-milan-marriage-sumitacharya-best-astrologer/","themes":["Ashtakoot 36 gunas","Manglik research","planetary influence","compatibility","remedies"],"note":"V12 keeps compatibility as a non-deterministic guidance layer."},
    {"id":"sumit-business","kind":"official_service","title":"Business Astrology + Vastu for offices/shops","url":BASE+"/product/grow-business-with-astrology-strategic-help-for-offices-shops/","themes":["business timing","partner fit","Vastu","branding","agreements","remedies"],"note":"V12 provides a checklist; actual site/floor-plan data is required for Vastu conclusions."},
    {"id":"sumit-services","kind":"official_archive","title":"Astrology Services archive","url":BASE+"/product-category/astrology-services/","themes":["baby birth report","lucky name","consultation","business","marriage","kundali"],"note":"Used to shape workflow modules, not to copy paid service content."},
    {"id":"sumit-form-users","kind":"official_archive","title":"Consultation / Form Users archive","url":BASE+"/product-category/form-users/","themes":["consultation","baby birth report","lucky name","video call","business","marriage problems"],"note":"Public service taxonomy used only to broaden software workflows and question templates."},
    {"id":"sumit-vedic-tag","kind":"official_archive","title":"Vedic Astrology service tag","url":BASE+"/product-tag/vedic-astrology/","themes":["kundali","marriage","business","Trijata research","consultation"],"note":"Public index used for source discovery; no paid content or protected text is ingested."},
    {"id":"sumit-services-page2","kind":"official_archive","title":"Astrology Services archive — page 2","url":BASE+"/product-category/astrology-services/page/2/","themes":["marriage/love consultation","urgent consultation"],"note":"Public service metadata only; not a replacement for a personal consultation."},
    {"id":"sumit-shop","kind":"official_archive","title":"Official shop/service index","url":BASE+"/shop/","themes":["astrology services","grah shanti","traditional products","consultation"],"note":"Used only to identify public categories and safety/attribution boundaries; product claims are not treated as proven outcomes."},
    {"id":"sumit-grah-shanti","kind":"official_service","title":"Grah Dosh Shanti Pooja","url":BASE+"/product/grah-dosh-shanti-puja-shri-sumitacharya-ji-maharaj-hawan/","themes":["chart-first review","graha/dosha identification","muhurta","sankalp","havan"],"note":"V12 does not automate ritual purchases, extreme fasting, fire procedures or health claims."},
    {"id":"sumit-pooja","kind":"official_archive","title":"Pooja / Grah Shanti archive","url":BASE+"/product-category/pooja/","themes":["Brihaspati","Budh","Chandra","Ketu","Mahamrityunjaya","havan"],"note":"Traditional references are labelled as cultural practices, not guaranteed outcomes."},
    {"id":"sumit-shukra","kind":"official_service","title":"Shukra Grah Shanti page","url":BASE+"/product/shukra-grah-shanti-online-pooja-shri-sumitacharya-ji/","themes":["Venus","relationships","comfort","finance themes"],"note":"Claims on the source page are not presented as factual guarantees by V12."},
    {"id":"sumit-trijata","kind":"official_article","title":"Trijata Dosh article","url":BASE+"/trijata-dosh-hawan-nivaran/","themes":["7th house/lord","8th house","Saturn + nodes","lagna lord","karakas","6/8/12"],"note":"V12 exposes only a research flag. It never predicts death, widowhood, disease or lifespan."},
    {"id":"sumit-terms","kind":"official_policy","title":"Terms and Conditions / astrology disclaimer","url":BASE+"/terms-and-conditions/","themes":["entertainment","guidance","informational","not professional advice","IP"],"note":"V12 mirrors this safety boundary and does not copy protected site content."},
    {"id":"sumit-youtube","kind":"official_youtube_channel","title":"Shri Sumitacharya Ji Maharaj — official YouTube channel","url":CHANNEL,"themes":["daily do/don'ts","future prediction","love","money","career","remedies"],"note":"Channel link only; no transcript scraping or bulk reproduction."},
    {"id":"sumit-live-solutions","kind":"official_youtube_video","title":"LIVE Jeevan Ke Samadhan","url":"https://www.youtube.com/watch?v=PiEaqkiOADY","themes":["daily guidance","love","money","career","remedies"],"note":"Public description used for topic mapping; spoken content is not copied."},
    {"id":"sumit-2025","kind":"official_youtube_video","title":"Predictions for 2025","url":"https://www.youtube.com/watch?v=0nzQFw1VQQQ","themes":["predictions","do/don'ts","career","relationship","remedies"],"note":"Public description indexed only; not used as a personal deterministic forecast."},
]

SIGN_LORD = {1:"Mars",2:"Venus",3:"Mercury",4:"Moon",5:"Sun",6:"Mercury",7:"Venus",8:"Mars",9:"Jupiter",10:"Saturn",11:"Saturn",12:"Jupiter"}
NAKSHATRA_SYLLABLES = {
    "Ashwini":["Chu","Che","Cho","La"], "Bharani":["Li","Lu","Le","Lo"], "Krittika":["A","Ee","U","Ae"],
    "Rohini":["O","Va","Vi","Vu"], "Mrigashira":["Ve","Vo","Ka","Ki"], "Ardra":["Ku","Gha","Na","Cha"],
    "Punarvasu":["Ke","Ko","Ha","Hi"], "Pushya":["Hu","He","Ho","Da"], "Ashlesha":["Di","Du","De","Do"],
    "Magha":["Ma","Mi","Mu","Me"], "Purva Phalguni":["Mo","Ta","Ti","Tu"], "Uttara Phalguni":["Te","To","Pa","Pi"],
    "Hasta":["Pu","Sha","Na","Tha"], "Chitra":["Pe","Po","Ra","Ri"], "Swati":["Ru","Re","Ro","Ta"],
    "Vishakha":["Ti","Tu","Te","To"], "Anuradha":["Na","Ni","Nu","Ne"], "Jyeshtha":["No","Ya","Yi","Yu"],
    "Mula":["Ye","Yo","Bha","Bhi"], "Purva Ashadha":["Bhu","Dha","Pha","Dha"], "Uttara Ashadha":["Bhe","Bho","Ja","Ji"],
    "Shravana":["Ju","Je","Jo","Khi"], "Dhanishta":["Ga","Gi","Gu","Ge"], "Shatabhisha":["Go","Sa","Si","Su"],
    "Purva Bhadrapada":["Se","So","Da","Di"], "Uttara Bhadrapada":["Du","Tha","Jha","Na"], "Revati":["De","Do","Cha","Chi"],
}


def source_library() -> Dict:
    return {
        "sources": SOURCES,
        "official_site": BASE,
        "official_channel": CHANNEL,
        "boundary":"Public source links and independently written summaries only. Paid reports, consultations, proprietary algorithms, copyrighted article text and full video transcripts are not copied.",
        "affiliation_note":"This is an independent research/software implementation and is not affiliated with or endorsed by Shri Sumitacharya Ji Maharaj or Sumitacharya Gurukul unless separately licensed.",
        "safety_note":"Astrology is presented as entertainment/guidance. Health, legal, investment and other high-stakes decisions require qualified professionals.",
    }


def _vedic_details(chart: Dict) -> List[Dict]:
    return (chart.get("vedic_aux",{}) or {}).get("planet_details",[]) or []


def _detail_map(chart: Dict) -> Dict[str,Dict]:
    return {x.get("planet"):x for x in _vedic_details(chart)}


def _cyclic_between(x:float, a:float, b:float)->bool:
    """True if x lies on forward zodiac arc a -> b (inclusive)."""
    x%=360; a%=360; b%=360
    span=(b-a)%360; pos=(x-a)%360
    return pos <= span + 1e-9


def dosha_research_scanner(chart: Dict) -> Dict:
    """Conservative Vedic research flags, not deterministic diagnoses."""
    dm=_detail_map(chart)
    placements={p.get('planet'):p for p in chart.get('placements',[]) or []}
    lagna=(chart.get('vedic_aux',{}) or {}).get('lagna',{}) or {}
    lagna_sign=int(lagna.get('sign_no') or 1)
    moon=dm.get('Moon',{})
    mars=dm.get('Mars',{})
    sat=dm.get('Saturn',{})
    rahu=placements.get('Rahu',{})
    ketu=placements.get('Ketu',{})

    flags=[]
    manglik_houses={1,4,7,8,12}
    mars_h=mars.get('house')
    flags.append({
        'key':'manglik','label':'Manglik / Mangal Dosha research','status':'Candidate' if mars_h in manglik_houses else 'Not triggered by this basic house test',
        'score':72 if mars_h in manglik_houses else 22,
        'evidence':[f"Mars in Vedic whole-sign house {mars_h}"],
        'note':'Basic house-screen only; traditions use different exceptions/cancellation rules. Do not use this alone for marriage decisions.',
        'source_url':BASE+'/product/kundali-milan-marriage-sumitacharya-best-astrologer/'
    })

    # Sade Sati: transit Saturn in sign before, same or after natal Moon sign.
    live=(chart.get('live_transit',{}) or {}).get('placements',[]) or []
    tmap={x.get('planet'):x for x in live}
    natal_moon_sign=int(moon.get('sign_no') or 0); trans_sat=int((tmap.get('Saturn') or {}).get('sign_no') or 0)
    ss_signs={((natal_moon_sign-2)%12)+1,natal_moon_sign,(natal_moon_sign%12)+1} if natal_moon_sign else set()
    ss=trans_sat in ss_signs if trans_sat else False
    flags.append({
        'key':'sade_sati','label':'Shani Sade Sati research','status':'Active candidate' if ss else 'Not active by transit-sign screen',
        'score':76 if ss else 18,'evidence':[f"Natal Moon sign #{natal_moon_sign}",f"Transit Saturn sign #{trans_sat}"],
        'note':'Transit-sign screen only; it is not a prediction of harm. Use actual life context and current dasha as separate evidence.',
        'source_url':BASE+'/product/grah-dosh-shanti-puja-shri-sumitacharya-ji-maharaj-hawan/'
    })

    # Kaal Sarpa candidate — all 7 classical planets on one nodal half of zodiac.
    classical=[placements.get(x,{}) for x in ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn']]
    rlon=float(rahu.get('longitude',0)); klon=float(ketu.get('longitude',(rlon+180)%360))
    arc1=all(_cyclic_between(float(p.get('longitude',0)),rlon,klon) for p in classical)
    arc2=all(_cyclic_between(float(p.get('longitude',0)),klon,rlon) for p in classical)
    ks=arc1 or arc2
    flags.append({
        'key':'kaal_sarpa','label':'Kaal Sarpa pattern research','status':'Candidate' if ks else 'Not triggered by nodal-half screen',
        'score':68 if ks else 15,'evidence':[f"All classical planets within one nodal half: {'yes' if ks else 'no'}"],
        'note':'Definitions and exceptions vary substantially. This is a geometry flag, not a guarantee of life events.',
        'source_url':BASE+'/product/grah-dosh-shanti-puja-shri-sumitacharya-ji-maharaj-hawan/'
    })

    # Trijata research — only public article conditions, translated into conservative flags.
    tri=[]
    malefics={'Saturn','Rahu','Ketu','Mars'}
    h7_m=[x for x in malefics if dm.get(x,{}).get('house')==7]
    h8_m=[x for x in malefics if dm.get(x,{}).get('house')==8]
    if h7_m: tri.append('Malefic(s) in Vedic H7: '+', '.join(sorted(h7_m)))
    if h8_m: tri.append('Malefic(s) in Vedic H8: '+', '.join(sorted(h8_m)))
    if sat.get('house') in {7,8} and (dm.get('Rahu',{}).get('house')==sat.get('house') or dm.get('Ketu',{}).get('house')==sat.get('house')):
        tri.append('Saturn + node share H7/H8 candidate')
    lagna_lord=SIGN_LORD.get(lagna_sign)
    ll=dm.get(lagna_lord,{})
    if ll.get('house') in {6,8,12} or 'Debilitated' in (ll.get('flags') or []):
        tri.append(f"Lagna lord {lagna_lord} is weak/dusthana candidate")
    for karaka in ['Venus','Jupiter']:
        kd=dm.get(karaka,{})
        if kd.get('house') in {6,8,12} or 'Debilitated' in (kd.get('flags') or []):
            tri.append(f"{karaka} karaka weak/dusthana candidate")
    tri_score=min(88,18+len(tri)*14)
    flags.append({
        'key':'trijata','label':'Trijata Dosh research flag','status':'Multi-factor review candidate' if len(tri)>=3 else 'Insufficient convergence in this conservative screen',
        'score':tri_score,'evidence':tri or ['No strong convergence in the implemented public-condition screen'],
        'note':'Research flag only. V12 explicitly does NOT infer death, widowhood, disease, fertility, lifespan or unavoidable misfortune from this label.',
        'source_url':BASE+'/trijata-dosh-hawan-nivaran/'
    })

    # No widow/death yoga operationalization by design.
    return {
        'flags':flags,'top_attention':sorted(flags,key=lambda x:x['score'],reverse=True),
        'excluded':['Widow/death/lifespan prediction','medical diagnosis','fertility certainty','guaranteed harm'],
        'method_note':'V12 implements conservative candidate screens from publicly described Vedic themes and keeps source-dependent cancellation rules visible.',
        'safety_note':'Do not make marriage, health, legal or financial decisions solely from a dosha flag.'
    }


def baby_name_lab(chart: Dict) -> Dict:
    p=(chart.get('vedic_aux',{}) or {}).get('panchang',{}) or {}
    n=(p.get('nakshatra') or {})
    name=n.get('name',''); pada=int(n.get('pada') or 1)
    sylls=NAKSHATRA_SYLLABLES.get(name,[])
    primary=sylls[pada-1] if len(sylls)>=pada else ''
    return {
        'nakshatra':name,'pada':pada,'traditional_starting_sound':primary,'all_pada_sounds':sylls,
        'suggestion_examples':[primary+x for x in ['a','an','it','ya','esh','ika']][:6] if primary else [],
        'note':'Traditional Vedic naming aid only. Name choice belongs to the family, culture and language; this is not a proprietary Sumitacharya naming algorithm.',
        'source_url':BASE+'/product-category/astrology-services/'
    }


def business_vastu_checklist(chart: Dict) -> Dict:
    fp=full_prediction_studio(chart,years=5)
    by={x['key']:x for x in fp.get('domains',[])}
    rows=[]
    for key,label in [('business','Business climate'),('money','Cash-flow discipline'),('leadership','Leadership'),('network','Customers/network'),('reputation','Brand/reputation'),('property','Premises/property')]:
        x=by.get(key,{})
        rows.append({'key':key,'label':label,'score':x.get('current_score',50),'band':x.get('band','Mixed'),'practical':x.get('practical','')})
    return {
        'astrology_snapshot':rows,
        'site_data_needed':['entrance direction','owner desk direction','cash/billing area','kitchen/fire zone','toilet/water zones','staircase/lift','shop/office floor plan','business start date / incorporation date'],
        'practical_audit':['verify lease/title/compliance','track cash flow and margin','review partner roles in writing','check customer flow and signage','repair lighting/leaks/clutter','keep fire/electrical safety professional'],
        'status':'Chart-based business workspace ready; full Vastu requires real premises directions/floor plan.',
        'source_url':BASE+'/product/grow-business-with-astrology-strategic-help-for-offices-shops/',
        'safety_note':'No structural, electrical, fire or financial change should be made solely from astrological/Vastu guidance.'
    }


def marriage_single_chart_panel(chart: Dict) -> Dict:
    dm=_detail_map(chart)
    fp=full_prediction_studio(chart,years=5)
    rel=next((x for x in fp.get('domains',[]) if x.get('key')=='relationships'),{})
    fam=next((x for x in fp.get('domains',[]) if x.get('key')=='family'),{})
    return {
        'relationship_score':rel.get('current_score',50),'relationship_band':rel.get('band','Mixed'),
        'family_score':fam.get('current_score',50),'venus':dm.get('Venus',{}),'jupiter':dm.get('Jupiter',{}),
        'navamsha_available':bool((chart.get('vedic_aux',{}) or {}).get('charts',{}).get('navamsha')),
        'next_years':fp.get('next_years',[])[:5],
        'note':'Single-chart relationship lens only. Full marriage matching requires both birth charts; 36-Guna/Ashtakoot and Manglik screens are guidance rather than a pass/fail verdict.',
        'source_url':BASE+'/product/kundali-milan-marriage-sumitacharya-best-astrologer/'
    }


def deep_prediction_studio(chart: Dict, horizon: int=5) -> Dict:
    horizon=max(1,min(int(horizon),10))
    fp=full_prediction_studio(chart,years=horizon)
    dosha=dosha_research_scanner(chart)
    dasha=vimshottari_full(chart)
    year0=datetime.now().year
    years=[]
    for y in range(year0,year0+horizon):
        fy=forecast_year(chart,y); ev=event_windows_for_year(chart,y)
        years.append({'year':y,'top':fy.get('top',[])[:5],'watch':fy.get('watch',[])[:4],'events':ev.get('top_windows',[])[:5],'house_cycle':fy.get('house_cycle')})
    return {
        'foundation':{
            'lagna':(chart.get('vedic_aux',{}) or {}).get('lagna',{}),
            'panchang':(chart.get('vedic_aux',{}) or {}).get('panchang',{}),
            'planet_strengths':[{k:p.get(k) for k in ['planet','house','sign','score','status']} for p in chart.get('placements',[])],
            'raj_yoga_candidates':((chart.get('vedic_aux',{}) or {}).get('raj_yoga_candidates',[]) or [])[:12],
        },
        'active_dasha':dasha.get('active_chain',[]),'domains':fp.get('domains',[]),'strongest':fp.get('strongest',[]),'watch':fp.get('watch',[]),
        'next_12_months':fp.get('next_12_months',[]),'years':years,'dosha_research':dosha,
        'recommended_source_upay':sumitacharya_source_recommended(chart,limit=12),
        'method_note':'V12 independently combines D1/divisional chart context, 4-level Vimshottari, annual/house-cycle/transit evidence and 16-domain scoring. It is inspired only by the public breadth described for Sumitacharya reports, not by a proprietary report algorithm.',
        'certainty_note':'Scores are interpretive emphasis indexes, not event probabilities or guarantees.'
    }


def report_108_outline(chart: Dict) -> Dict:
    """108 original insight slots, not a copied 108-page report."""
    fp=deep_prediction_studio(chart,5)
    sections=[
        ('Birth Foundation',['Lagna','Moon','Sun','Nakshatra','Panchang','Core strengths']),
        ('Planet Passport',['Sun','Moon','Mars','Mercury','Jupiter','Venus']),
        ('Outer/Karmic Planets',['Saturn','Rahu','Ketu','Nodes axis','Retrogrades','Dignity flags']),
        ('Houses 1–6',['H1','H2','H3','H4','H5','H6']),
        ('Houses 7–12',['H7','H8','H9','H10','H11','H12']),
        ('Varga Essentials',['D1','D9','D10','D12','D7 research','D60 research']),
        ('Dasha Timing',['Mahadasha','Antardasha','Pratyantar','Sookshma','Next boundary','Dasha support']),
        ('Career',['Career strength','Role style','Skill focus','Growth window','Caution','Action']),
        ('Business',['Enterprise fit','Partner fit','Launch timing','Cash-flow lens','Brand/network','Action']),
        ('Money',['Income theme','Savings','Expense discipline','Asset/property','Risk boundary','Action']),
        ('Marriage',['Relationship pattern','Venus','Jupiter','D9','Timing lens','Action']),
        ('Family & Children',['Family','Caregiving','Children theme','D12/D7 research','Caution','Action']),
        ('Property & Travel',['Property','Vehicle','Home','Foreign','Travel','Action']),
        ('Learning & Reputation',['Education','Creativity','Leadership','Network','Reputation','Action']),
        ('Dosha Research',['Manglik','Sade Sati','Kaal Sarpa','Trijata research','Cancellation review','Safety']),
        ('Lal Kitab',['Fixed-house Teva','Pakka Ghar','Soya/Jagta','Rin','Masnui','36-year cycle']),
        ('Remedies',['Top remedy 1','Top remedy 2','Top remedy 3','Source upay','Conflict check','43-day review']),
        ('5-Year Roadmap',['Year 1','Year 2','Year 3','Year 4','Year 5','Review checklist']),
    ]
    slots=[]; n=1
    for sec,items in sections:
        for item in items:
            slots.append({'no':n,'section':sec,'insight':item}); n+=1
    assert len(slots)==108
    return {
        'title':'108-Insight Deep Kundali Builder','total_insights':108,'sections':[{'title':s,'items':i} for s,i in sections],
        'slots':slots,'prediction_snapshot':{'strongest':fp.get('strongest',[])[:5],'watch':fp.get('watch',[])[:5]},
        'note':'108 original software insight slots — not a reproduction of Shri Sumitacharya Ji’s paid 108-page report.',
        'source_url':BASE+'/product/janam-kundali-108-pages-shri-sumitacharya/'
    }


def sumitacharya_dashboard(chart: Dict, horizon: int=5) -> Dict:
    return {
        'source_library':source_library(),
        'deep_predictions':deep_prediction_studio(chart,horizon),
        'dosha_research':dosha_research_scanner(chart),
        'baby_name':baby_name_lab(chart),
        'business_vastu':business_vastu_checklist(chart),
        'marriage_panel':marriage_single_chart_panel(chart),
        'report_108':report_108_outline(chart),
        'source_remedies':sumitacharya_source_recommended(chart,limit=24),
        'features':['100+/108-report-inspired depth without cloning','5-year deep prediction studio','Dosha Research Lab','Baby Name Lab','Business + Vastu checklist','Marriage single-chart panel','600 source-aware remedy records','official source library'],
        'boundary':'Independent software synthesis. Not an official Sumitacharya product and not a substitute for qualified professional advice.'
    }
