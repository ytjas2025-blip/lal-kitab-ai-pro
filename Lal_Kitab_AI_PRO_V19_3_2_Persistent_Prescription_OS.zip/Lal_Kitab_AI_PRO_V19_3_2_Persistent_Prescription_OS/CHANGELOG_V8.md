# CHANGELOG — AI OS v8.1

## Interface
- Rebuilt the front end into a mobile-first black/gold kundli workstation.
- Added slide-out navigation inspired by high-density astrology apps.
- Added quick top tabs for main charts and AI.
- Added North-Indian kundli renderer with degree / retrograde / Vargottama markers.
- Added a sacred Lal Kitab chart view using the supplied visual direction.

## New chart / Vedic auxiliary layers
- Lagna / D1.
- Navamsha / D9.
- Moon chart.
- Bhav Chalit auxiliary.
- Dasamsa / D10.
- Dwadasamsa / D12.
- Panchang.
- Vimshottari Dasha reference.
- Live transit snapshot.
- Bhav Madhya.
- Strength Lab.
- Karakamsha and Swamsa research views.
- KP cusp workspace.
- Avakhada summary.

## v8.1 additions
- Shodashavarga Matrix with explicit source-pack gating for unimplemented Vargas.
- Raj Yoga Candidate Lab with conservative, explainable candidate flags.
- Ghatak & Favourable workspace with source-profile gating.
- Stronger method labels separating Lal Kitab and Vedic systems.

## AI OS
- 8 AI modes: Explain, Second Opinion, Skeptic, Consultation, Remedy Review, Timeline, Report, Evidence.
- Optional cloud AI with built-in offline fallback.
- Saved AI history for CRM clients.
- Optional palm-image interpretation with strict cultural/entertainment framing.

## Existing PRO intelligence retained
- 2,700 remedy records.
- 16 prediction domains.
- 11 event-theme windows.
- Command Center.
- Scenario Lab.
- Compatibility / Family Matrix.
- Birth-time rectification.
- Prediction consensus and rule audit.
- 43-day remedy tracker.
- Outcome tracker and follow-ups.

## Safety / integrity
- No fabricated full Ashtakavarga totals.
- No fabricated unverified Shodashavarga charts.
- No deterministic event probabilities.
- No hazardous / exploitative remedy guidance.
- Medical, legal and financial decisions remain outside astrology guidance.
