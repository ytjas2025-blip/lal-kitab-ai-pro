from __future__ import annotations

"""V19.3.1 — Source-grounded adaptive Upay prescription intelligence.

Design goals:
- never equate a modern service substitute with an early Lal Kitab source rule;
- allow "no remedy needed";
- avoid blind stacking of remedies;
- prefer safe, low-cost, feasible actions;
- expose source tier, rationale and conflicts;
- provide practical alternatives when a ritual/action is impossible.

This is an interpretive/research layer, not a claim of scientifically proven causation.
"""

from typing import Dict, List, Any, Optional

PLANETS = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu"]

SOURCE_TIERS = {
    "A": "Early Lal Kitab source (1941/1952 family) — use only when rule is explicitly mapped/verified",
    "B": "Structured Lal Kitab commentary / supporting edition",
    "C": "Traditional secondary commentary",
    "D": "Modern public compilation",
    "E": "Modern seva / behavioural / safety substitute",
}

SOURCE_REGISTRY = [
    {"id":"lk1941","title":"Lal Kitab (Teesra Hissa) 1941","tier":"A","status":"verified_in_build","url":"https://dn760007.eu.archive.org/0/items/LalKitab1941/LK-1941.pdf","use":"Primary early-source principles and future house/condition remedy mapping."},
    {"id":"lk1952","title":"Lal Kitab 1952 Hindi volumes","tier":"A","status":"source_received_needs_volume_dedupe","url":"","use":"Primary early-source cross-check after exact volume/page identity verification."},
    {"id":"arun_sanhita","title":"Arun Sanhita — Lal Kitab","tier":"B","status":"supporting_source_received","url":"https://www.sanskrit.nic.in/books_archive/006_Arun_Sanhita_Lal_Kitab_Hare_Krishna_Trashta.pdf","use":"Structured supporting/cross-check source; not promoted above early editions."},
    {"id":"girdhari","title":"Asli Prachin Lal Kitab — Girdhari Lal Sharma","tier":"C","status":"secondary_reference","url":"https://archive.org/details/AsliPrachinLalKitabGirdhariLalSharma","use":"Traditional secondary commentary; verify exact rule/page before recommendation."},
    {"id":"bm_gosvami","title":"Jyotish Lal Kitab — B.M. Gosvami","tier":"C","status":"secondary_reference_needs_page_mapping","url":"https://dn760100.eu.archive.org/0/items/jyotishlalkitabb.m.gosvami/Jyotish_Lal%20Kitab_B.M.%20Gosvami.pdf","use":"Secondary structured reference after title/page/rule verification."},
    {"id":"emalwa51","title":"51 Lal Kitab Ram-Baan Upay — modern compilation","tier":"D","status":"idea_pool_safety_filtered","url":"https://emalwa.com/religion/%e0%a4%b2%e0%a4%be%e0%a4%b2-%e0%a4%95%e0%a4%bf%e0%a4%a4%e0%a4%be%e0%a4%ac-%e0%a4%95%e0%a5%87-%e0%a4%af%e0%a5%87-51-%e0%a4%b0%e0%a4%be%e0%a4%ae%e0%a4%ac%e0%a4%be%e0%a4%a3-%e0%a4%89%e0%a4%aa%e0%a4%be/","use":"Modern idea pool only; unsafe/outdated claims blocked or substituted."},
]

# Core principle encoded from the 1941 Hindi-transliteration introduction: do not blindly
# prescribe remedies for every planet; a benefic planet's positive expression can be disturbed.
SOURCE_PRINCIPLES = [
    {
        "id": "lk1941-no-blind-stacking",
        "tier": "A",
        "source": "Lal Kitab (Teesra Hissa), 1941 — Hindi transliteration",
        "principle": "Do not apply remedies to every planet blindly; assess whether a remedy is actually needed and whether it could disturb a benefic/working planet.",
        "software_rule": "Remedy Conflict Guard 2.0 + No-Remedy result",
    },
    {
        "id": "lk1941-conduct",
        "tier": "A",
        "source": "Lal Kitab (Teesra Hissa), 1941 — introductory framing",
        "principle": "Character/conduct is treated as meaningful, so behaviour correction is a first-class remedy category rather than only material ritual.",
        "software_rule": "Karma/Behaviour Correction appears alongside traditional actions",
    },
]


def _r(id:str, title:str, action:str, planets:List[str], concerns:List[str], *,
       category:str="modern_seva", tier:str="E", cost:str="₹0–₹200",
       time:str="5–20 min", frequency:str="One-time / weekly", needs:Optional[List[str]]=None,
       avoid:Optional[List[str]]=None, source:str="Modern safe substitute",
       source_note:str="Not claimed as a verbatim original Lal Kitab remedy.",
       safety:str="Low-risk when done respectfully and lawfully.", dignity:bool=True) -> Dict[str,Any]:
    return {
        "id":id,"title":title,"action":action,"planets":planets,"concerns":concerns,
        "category":category,"source_tier":tier,"cost":cost,"time":time,"frequency":frequency,
        "needs":needs or [],"avoid_if":avoid or [],"source":source,"source_note":source_note,
        "safety":safety,"dignity_first":dignity,
    }


MODERN_UPAY_BANK: List[Dict[str,Any]] = [
    _r("labour_tea","Labour Tea Seva","1–5 labourers/workers ko chai + simple snack respectfully offer karein; photo/post ki zaroorat nahi.",["Saturn"],["career","business","delay","money"],cost="₹50–₹300",frequency="Saturday/weekly"),
    _r("labour_breakfast","Worker Breakfast","Construction/manual workers ke liye breakfast sponsor karein; site permission aur food hygiene ka dhyan rakhein.",["Saturn","Mars"],["career","business","delay"],cost="₹100+",frequency="Weekly"),
    _r("worker_water","Worker Water Support","Garmi mein workers/security/delivery staff ko sealed drinking water ya safe hydration support dein.",["Saturn","Mars"],["career","business","health-support"],cost="₹20+",frequency="As needed"),
    _r("worker_safety","Worker Safety Kit","Genuine need ho to gloves/raincoat/safety shoes jaise work essentials sponsor karein; employer safety obligations ka substitute nahi.",["Saturn","Mars"],["business","career","delay"],cost="₹200+",frequency="One-time"),
    _r("clear_worker_dues","Clear Worker Dues","Worker/helper/vendor ka legitimate pending payment ya agreed overtime clear karein.",["Saturn","Mercury"],["money","business","career","debt"],cost="Existing obligation",frequency="Immediate",source="Modern karma-correction substitute"),
    _r("domestic_staff_fairness","Domestic Staff Fairness","Domestic worker/helper ko timely salary, respectful treatment aur clear work expectations dein.",["Saturn","Venus"],["home","relationship","money"],cost="₹0 beyond dues",frequency="Ongoing"),
    _r("sanitation_tea","Sanitation Worker Tea/Meal","Safai/sanitation worker ko chai, meal, ration ya respectful tip dein; alcohol gift recommend nahi kiya jata.",["Rahu","Saturn"],["obstacles","career","money"],cost="₹30+",frequency="Saturday/weekly"),
    _r("sanitation_raincoat","Sanitation Worker Essentials","Raincoat, gloves, socks ya hygiene kit need-based tareeke se dein.",["Rahu","Saturn"],["obstacles","career"],cost="₹100+",frequency="Seasonal"),
    _r("sanitation_child_school","Sanitation Family Education Support","Safai worker ke bachche ke liye notebook/stationery ya verified education support dein.",["Rahu","Mercury","Jupiter"],["education","career","obstacles"],cost="₹100+",frequency="Monthly/one-time"),
    _r("blind_meal","Visually Impaired Meal Seva","Blind school/verified disability organization mein meal sponsorship ya food support karein.",["Saturn","Sun"],["obstacles","career","spiritual"],cost="₹100+",frequency="Monthly"),
    _r("braille_supplies","Accessible Learning Support","Braille stationery, accessible books ya assistive-learning material verified organization ke through sponsor karein.",["Mercury","Jupiter","Saturn"],["education","career"],cost="₹200+",frequency="One-time/monthly"),
    _r("disability_transport","Accessibility Transport Help","Disabled/elderly person ke verified transport/accessibility expense mein practical help karein; dignity aur consent first.",["Saturn","Moon"],["obstacles","travel","health-support"],cost="Variable",frequency="As needed"),
    _r("old_age_meal","Old-Age Home Meal","Verified old-age home/community senior program mein meal/fruits/ration support karein.",["Saturn","Sun","Jupiter"],["family","career","spiritual"],cost="₹100+",frequency="Weekly/monthly"),
    _r("elder_errand","Elder Practical Help","Elder ko grocery, digital form, bill ya transport mein help karein—sirf consent ke saath.",["Saturn","Sun","Moon"],["family","home","obstacles"],cost="₹0+",frequency="Weekly"),
    _r("leprosy_ration","Leprosy Rehabilitation Ration","Verified leprosy rehabilitation centre/NGO ko ration, hygiene essentials ya meal support karein; residents ko stigma-free dignity ke saath treat karein.",["Saturn","Rahu"],["obstacles","spiritual","career"],cost="₹100+",frequency="Monthly"),
    _r("leprosy_blanket","Rehabilitation Centre Blanket","Seasonal need ho to verified rehabilitation centre mein clean blanket/clothes donate karein.",["Saturn","Rahu"],["obstacles","spiritual"],cost="₹200+",frequency="Seasonal"),
    _r("homeless_meal","Homeless Shelter Meal","Verified shelter/community kitchen ke through cooked meal sponsor karein.",["Saturn","Moon","Jupiter"],["money","spiritual","obstacles"],cost="₹100+",frequency="Weekly/monthly"),
    _r("hospital_attendant_meal","Hospital Attendant Meal","Hospital ke bahar patient attendants/families ke liye verified meal-service organization ko support karein.",["Moon","Saturn","Jupiter"],["health-support","family","spiritual"],cost="₹100+",frequency="As affordable",safety="Support only; never replace medical treatment or advice."),
    _r("community_kitchen","Community Kitchen Seva","Langar/community kitchen/food bank mein food, time ya ingredients contribute karein.",["Moon","Jupiter","Saturn"],["money","family","spiritual"],cost="₹0+",frequency="Weekly/monthly"),
    _r("ration_kit","Need-Based Ration Kit","Verified needy family ko atta/dal/rice/oil ki practical ration kit dein.",["Moon","Jupiter","Saturn"],["money","family","debt"],cost="₹300+",frequency="Monthly"),
    _r("student_books","Student Books & Stationery","Needy student ko books, notebooks, pens ya exam stationery support karein.",["Mercury","Jupiter"],["education","career"],cost="₹100+",frequency="Wednesday/Thursday optional"),
    _r("student_exam_fee","Exam Fee Support","Verified student ki exam/application fee ka affordable hissa sponsor karein.",["Mercury","Jupiter"],["education","career","money"],cost="Variable",frequency="One-time"),
    _r("skill_training","Skill Training Support","Unemployed person ke verified skill course/interview travel expense mein help karein.",["Mercury","Jupiter","Saturn"],["career","money"],cost="Variable",frequency="One-time"),
    _r("girls_education","Girls' Education Support","Verified education program ko books/fees/learning material support dein.",["Jupiter","Venus","Mercury"],["education","career","relationship"],cost="₹100+",frequency="Monthly"),
    _r("women_hygiene","Women Welfare Hygiene Support","Verified women-care organization ko hygiene essentials donate karein.",["Venus","Moon"],["relationship","family","spiritual"],cost="₹100+",frequency="Friday/monthly"),
    _r("relationship_respect","Relationship Respect Action","Manipulation/secret pressure ki jagah clear, respectful aur consent-based conversation choose karein.",["Venus","Mercury"],["relationship","family"],cost="₹0",frequency="As needed",source="Modern behaviour correction"),
    _r("mentor_thanks","Mentor/Teacher Gratitude","Teacher/mentor available ho to genuine thanks/help karein; unsafe/estranged relation ho to forced contact nahi.",["Jupiter","Sun"],["education","career","spiritual"],cost="₹0+",frequency="Thursday/Sunday optional"),
    _r("father_substitute","Father-Unavailable Safe Substitute","Father deceased/absent/estranged/unsafe ho to forced contact na karein; elder/teacher/mentor/service/discipline action choose karein.",["Sun"],["family","career","self"],cost="₹0",frequency="Weekly",source="Modern symbolic substitute",source_note="Not presented as an exact classical substitution rule."),
    _r("mother_substitute","Mother/Caregiver-Unavailable Substitute","Mother/caregiver unavailable ya unsafe ho to forced contact na karein; elder-woman/caregiver support, home-care ya calm routine choose karein.",["Moon"],["family","home","mind"],cost="₹0",frequency="Weekly",source="Modern symbolic substitute",source_note="Not presented as an exact classical substitution rule."),
    _r("vendor_payment","Vendor Payment Discipline","Genuine vendor/supplier dues ko agreed timeline par clear karein; disputed invoice ho to written reconciliation karein.",["Saturn","Mercury"],["business","money","debt"],cost="Existing obligation",frequency="Immediate"),
    _r("document_check","Document Double-Check","Payment, agreement, name, date, tax, bank details aur commitments ko send/sign se pehle double-check karein.",["Mercury","Rahu"],["business","money","legal","fraud"],cost="₹0",frequency="Every important transaction"),
    _r("digital_security","Digital Fraud Hygiene","Unknown links/offers/payment requests ko independently verify karein; passwords/2FA/privacy update karein.",["Rahu","Mercury"],["fraud","money","business"],cost="₹0",frequency="Ongoing"),
    _r("anonymous_help","Anonymous Seva","Ek useful seva bina social-media credit/post ke karein.",["Ketu","Rahu","Saturn"],["spiritual","obstacles"],cost="₹0+",frequency="Weekly"),
    _r("declutter","10-Minute Declutter","Broken/unused items, pending digital clutter ya abandoned task ka 10-minute cleanup karein; usable items responsibly donate/recycle karein.",["Ketu","Rahu","Saturn"],["obstacles","home","mind"],cost="₹0",frequency="Daily 10 min"),
    _r("animal_shelter","Animal Shelter Support","Unsafe stray feeding ke bajay reputable animal shelter ko food, medicine fund ya cleaning seva support karein.",["Ketu","Saturn"],["spiritual","obstacles"],cost="₹0+",frequency="Weekly/monthly",safety="Do not feed animals unsafe foods or create road/public-health hazards."),
    _r("dog_welfare","Dog Welfare Alternative","Dog-feeding possible/safe na ho to shelter food bag, adoption centre cleaning ya vetted rescue support karein.",["Ketu"],["obstacles","spiritual"],cost="₹0+",frequency="Weekly"),
    _r("bird_water","Bird Water Bowl","Garmi mein safe elevated location par clean water bowl rakhein aur daily clean karein.",["Moon","Ketu"],["mind","spiritual"],cost="₹0–₹100",frequency="Seasonal/daily"),
    _r("tree_care","Tree/Plant Care","Naya tree lagana hi zaroori nahi—existing plant/tree ko lawful, sustainable care dein.",["Mars","Mercury","Jupiter"],["home","career","spiritual"],cost="₹0+",frequency="Weekly"),
    _r("public_water","Public Water Support","Verified place par drinking-water cooler/refill support karein; hygiene and permissions follow karein.",["Moon","Saturn"],["spiritual","health-support"],cost="Variable",frequency="Seasonal"),
    _r("food_waste","Food Waste Discipline","Edible surplus ko safe food-bank channel dein; spoiled food donate na karein.",["Moon","Saturn","Jupiter"],["money","home","spiritual"],cost="₹0",frequency="Ongoing"),
    _r("anger_delay","10-Minute Anger Delay","Gusse mein message/call/decision se pehle minimum 10-minute pause rule use karein.",["Mars","Mercury"],["relationship","business","legal"],cost="₹0",frequency="As needed"),
    _r("exercise","Controlled Physical Energy","Health ke hisaab se safe walking/exercise ya constructive physical work karein; medical restrictions follow karein.",["Mars"],["mind","career","self"],cost="₹0",frequency="Daily",safety="Follow clinician advice if you have health limitations."),
    _r("truthful_speech","Truthful Speech Day","Gossip, half-information, false promises aur unnecessarily harsh speech consciously avoid karein.",["Mercury","Sun"],["relationship","business","career"],cost="₹0",frequency="Wednesday/weekly"),
    _r("learning_15","15-Minute Learning","Roz 15 minute useful skill/study aur ek practical application karein.",["Mercury","Jupiter"],["education","career","business"],cost="₹0",frequency="Daily"),
    _r("ethical_commitment","One Ethical Commitment","Shortcut ke bajay ek important ethical/professional commitment poora karein.",["Jupiter","Sun","Saturn"],["career","business","legal"],cost="₹0",frequency="Daily/weekly"),
    _r("luxury_review","Luxury Spending Review","Subscriptions, impulse luxury spending aur unused possessions review karein.",["Venus","Rahu"],["money","relationship"],cost="₹0",frequency="Friday/monthly"),
    _r("pending_repair","Pending Repair","Ek neglected repair/maintenance task safe way se close karein.",["Saturn","Mars"],["home","property","vehicle","delay"],cost="Variable",frequency="Saturday/weekly"),
    _r("debt_calendar","Debt Calendar","Debt/EMI/payment commitments ka written calendar bana kar due dates automate karein.",["Saturn","Mercury"],["debt","money","business"],cost="₹0",frequency="Monthly"),
    _r("gambling_restraint","Gambling/Impulse Restraint","Gambling, speculative impulse ya intoxicant-linked risky decisions avoid karein; addiction concern ho to professional support lein.",["Saturn","Rahu"],["money","fraud","mind"],cost="₹0",frequency="Ongoing",safety="If substance/gambling use is problematic, seek qualified support."),
    _r("morning_discipline","Morning Discipline Substitute","Sunrise ritual possible na ho to fixed wake-up, hydration, sunlight exposure when safe, and first responsibility complete karein.",["Sun"],["career","self","mind"],cost="₹0",frequency="Daily",source="Modern behavioural substitute"),
    _r("calm_corner","Calm Home Corner","Home mein ek clean, uncluttered calm corner rakhein; 5 minutes quiet sitting/journaling karein.",["Moon","Ketu"],["mind","home","relationship"],cost="₹0",frequency="Daily"),
    _r("sleep_rhythm","Sleep Rhythm","Consistent sleep/wake routine build karein; sleep problem persistent ho to medical guidance lein.",["Moon","Saturn"],["mind","health-support"],cost="₹0",frequency="Daily",safety="Supportive routine only; not treatment."),
    _r("legal_aid_donation","Legal-Aid Support","Court/legal stress ho to verified legal-aid organization ko optional support dein—apne case ke liye qualified legal advice alag se lein.",["Saturn","Jupiter"],["legal","obstacles"],cost="₹0+",frequency="Optional",safety="Never replace legal counsel with astrology/remedies."),
    _r("hospital_support","Health-Support Reality First","Health issue mein diagnosis/treatment clinician se; spiritual/seva action sirf supportive layer rahe.",["Moon","Jupiter","Saturn"],["health-support"],cost="₹0",frequency="Always",category="safety",source="Safety rule",source_note="Mandatory reality-first guard."),
    _r("no_remedy","No Remedy / Observe","Agar chart/source/conflict guard clear priority na dikhaye, koi graha-specific upay force na karein. Normal practical routine continue karein.",PLANETS,["general","self"],cost="₹0",frequency="Review later",category="safety",source="Remedy Conflict Guard 2.0"),
]

# Add systematic variants without pretending each is a classical rule.
SERVICE_GROUPS = [
    ("security_guard","Security Guard Support",["Saturn","Mars"],"security guard ko water/tea/seasonal essentials"),
    ("delivery_worker","Delivery Worker Support",["Saturn","Mercury"],"delivery worker ko water/snack ya respectful tip"),
    ("rickshaw_driver","Driver/Rickshaw Support",["Saturn","Mercury"],"driver/rickshaw worker ko meal/water ya fair fare"),
    ("artisan","Artisan Fair-Payment",["Saturn","Mercury"],"cobbler/tailor/carpenter/artisan se excessive bargaining na karke fair payment"),
    ("orphan_support","Child-Care Organization Support",["Jupiter","Moon"],"verified child-care/education organization ko food/stationery support"),
    ("shelter_hygiene","Shelter Hygiene Kit",["Saturn","Venus"],"verified shelter ko soap/toothpaste/towel/hygiene kit"),
    ("winter_blanket","Winter Blanket Seva",["Saturn"],"need-based clean blanket distribution through verified channel"),
    ("rain_umbrella","Rain Protection Seva",["Saturn","Moon"],"umbrella/raincoat need-based distribution"),
    ("job_cv_help","Job-Seeker Practical Help",["Mercury","Saturn"],"job seeker ka CV, application ya interview-prep free help"),
    ("community_cleanup","Community Cleanup",["Saturn","Ketu"],"public-space litter cleanup with safety gear and local rules"),
]
for key,title,planets,desc in SERVICE_GROUPS:
    MODERN_UPAY_BANK.append(_r(key,title,desc+" karein.",planets,["career","money","obstacles","spiritual"],cost="₹0+",frequency="As practical"))


# Expanded modern-service families. These are deliberately tagged Tier E: practical,
# safe substitutes rather than claims of verbatim early Lal Kitab text.
EXPANDED_SEVA_GROUPS = [
    ("tea_vendor","Tea Vendor Fairness",["Saturn","Mercury"],"small tea/snack vendor se fair payment karein aur unnecessary bargaining avoid karein",["money","business","career"]),
    ("street_vendor","Street Vendor Support",["Saturn","Mercury"],"street vendor se useful item kharid kar fair payment karein",["money","business","career"]),
    ("porter_support","Porter/Loader Support",["Saturn","Mars"],"porter/loader ko water, meal ya fair tip dein",["travel","career","business"]),
    ("mechanic_support","Mechanic Fair-Payment",["Saturn","Mars","Mercury"],"mechanic/repair worker ko agreed fair payment aur respectful treatment dein",["vehicle","business","money"]),
    ("farm_worker","Farm Worker Support",["Saturn","Mars","Moon"],"farm/agri worker ko seasonal water, meal ya essentials support karein",["career","money","property"]),
    ("cleaner_support","Cleaner Support",["Saturn","Rahu"],"cleaner/housekeeping staff ko tea, meal, hygiene essentials ya fair tip dein",["home","career","obstacles"]),
    ("sewer_worker_ppe","Sewer/Sanitation PPE Support",["Saturn","Rahu","Mars"],"verified sanitation worker welfare channel ke through gloves, boots, mask ya safety essentials support karein",["career","obstacles","health-support"]),
    ("hearing_impaired_support","Hearing-Impaired Accessibility Support",["Mercury","Saturn"],"verified deaf/hard-of-hearing organization ko accessible learning/communication support dein",["education","career","obstacles"]),
    ("mobility_aid_support","Mobility-Aid Support",["Saturn","Mars"],"verified disability organization ke through wheelchair/walker repair ya mobility aid sponsorship karein",["travel","health-support","obstacles"]),
    ("special_education","Special Education Support",["Mercury","Jupiter","Saturn"],"verified special-education program ko learning material ya fee support dein",["education","career","family"]),
    ("rehab_skill_support","Rehabilitation Skill Support",["Saturn","Mercury","Jupiter"],"rehabilitation centre ke skill-training ya livelihood program ko support karein",["career","money","obstacles"]),
    ("caregiver_meal","Caregiver Meal Support",["Moon","Saturn"],"long-term patient caregivers ke liye verified meal/support service ko contribute karein",["health-support","family","mind"]),
    ("blood_bank_support","Blood Bank Logistics Support",["Mars","Moon"],"eligible hon to blood donation karein ya blood-bank logistics/awareness ko support karein; medical eligibility mandatory hai",["health-support","spiritual" ]),
    ("organ_donation_awareness","Organ Donation Awareness",["Sun","Jupiter","Mars"],"reputable public-health channel se organ-donation awareness/share karein; consent aur law follow karein",["health-support","spiritual"]),
    ("public_library","Public Library Support",["Mercury","Jupiter"],"public/community library ko useful books ya study material donate karein",["education","career"]),
    ("digital_literacy","Digital Literacy Seva",["Mercury","Jupiter","Rahu"],"elderly/needy person ko safe digital payment, form ya scam-awareness sikhane mein help karein",["fraud","education","career"]),
    ("cyber_safety_help","Cyber Safety Help",["Mercury","Rahu","Saturn"],"family/elder ko phishing, OTP, fake-link aur password-safety samjha dein",["fraud","money","family"]),
    ("document_help","Document/Form Help",["Mercury","Saturn"],"needy/elder person ko legitimate form, appointment ya document process samajhne mein free help karein",["legal","career","obstacles"]),
    ("resume_review","Resume Review Seva",["Mercury","Saturn","Jupiter"],"job seeker ka CV/resume free review karein ya interview prep help dein",["career","money"]),
    ("skill_course_support","Skill Course Support",["Mercury","Jupiter","Saturn"],"verified needy learner ke skill-course fee ya learning resources ka affordable support karein",["career","education","money"]),
    ("school_meal","School Meal Support",["Moon","Jupiter"],"verified school/community program mein nutritious meal support karein",["education","family","spiritual"]),
    ("school_uniform","School Uniform Support",["Venus","Mercury","Jupiter"],"verified needy student ko uniform/shoes/bag support dein",["education","career","family"]),
    ("girl_education","Girls Education Support",["Venus","Jupiter","Mercury"],"verified girls-education program ko fee, books ya digital learning support dein",["education","career","family"]),
    ("widow_support","Widow Livelihood Support",["Saturn","Moon","Venus"],"verified widow livelihood/self-help program ko practical support dein",["money","family","career"]),
    ("single_parent_support","Single-Parent Family Support",["Moon","Saturn","Venus"],"verified single-parent family ko ration, school supplies ya job-support dein",["family","money","career"]),
    ("orphan_education","Child Education Support",["Moon","Jupiter","Mercury"],"verified child-care organization ke through education support dein",["education","family","spiritual"]),
    ("shelter_bedding","Shelter Bedding Support",["Saturn","Moon"],"verified shelter ko clean bedsheet, blanket ya towel need-based tareeke se donate karein",["home","obstacles","spiritual"]),
    ("community_fridge","Community Fridge Support",["Moon","Jupiter"],"safe, fresh, labelled food verified community fridge/food-sharing point par contribute karein",["money","family","spiritual"]),
    ("food_waste_rescue","Food Waste Rescue",["Moon","Jupiter","Saturn"],"edible surplus ko verified food-rescue channel tak safely pahunchayein",["money","spiritual","business"]),
    ("water_cooler","Public Water Cooler Support",["Moon","Saturn"],"verified public/community place par drinking-water cooler/maintenance support karein",["health-support","spiritual","career"]),
    ("bird_water","Bird Water Bowl",["Moon","Ketu"],"safe shaded jagah par clean bird-water bowl rakhein aur daily clean/refill karein",["home","spiritual","mind"]),
    ("dog_shelter","Dog Shelter Support",["Ketu","Saturn"],"verified dog shelter ko food, medicine-fund ya cleaning seva support karein",["spiritual","obstacles","mind"]),
    ("animal_rescue","Animal Rescue Support",["Ketu","Moon","Saturn"],"injured stray ke liye verified rescue NGO ko call/support karein; khud unsafe handling na karein",["spiritual","obstacles","health-support"]),
    ("cow_shelter","Cattle Shelter Fodder Support",["Jupiter","Moon"],"verified animal-welfare shelter ko fodder/clean water support dein; local welfare standards check karein",["spiritual","family","money"]),
    ("tree_care","Tree Care",["Jupiter","Ketu","Moon"],"existing tree/plant ki long-term watering, guard ya maintenance responsibility lein",["property","spiritual","mind"]),
    ("plantation_aftercare","Plantation Aftercare",["Jupiter","Saturn"],"sirf tree-planting photo nahi; planted tree ki months tak aftercare ensure karein",["property","spiritual","career"]),
    ("plastic_cleanup","Plastic Cleanup",["Saturn","Ketu","Rahu"],"gloves ke saath local rules follow karte hue public-space plastic/litter cleanup karein",["obstacles","spiritual","home"]),
    ("recycling_discipline","Recycling Discipline",["Saturn","Ketu"],"ghar/office waste segregation aur responsible recycling routine start karein",["home","business","spiritual"]),
    ("vendor_dues","Clear Vendor Dues",["Saturn","Mercury"],"legitimate vendor/supplier outstanding ko agreed terms ke mutabik clear karein",["business","money","debt"]),
    ("salary_on_time","Salary On Time",["Saturn","Sun"],"staff salary agreed date par release karein aur avoidable delay na karein",["business","career","money"]),
    ("overtime_dues","Clear Overtime Dues",["Saturn","Mars"],"legitimate overtime/extra-work dues accurately settle karein",["business","career","money"]),
    ("refund_due","Return Legitimate Refund",["Mercury","Saturn"],"jahan aap par genuine refund/repayment due ho use delay na karein",["money","debt","business"]),
    ("borrowed_item_return","Return Borrowed Item",["Saturn","Mercury"],"borrowed item/document ko time par aur proper condition mein return karein",["debt","relationship","home"]),
    ("promise_audit","Promise Audit",["Saturn","Sun","Mercury"],"3 pending commitments likh kar jo genuinely due hain unhe complete/renegotiate karein",["career","relationship","business"]),
    ("truthful_sales","Truthful Sales Practice",["Mercury","Jupiter"],"sales/marketing mein false promise, hidden charge ya misleading claim avoid karein",["business","career","money"]),
    ("contract_doublecheck","Contract Double-Check",["Mercury","Saturn","Rahu"],"important contract/payment instruction ko sign/send se pehle independently verify karein",["business","legal","fraud"]),
    ("otp_safety","OTP/Link Safety",["Mercury","Rahu"],"OTP, UPI PIN, unknown link aur remote-access request kabhi share/accept na karein",["fraud","money"]),
    ("backup_documents","Document Backup",["Mercury","Saturn"],"important IDs/contracts/bills ki encrypted/cloud + offline backup copy maintain karein",["legal","business","money"]),
    ("budget_review","Weekly Budget Review",["Mercury","Saturn","Jupiter"],"weekly 10-minute income/expense/debt review karein aur avoidable leak identify karein",["money","debt","business"]),
    ("impulse_wait","24-Hour Impulse Rule",["Rahu","Mars","Mercury"],"large non-essential purchase/speculative decision par 24-hour wait rule rakhein",["money","fraud","mind"]),
    ("anger_delay","Anger Delay Rule",["Mars","Moon","Mercury"],"heated message/call par 20-minute pause aur factual reply rule use karein",["relationship","career","mind"]),
    ("apology_repair","Repair Through Apology",["Moon","Venus","Mercury"],"jahan aapki clear galti ho aur contact safe ho, specific apology + corrective action karein",["relationship","family","career"]),
    ("gratitude_message","Gratitude Message",["Sun","Jupiter","Venus"],"safe mentor/teacher/elder ko sincere thanks message bhejein; forced family contact nahi",["family","career","spiritual"]),
    ("mentor_service","Mentor/Teacher Service",["Sun","Jupiter"],"father unavailable/unsafe ho to safe mentor/teacher/elder ke prati respect ya seva ko modern symbolic alternative ke roop mein use karein",["family","career","spiritual"]),
    ("caregiver_service","Caregiver Respect",["Moon","Venus"],"mother unavailable/unsafe ho to safe caregiver/elder woman ki practical help ko modern symbolic alternative ke roop mein use karein",["family","home","relationship"]),
    ("spouse_respect","Relationship Respect Action",["Venus","Moon"],"partner ke liye ek concrete respectful action karein: listening, fair workload, appreciation ya pending issue calmly address karein",["relationship","home"]),
    ("home_cleanliness","Home Cleanliness Reset",["Venus","Moon","Ketu"],"one cluttered zone clean karein, broken useless items responsibly remove karein aur hygiene maintain karein",["home","relationship","mind"]),
    ("desk_reset","Work Desk Reset",["Mercury","Saturn"],"work desk/files ko 15 minutes organize karein aur pending document list banayein",["career","business","mind"]),
    ("phone_detox","Phone/Scroll Detox",["Rahu","Mercury","Ketu"],"daily fixed 30-minute no-scroll window rakhein; unnecessary notifications off karein",["mind","career","relationship"]),
    ("anonymous_help","Anonymous Help",["Ketu","Saturn","Jupiter"],"bina recognition/photo ke kisi genuine need mein quietly help karein",["spiritual","mind","obstacles"]),
    ("volunteer_hour","One Volunteer Hour",["Saturn","Jupiter"],"mahine mein kam se kam ek ghanta verified community seva volunteer karein",["spiritual","career","mind"]),
    ("legal_document_order","Legal Document Order",["Saturn","Mercury","Jupiter"],"court/legal matter mein dates, receipts, notices aur counsel instructions ko one-folder system mein organize karein",["legal","obstacles","career"]),
    ("medical_appointment_support","Medical Appointment Support",["Moon","Saturn"],"elder/disabled person ko appointment transport/registration mein practical help karein; treatment advice clinician ka rahe",["health-support","family","obstacles"]),
    ("medication_pickup_help","Prescription Pickup Help",["Moon","Saturn","Mercury"],"consent ke saath kisi vulnerable person ki prescribed medicine pickup/logistics mein help karein; medicine change na karein",["health-support","family"]),
    ("first_responder_support","First-Responder Welfare Support",["Mars","Sun","Saturn"],"verified firefighter/ambulance/first-responder welfare initiative ko optional support dein",["career","health-support","spiritual"]),
    ("road_safety","Road Safety Discipline",["Mars","Saturn","Rahu"],"seatbelt/helmet, no-phone driving, speed discipline aur vehicle maintenance strictly follow karein",["travel","vehicle","health-support"]),
    ("vehicle_maintenance","Vehicle Maintenance Due",["Mars","Saturn","Mercury"],"tyre, brake, lights, insurance/PUC/service due ho to practical maintenance complete karein",["vehicle","travel","money"]),
    ("property_paper_check","Property Paper Check",["Mars","Saturn","Mercury"],"property deal/document ko qualified professional se verify karein; remedy ko legal due diligence ka substitute na banayein",["property","legal","money"]),
    ("construction_safety","Construction Safety Review",["Mars","Saturn"],"construction/renovation mein worker PPE, wiring, access aur site safety practical review karein",["property","business","health-support"]),
    ("study_block","Daily Study Block",["Mercury","Jupiter"],"15–30 minute distraction-free learning block daily rakhein",["education","career"]),
    ("teach_free","Teach One Skill Free",["Mercury","Jupiter"],"kisi needy learner ko ek practical skill/subject free sikhayein",["education","career","spiritual"]),
    ("reading_donation","Useful Book Donation",["Mercury","Jupiter"],"verified school/library/student ko genuinely useful book donate karein",["education","career"]),
    ("quiet_morning","Quiet Morning Start",["Sun","Moon"],"sunrise ritual possible na ho to first 5 minutes phone-free, calm, disciplined morning start karein",["career","mind","self"]),
    ("sunlight_walk","Safe Morning Light",["Sun"],"health-permitting morning natural light mein short walk/sit karein; sunscreen/medical advice as appropriate",["career","mind","health-support"]),
    ("water_conservation","Water Conservation",["Moon","Saturn"],"leaks fix karein aur daily water wastage reduce karein",["home","money","spiritual"]),
    ("kitchen_food_respect","Food Respect",["Moon","Jupiter"],"food waste reduce karein aur usable surplus safely share karein",["family","money","spiritual"]),
    ("weekly_declutter","Weekly Declutter",["Ketu","Saturn"],"har week 10 unused items responsibly sort/recycle/donate karein",["home","mind","spiritual"]),
    ("silent_service","Silent Service",["Ketu","Jupiter"],"kisi service action ko bina social media/post ke quietly complete karein",["spiritual","mind"]),
]
for key,title,planets,desc,concerns in EXPANDED_SEVA_GROUPS:
    MODERN_UPAY_BANK.append(_r(key,title,desc+".",planets,concerns,cost="₹0+",frequency="As practical"))

PREFERENCE_BLOCKS = {
    "noSunrise": {"sunrise"},
    "noDonation": {"donation"},
    "noMantra": {"mantra"},
    "noTemple": {"temple"},
    "noAnimals": {"animals"},
    "noRiver": {"river"},
    "homeOnly": {"outside"},
    "noDonation": {"donation"},
    "noMantra": {"mantra"},
    "noSunrise": {"sunrise"},
    "mobilityLimit": {"travel_required"},
}

CONCERN_PLANETS = {
    "money":["Saturn","Mercury","Jupiter","Venus","Rahu"],
    "career":["Sun","Saturn","Mercury","Jupiter","Mars"],
    "business":["Mercury","Saturn","Rahu","Jupiter","Mars"],
    "relationship":["Venus","Moon","Mercury","Mars"],
    "property":["Mars","Moon","Saturn"],
    "travel":["Rahu","Mercury","Moon"],
    "mind":["Moon","Mercury","Ketu","Saturn"],
    "spiritual":["Jupiter","Ketu","Saturn","Sun"],
    "legal":["Saturn","Jupiter","Mercury","Rahu"],
    "fraud":["Rahu","Mercury","Saturn"],
    "education":["Mercury","Jupiter","Moon"],
    "family":["Moon","Sun","Venus","Jupiter"],
    "debt":["Saturn","Mercury","Rahu"],
    "health-support":["Moon","Sun","Saturn","Jupiter"],
    "general":PLANETS,
}


def _planet_mentions(value:Any, found:Optional[List[str]]=None, depth:int=0) -> List[str]:
    """Conservatively collect explicit planet-name mentions from existing chart evidence."""
    if found is None: found=[]
    if depth>5: return found
    if isinstance(value,str):
        low=value.lower()
        for p in PLANETS:
            if p.lower() in low and p not in found: found.append(p)
    elif isinstance(value,dict):
        for k,v in value.items():
            if str(k).lower() in {"source_registry","source_tiers","remedy_catalog"}: continue
            _planet_mentions(v,found,depth+1)
    elif isinstance(value,list):
        for v in value[:80]: _planet_mentions(v,found,depth+1)
    return found


def _activation_layers(chart:Dict[str,Any]) -> Dict[str,List[str]]:
    """Use already-computed chart layers; does not invent new astrology rules."""
    dasha=[]; transit=[]; alerts=[]
    for key in ["dasha","vimshottari","dasha_4_level","current_dasha","active_dasha","prediction_engine"]:
        if key in chart: dasha=_planet_mentions(chart.get(key),dasha)
    for key in ["transits","transit","live_transits","sudden_radar","v19_2_3"]:
        if key in chart: transit=_planet_mentions(chart.get(key),transit)
    for key in ["critical_alert_center","alerts","yoga_dosha"]:
        if key in chart: alerts=_planet_mentions(chart.get(key),alerts)
    return {"dasha":dasha[:5],"transit":transit[:5],"alerts":alerts[:5]}


def _preference_compatible(item:Dict[str,Any], prefs:Dict[str,Any]) -> bool:
    text=(item.get("action","")+" "+item.get("title","")+" "+item.get("category","")).lower()
    if prefs.get("noDonation") and any(w in text for w in ["donat","sponsor","ration","meal support","fee support","support dein"]): return False
    if prefs.get("noMantra") and "mantra" in text: return False
    if prefs.get("noSunrise") and any(w in text for w in ["sunrise","surya jal","arghya"]): return False
    if prefs.get("mobilityLimit") and any(w in text for w in ["visit","centre","shelter","public place","cleanup","langar"]): return False
    if prefs.get("zeroOnly") and not item.get("cost","").startswith("₹0"): return False
    return True

def _active_planets_from_chart(chart:Dict[str,Any]) -> List[str]:
    # Prefer planets already selected by the existing remedy engine, then fall back to natal placements.
    out: List[str] = []
    rp = chart.get("remedy_plan") or {}
    for x in (rp.get("primary") or []) + (rp.get("secondary") or []):
        p = x.get("planet") if isinstance(x,dict) else None
        if p in PLANETS and p not in out:
            out.append(p)
    for p in chart.get("placements") or []:
        name = p.get("planet")
        if name in PLANETS and name not in out:
            out.append(name)
    return out[:9]


def _allowed(item:Dict[str,Any], prefs:Dict[str,Any]) -> bool:
    if not _preference_compatible(item,prefs):
        return False
    needs=set(item.get("needs") or [])
    for pref,blocked in PREFERENCE_BLOCKS.items():
        if prefs.get(pref) and needs.intersection(blocked):
            return False
    if prefs.get("lowCost"):
        c=item.get("cost","")
        if any(s in c for s in ["₹200+","₹300+","Variable"]):
            return False
    if prefs.get("noFamilyContact") and item["id"] in {"mentor_thanks"}:
        # mentor is still allowed; family-specific direct contact is not forced anywhere in this bank.
        pass
    return True


def _score(item:Dict[str,Any], active:List[str], concern:str, prefs:Dict[str,Any], layers:Optional[Dict[str,List[str]]]=None) -> int:
    score=16
    layers=layers or {}
    planets=item.get("planets",[])
    for p in planets:
        if p in active: score += 8
        if p in CONCERN_PLANETS.get(concern,[]): score += 9
        if p in layers.get("dasha",[]): score += 9
        if p in layers.get("transit",[]): score += 6
        if p in layers.get("alerts",[]): score += 5
    if concern in item.get("concerns",[]): score += 22
    if item.get("source_tier") in {"A","B"}: score += 5
    if item.get("category") in {"modern_seva","safety"}: score += 3
    if prefs.get("lowCost") and item.get("cost","").startswith("₹0"): score += 12
    if prefs.get("homeOnly") and "outside" not in item.get("needs",[]): score += 5
    if prefs.get("zeroOnly") and item.get("cost","").startswith("₹0"): score += 10
    return min(100,score)


def _explain_selection(item:Dict[str,Any], active:List[str], concern:str, layers:Dict[str,List[str]]) -> List[str]:
    why=[]
    if concern in item.get("concerns",[]): why.append(f"Direct concern match: {concern}")
    overlap=[p for p in item.get("planets",[]) if p in active]
    if overlap: why.append("Existing remedy/chart activation: "+", ".join(overlap))
    for label,key in [("Dasha","dasha"),("Transit","transit"),("Alert","alerts")]:
        hit=[p for p in item.get("planets",[]) if p in layers.get(key,[])]
        if hit: why.append(f"{label} layer agreement: "+", ".join(hit))
    if item.get("source_tier") in {"A","B"}: why.append("Higher source tier available")
    if item.get("source_tier")=="E": why.append("Modern safe substitute; not presented as an original Lal Kitab rule")
    return why or ["Safe practical fit after preference and conflict filtering"]


def upay_intelligence(chart:Dict[str,Any], concern:str="general", preferences:Optional[Dict[str,Any]]=None,
                      limit:int=24) -> Dict[str,Any]:
    prefs=preferences or {}
    active=_active_planets_from_chart(chart)
    layers=_activation_layers(chart)
    candidates=[]
    for item in MODERN_UPAY_BANK:
        if not _allowed(item,prefs):
            continue
        if concern!="general" and concern not in item.get("concerns",[]) and not set(item.get("planets",[])).intersection(CONCERN_PLANETS.get(concern,[])):
            continue
        row=dict(item)
        row["score"]=_score(item,active,concern,prefs,layers)
        row["why_selected"]=_explain_selection(item,active,concern,layers)
        row["source_confidence"]="VERIFIED PRINCIPLE" if item.get("source_tier")=="A" else "SUPPORTING" if item.get("source_tier") in {"B","C"} else "MODERN SAFE ALTERNATIVE"
        row["priority"]="HIGH" if row["score"]>=70 else "MEDIUM" if row["score"]>=50 else "LOW"
        candidates.append(row)
    candidates.sort(key=lambda x:(x["score"], x["category"]=="safety"),reverse=True)

    # Conflict guard: never recommend an unlimited stack. One main + up to two alternatives.
    must_do = next((x for x in candidates if x["id"]!="no_remedy" and x.get("score",0)>=48), None)
    alternatives=[]
    seen_cat=set()
    for x in candidates:
        if must_do and x["id"]==must_do["id"]: continue
        if x["id"]=="no_remedy": continue
        key=(x["category"], tuple(x["planets"][:1]))
        if key in seen_cat: continue
        seen_cat.add(key)
        alternatives.append(x)
        if len(alternatives)>=2: break

    zero_cost=next((x for x in candidates if x.get("cost","").startswith("₹0") and x["id"]!="no_remedy"),None)
    if not must_do:
        must_do=next(x for x in MODERN_UPAY_BANK if x["id"]=="no_remedy")
        must_do=dict(must_do,score=100,priority="HIGH")

    return {
        "version":"19.3.1",
        "title":"Adaptive Source-Grounded Upay Prescription OS",
        "concern":concern,
        "active_planets":active,
        "activation_layers":layers,
        "source_principles":SOURCE_PRINCIPLES,
        "source_tiers":SOURCE_TIERS,
        "source_registry":SOURCE_REGISTRY,
        "conflict_guard":{
            "status":"ON",
            "rule":"Do not blindly stack remedies. One main action + limited alternatives; 'No remedy needed' is valid.",
            "max_visible_prescription":3,
        },
        "decision":{"remedy_needed":must_do.get("id")!="no_remedy","reason":"A remedy is shown only after concern, chart-layer, source, safety and feasibility checks."},
        "prescription":{"must_do":must_do,"alternatives":alternatives,"zero_cost":zero_cost},
        "catalog":{"total":len(MODERN_UPAY_BANK),"returned":min(limit,len(candidates)),"items":candidates[:limit]},
        "preferences":prefs,
        "safety":[
            "No alcohol-gifting recommendation to workers/sanitation staff; use meal/tea/ration/safety-kit substitutes.",
            "No forced contact with deceased/absent/estranged/unsafe family relationships.",
            "No river/drain pollution, wildlife products, unsafe fire/smoke, unknown ingestion or animal harm.",
            "Medical/legal/financial problems require appropriate real-world professional action first.",
            "Modern seva/behaviour items are clearly labelled and are not presented as verbatim early Lal Kitab remedies.",
        ],
        "note":"Astrology is a traditional belief system. Scores rank software relevance and layer agreement, not probability or proof of effect.",
    }


def catalog_stats() -> Dict[str,Any]:
    cats={}
    planets={p:0 for p in PLANETS}
    for x in MODERN_UPAY_BANK:
        cats[x["category"]]=cats.get(x["category"],0)+1
        for p in x["planets"]:
            if p in planets: planets[p]+=1
    return {"version":"19.3.1","total":len(MODERN_UPAY_BANK),"categories":cats,"planet_coverage":planets,"source_tiers":SOURCE_TIERS,"source_registry":SOURCE_REGISTRY}
