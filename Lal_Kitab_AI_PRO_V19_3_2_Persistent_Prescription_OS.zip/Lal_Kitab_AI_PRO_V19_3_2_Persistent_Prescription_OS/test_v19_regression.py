from engine import chart_payload
EXPECTED={'Sun':9,'Moon':3,'Mars':9,'Mercury':9,'Jupiter':8,'Venus':10,'Saturn':2,'Rahu':4,'Ketu':10}
def test_verified_ludhiana_chart():
    c=chart_payload({'name':'Golden Fixture','birth_date':'1989-07-20','birth_time':'15:07:30','city':'Ludhiana','timezone_offset':5.5,'latitude':30.900965,'longitude':75.857276,'rule_profile':'1940-foundation'})
    assert c['lagna']['sign']=='Scorpio'
    got={p['planet']:p['house'] for p in c['placements']}
    assert got==EXPECTED,(got,EXPECTED)
    for p in c['placements']:
        assert p['house']==p['whole_sign_house']
        assert p['natural_zodiac_index']==p['sign_no']
if __name__=='__main__':
    test_verified_ludhiana_chart(); print('V19 GOLDEN CHART PASS',EXPECTED)
