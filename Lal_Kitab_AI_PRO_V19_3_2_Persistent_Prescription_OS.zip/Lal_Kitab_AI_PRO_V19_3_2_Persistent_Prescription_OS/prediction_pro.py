from __future__ import annotations

"""Explainable Lal Kitab-inspired prediction prioritization engine.

This module is intentionally non-deterministic. It ranks symbolic emphasis across
life areas using multiple chart layers and exposes the evidence that moved each
score. Scores are interpretive software indexes, not probabilities.
"""

from datetime import datetime
from typing import Dict, List, Optional, Tuple

from engine import (
    RULE_PROFILES, annual_rotation_from_natal, annual_snapshot, house_cycle_for_age,
)

DOMAIN_RULES: Dict[str, Dict] = {
    "career": {
        "label":"Career & Status", "houses":{10:1.75,6:0.95,11:1.05,2:0.55,3:0.45},
        "planets":{"Saturn":1.30,"Sun":1.20,"Mercury":1.00,"Mars":0.75,"Jupiter":0.75},
        "practical":"Prioritise skill depth, consistency, documentation, reputation and lawful professional decisions."
    },
    "business": {
        "label":"Business & Trade", "houses":{7:1.55,3:1.05,10:1.05,11:1.10,2:0.85,8:0.25},
        "planets":{"Mercury":1.30,"Venus":0.95,"Mars":0.80,"Rahu":0.75,"Saturn":0.70,"Jupiter":0.65},
        "practical":"Validate demand, margins, cash flow, contracts and partner incentives before committing capital."
    },
    "money": {
        "label":"Money & Gains", "houses":{2:1.55,11:1.55,10:0.80,5:0.45,8:0.30},
        "planets":{"Jupiter":1.10,"Venus":1.00,"Mercury":0.90,"Saturn":0.65,"Rahu":0.40},
        "practical":"Use budgeting, diversification and qualified financial advice; this score is not a return forecast."
    },
    "relationships": {
        "label":"Relationships & Partnership", "houses":{7:1.70,2:0.85,4:0.75,5:0.65,11:0.30},
        "planets":{"Venus":1.25,"Moon":1.00,"Jupiter":0.70,"Mercury":0.55,"Mars":0.30},
        "practical":"Communication, consent, compatibility and boundaries matter more than astrological timing claims."
    },
    "family": {
        "label":"Family & Support System", "houses":{2:1.45,4:1.35,9:0.55,3:0.40},
        "planets":{"Moon":1.20,"Jupiter":0.85,"Sun":0.60,"Venus":0.55,"Mercury":0.35},
        "practical":"Use clear expectations, practical support and respectful boundaries inside family systems."
    },
    "learning": {
        "label":"Learning & Strategy", "houses":{5:1.45,4:0.70,9:1.05,3:0.85,2:0.40},
        "planets":{"Mercury":1.30,"Jupiter":1.15,"Moon":0.60,"Sun":0.45},
        "practical":"Build a concrete study plan, feedback loop and measurable practice routine."
    },
    "property": {
        "label":"Home & Property", "houses":{4:1.65,2:0.75,11:0.60,8:0.40,10:0.30},
        "planets":{"Moon":1.10,"Mars":0.80,"Venus":0.70,"Saturn":0.60,"Jupiter":0.55},
        "practical":"Use title checks, inspections, affordability analysis and legal documentation for property decisions."
    },
    "travel_foreign": {
        "label":"Travel & Foreign Links", "houses":{12:1.45,9:1.25,3:0.75,7:0.45,11:0.35},
        "planets":{"Rahu":1.20,"Jupiter":0.80,"Mercury":0.70,"Moon":0.45,"Saturn":0.35},
        "practical":"Verify visas, budgets, safety and logistics. Astrology cannot guarantee travel approval or outcomes."
    },
    "leadership": {
        "label":"Leadership & Visibility", "houses":{1:1.30,10:1.50,5:0.75,9:0.55,11:0.40},
        "planets":{"Sun":1.35,"Mars":0.90,"Jupiter":0.75,"Saturn":0.55,"Mercury":0.45},
        "practical":"Use accountability, communication and track record rather than status-seeking."
    },
    "creativity": {
        "label":"Creativity & Expression", "houses":{5:1.55,3:1.05,11:0.55,7:0.35},
        "planets":{"Venus":1.15,"Mercury":0.95,"Moon":0.75,"Sun":0.55,"Rahu":0.40},
        "practical":"Protect a regular creative practice, feedback loop and publishing/output cadence."
    },
    "network": {
        "label":"Network & Community", "houses":{11:1.65,3:0.80,7:0.65,10:0.55},
        "planets":{"Mercury":1.00,"Jupiter":0.85,"Venus":0.75,"Rahu":0.65,"Saturn":0.45},
        "practical":"Invest in trustworthy relationships, reciprocity and clear professional communication."
    },
    "discipline": {
        "label":"Discipline & Execution", "houses":{6:1.35,10:1.10,3:0.70,1:0.55},
        "planets":{"Saturn":1.35,"Mars":0.95,"Sun":0.55,"Mercury":0.50},
        "practical":"Use routines, deadlines, maintenance and measured follow-through rather than bursts of effort."
    },
    "reputation": {
        "label":"Reputation & Public Image", "houses":{10:1.55,1:0.90,11:0.75,9:0.45},
        "planets":{"Sun":1.20,"Saturn":0.90,"Jupiter":0.70,"Mercury":0.55,"Venus":0.45},
        "practical":"Protect credibility through accurate claims, reliable delivery and clean public communication."
    },
    "communication": {
        "label":"Communication & Coordination", "houses":{3:1.50,7:1.05,2:0.75,11:0.65,10:0.45},
        "planets":{"Mercury":1.40,"Moon":0.70,"Venus":0.55,"Jupiter":0.45,"Saturn":0.35},
        "practical":"Use clear written agreements, active listening, measured speech and explicit handoffs instead of assumptions."
    },
    "decision_quality": {
        "label":"Decision Quality & Verification", "houses":{5:1.20,9:1.00,6:0.90,10:0.80,2:0.55},
        "planets":{"Mercury":1.15,"Jupiter":1.00,"Saturn":0.85,"Sun":0.55,"Moon":0.35},
        "practical":"Separate facts, assumptions and risks; use checklists and qualified advice for high-stakes choices."
    },
    "inner_growth": {
        "label":"Inner Growth & Reflection", "houses":{9:1.10,12:1.35,8:0.80,5:0.45,4:0.35},
        "planets":{"Jupiter":1.05,"Ketu":1.10,"Moon":0.65,"Saturn":0.50},
        "practical":"Use reflection as support, not a substitute for qualified medical, legal or financial help."
    },
}


def _clamp(v: float, lo: float=0.0, hi: float=100.0) -> float:
    return max(lo, min(hi, v))


def _band(score: float) -> str:
    if score >= 74: return "Strong supportive emphasis"
    if score >= 62: return "Supportive / constructive emphasis"
    if score >= 48: return "Mixed but workable emphasis"
    if score >= 36: return "Higher-friction / needs management"
    return "Strong caution / strengthen fundamentals"


def _confidence(evidence_count: int, layers: int, birth_time_present: bool=True) -> int:
    # Method confidence only: how many independent software layers contributed.
    c = 44 + min(24, evidence_count * 2) + min(16, layers * 2) + (4 if birth_time_present else -8)
    return int(_clamp(c, 42, 88))


def _status_delta(p: Dict, weight: float) -> Tuple[float, List[str]]:
    d=0.0; notes=[]
    status=p.get("status",[]) or []
    state=str(p.get("state","") or "")
    if "Uchcha reference" in status:
        d += 3.2*weight; notes.append("Uchcha reference")
    if "Pakka Ghar" in status:
        d += 2.3*weight; notes.append("Pakka Ghar")
    if "Neecha reference" in status:
        d -= 4.2*weight; notes.append("Neecha reference")
    if state.lower().startswith("soya") or "Soya candidate" in status:
        d -= 2.7*weight; notes.append("Soya candidate")
    if state.lower().startswith("jagta"):
        d += 1.4*weight; notes.append("Jagta reference")
    return d, notes


def _evidence(layer: str, label: str, delta: float, direction: Optional[str]=None) -> Dict:
    if direction is None:
        direction = "support" if delta >= 1.0 else ("caution" if delta <= -1.0 else "mixed")
    return {"layer":layer,"label":label,"delta":round(delta,1),"direction":direction}


def _score_domain(chart: Dict, rule: Dict, *, active_house: Optional[int]=None,
                  annual_rotation: Optional[Dict]=None, annual_astro: Optional[Dict]=None) -> Dict:
    placements=chart.get("placements",[]) or []
    relationships=chart.get("relationships",[]) or []
    aspects=chart.get("aspects",[]) or []
    axes=chart.get("virtual_axes",[]) or []
    house_states=chart.get("house_states",[]) or []
    masnui=chart.get("masnui",[]) or []
    score=50.0; ev=[]; layers=set()
    houses=rule["houses"]; planets=rule["planets"]
    by_planet={p.get("planet"):p for p in placements}

    # Natal placements + condition labels
    for p in placements:
        h=p.get("house"); pl=p.get("planet")
        if h not in houses and pl not in planets:
            continue
        hw=houses.get(h,0.35)
        pw=planets.get(pl,0.25)
        strength=(float(p.get("score",50))-50.0)/4.8
        d=strength*max(0.45,hw) + pw*2.0*max(0.55,hw)
        sd,notes=_status_delta(p,max(0.55,hw)); d+=sd
        score+=d; layers.add("natal")
        ev.append(_evidence("Natal",f"{pl} in H{h} ({p.get('score',50)}/100){' • '+', '.join(notes) if notes else ''}",d))

    # Same-house friend/enemy relations
    for r in relationships:
        h=r.get("house")
        if h not in houses: continue
        hw=houses[h]
        rel=r.get("relationship")
        if rel=="Mutual friend": d=2.8*hw
        elif rel=="Mutual enemy": d=-3.8*hw
        else: d=0.35*hw
        score+=d; layers.add("relationship")
        ev.append(_evidence("Relationship",f"H{h}: {r.get('pair')} — {rel}",d))

    # Lal Kitab drishti to relevant houses. Use source planet condition to sign the effect.
    for a in aspects:
        th=a.get("target_house")
        if th not in houses: continue
        src=by_planet.get(a.get("planet"))
        if not src: continue
        src_strength=(float(src.get("score",50))-50)/18.0
        d=src_strength*houses[th]
        if a.get("occupied"): d*=1.25
        score+=d; layers.add("drishti")
        ev.append(_evidence("Drishti",f"{a.get('planet')} → H{th} ({a.get('aspect_count')}th reference)",d))

    # Complementary occupied axes
    for ax in axes:
        ha,hb=ax.get("house_a"),ax.get("house_b")
        if ha in houses or hb in houses:
            d=1.0*(houses.get(ha,0.3)+houses.get(hb,0.3))
            score+=d; layers.add("axis")
            ev.append(_evidence("Axis",f"Occupied complementary axis {ax.get('axis')}",d))

    # House sleeping/waking state is treated lightly because rules vary by school.
    for hs in house_states:
        h=hs.get("house")
        if h not in houses: continue
        state=str(hs.get("state","") or "")
        if "sleep" in state.lower() or "soya" in state.lower():
            d=-1.4*houses[h]; score+=d; layers.add("house-state")
            ev.append(_evidence("House state",f"H{h}: {state}",d))

    # Masnui reference: small influence only when reference planet is domain-relevant.
    for m in masnui:
        ref=str(m.get("reference","") or "")
        hit=[p for p in planets if p.lower() in ref.lower()]
        if hit:
            d=1.1; score+=d; layers.add("masnui")
            ev.append(_evidence("Masnui",f"{m.get('pair')} → {ref}",d))

    # Active 36-year house cycle is a meaningful but non-deterministic timing emphasis.
    if active_house in houses:
        d=4.2*houses[active_house]; score+=d; layers.add("36y-cycle")
        ev.append(_evidence("36-year cycle",f"Active house H{active_house}",d))

    # Annual house rotation: deliberately lighter than natal layer.
    if annual_rotation:
        for p in annual_rotation.get("placements",[]) or []:
            h=p.get("house"); pl=p.get("planet")
            if h not in houses and pl not in planets: continue
            hw=houses.get(h,0.30); pw=planets.get(pl,0.20)
            d=((float(p.get("score",50))-50)/12.0)*max(0.4,hw)+pw*0.85*max(0.45,hw)
            score+=d; layers.add("annual-rotation")
            if abs(d)>=0.65: ev.append(_evidence("Annual rotation",f"{pl} → H{h}",d))

    # Astronomical birthday comparison is shown as an explicitly experimental comparison layer.
    if annual_astro:
        for p in annual_astro.get("placements",[]) or []:
            h=p.get("house"); pl=p.get("planet")
            if h not in houses and pl not in planets: continue
            hw=houses.get(h,0.25); pw=planets.get(pl,0.15)
            d=((float(p.get("score",50))-50)/17.0)*max(0.35,hw)+pw*0.55*max(0.40,hw)
            score+=d; layers.add("annual-astro")
            if abs(d)>=0.55: ev.append(_evidence("Birthday comparison",f"{pl} in H{h}",d))

    score=_clamp(score)
    ev=sorted(ev,key=lambda x:abs(x["delta"]),reverse=True)
    support=[x for x in ev if x["direction"]=="support"][:5]
    caution=[x for x in ev if x["direction"]=="caution"][:5]
    return {
        "score":round(score,1),"band":_band(score),
        "confidence":_confidence(len(ev),len(layers),bool(chart.get("profile",{}).get("birth_time"))),
        "evidence":ev[:14],"support":support,"cautions":caution,"layers":sorted(layers),
        "practical":rule["practical"],
        "interpretation":(
            "This area has comparatively stronger symbolic support; use the window for disciplined action and verification."
            if score>=62 else
            "This area looks mixed; progress is more likely to depend on planning, timing and corrective habits than on a simple good/bad label."
            if score>=48 else
            "This area carries more friction in the software model; strengthen fundamentals and avoid high-stakes decisions based only on astrology."
        )
    }


def _age_for_year(birth_date: str, year: int) -> int:
    dob=datetime.fromisoformat(birth_date)
    return max(1,year-dob.year)


def forecast_year(chart: Dict, year: int) -> Dict:
    profile=chart.get("profile",{})
    placements=chart.get("placements",[])
    if not placements or not profile.get("birth_date"):
        raise ValueError("Chart data is incomplete")
    rp=profile.get("rule_profile","1940-foundation")
    pakka=RULE_PROFILES.get(rp,RULE_PROFILES["1940-foundation"])["pakka"]
    age=_age_for_year(profile["birth_date"],year)
    cycle=house_cycle_for_age(age)
    rotation=annual_rotation_from_natal(placements,profile["birth_date"],year,pakka)
    try:
        astro=annual_snapshot(profile.get("name","Unnamed"),profile["birth_date"],profile["birth_time"],float(profile.get("timezone_offset",5.5)),year,rp)
    except Exception:
        astro=None
    domains={}
    for key,rule in DOMAIN_RULES.items():
        x=_score_domain(chart,rule,active_house=cycle.get("house"),annual_rotation=rotation,annual_astro=astro)
        domains[key]={"key":key,"label":rule["label"],**x}
    ranked=sorted(domains.values(),key=lambda x:x["score"],reverse=True)
    return {
        "year":year,"age_reference":age,"house_cycle":cycle,
        "domains":domains,
        "scores":{k:v["score"] for k,v in domains.items()},
        "top":[{"key":x["key"],"label":x["label"],"score":x["score"]} for x in ranked[:3]],
        "watch":[{"key":x["key"],"label":x["label"],"score":x["score"]} for x in ranked[-3:]],
        "method":"Natal multi-factor chart + source-aware 36-year house cycle + annual house rotation + separately-labelled birthday comparison.",
        "certainty":"Interpretive emphasis index, not a statistical probability or guaranteed event forecast."
    }


def prediction_package(chart: Dict, years: int=10) -> Dict:
    current_year=datetime.now().year
    base_cycle=chart.get("timing",{}).get("house_cycle_36",{}) or {}
    base_rotation=chart.get("annual_rotation")
    base_astro=chart.get("annual")
    domains={}
    for key,rule in DOMAIN_RULES.items():
        x=_score_domain(chart,rule,active_house=base_cycle.get("house"),annual_rotation=base_rotation,annual_astro=base_astro)
        domains[key]={"key":key,"label":rule["label"],**x}
    ranked=sorted(domains.values(),key=lambda x:x["score"],reverse=True)
    years=max(1,min(int(years),12))
    forecast=[]
    for year in range(current_year,current_year+years):
        try: forecast.append(forecast_year(chart,year))
        except Exception as exc: forecast.append({"year":year,"error":str(exc)})
    return {
        "engine":"OMNIVISION Explainable Prediction Engine v6",
        "domains":domains,
        "strongest":[{"key":x["key"],"label":x["label"],"score":x["score"],"band":x["band"],"confidence":x["confidence"]} for x in ranked[:5]],
        "watch":[{"key":x["key"],"label":x["label"],"score":x["score"],"band":x["band"],"confidence":x["confidence"]} for x in ranked[-4:]],
        "forecast":forecast,
        "method_note":"The engine keeps astronomical placement, Lal Kitab reference rules, timing layers and interpretation separate. It combines placement strength, relevant houses/planets, Pakka/Uchcha/Neecha labels, Soya/Jagta state, same-house relationships, Lal Kitab drishti, occupied axes, house state, Masnui references, the 36-year cycle and annual comparison layers; V6 also derives explainable event-theme windows and exposes cross-layer consensus/contradiction in a separate audit engine from multiple life-domain scores.",
        "confidence_note":"Confidence means software evidence coverage, not truth probability. Birth-time uncertainty and source-school differences can materially change house-sensitive conclusions.",
        "safety_note":"No deterministic prediction of death, disease, pregnancy, crime, court result, gambling win, exact investment return or other safety-critical outcome is generated."
    }


def forecast_range(chart: Dict, start_year: int, end_year: int) -> Dict:
    start=max(1900,min(int(start_year),2200)); end=max(start,min(int(end_year),2200))
    if end-start>25: raise ValueError("Forecast range is limited to 26 years per request")
    rows=[forecast_year(chart,y) for y in range(start,end+1)]
    return {
        "start_year":start,"end_year":end,
        "areas":[{"key":k,"label":v["label"]} for k,v in DOMAIN_RULES.items()],
        "years":[{
            "year":r["year"],"age_reference":r["age_reference"],"house_cycle":r["house_cycle"],
            "scores":r["scores"],"top":r["top"][0],"watch":r["watch"][0]
        } for r in rows],
        "note":"Year-by-year comparison uses the same transparent multi-factor engine with annual timing layers. Scores are symbolic emphasis indexes, not event probabilities."
    }


def enrich_chart(chart: Dict, years: int=10) -> Dict:
    pkg=prediction_package(chart,years=years)
    chart["pro_predictions"]=pkg
    chart["predictions"]=list(pkg["domains"].values())
    chart["prediction_summary"]={
        "strongest":pkg["strongest"],"watch":pkg["watch"],
        "method":pkg["method_note"],"certainty":pkg["confidence_note"]
    }
    current_year=datetime.now().year
    chart["event_windows"]=event_windows_for_year(chart,current_year)
    chart["decision_dashboard"]=decision_dashboard(chart,current_year)
    return chart


# Event-theme layer: combines several domain scores so no single placement creates an event claim.
EVENT_RULES: Dict[str, Dict] = {
    'career_move': {'label':'Career Move / Role Change','domains':{'career':0.45,'reputation':0.25,'leadership':0.15,'discipline':0.15},'type':'support','question':'Is there a concrete role, promotion, skill or responsibility worth pursuing this year?'},
    'business_expansion': {'label':'Business Expansion / New Offer','domains':{'business':0.40,'money':0.25,'network':0.20,'discipline':0.15},'type':'support','question':'Do demand, margins, contracts and working capital support expansion?'},
    'income_building': {'label':'Income / Savings Build','domains':{'money':0.50,'career':0.20,'business':0.15,'discipline':0.15},'type':'support','question':'Which measurable income, saving or cost-control action is realistic now?'},
    'relationship_commitment': {'label':'Relationship Commitment / Partnership','domains':{'relationships':0.55,'family':0.20,'discipline':0.10,'network':0.15},'type':'support','question':'Are communication, consent, values and practical expectations aligned?'},
    'property_move': {'label':'Home / Property Decision','domains':{'property':0.55,'money':0.20,'family':0.15,'discipline':0.10},'type':'support','question':'Are affordability, title/legal checks, inspection and family needs clear?'},
    'foreign_mobility': {'label':'Foreign Travel / Relocation Link','domains':{'travel_foreign':0.55,'career':0.15,'network':0.15,'money':0.15},'type':'support','question':'Are visa, logistics, finances and purpose strong enough for the move?'},
    'study_certification': {'label':'Study / Certification Push','domains':{'learning':0.55,'discipline':0.25,'career':0.10,'reputation':0.10},'type':'support','question':'Which qualification or skill would create the highest practical leverage?'},
    'visibility_launch': {'label':'Launch / Public Visibility','domains':{'leadership':0.30,'creativity':0.30,'reputation':0.25,'network':0.15},'type':'support','question':'Is the work ready to publish, present or launch with accurate claims?'},
    'network_alliance': {'label':'Network / Strategic Alliance','domains':{'network':0.45,'business':0.20,'relationships':0.20,'reputation':0.15},'type':'support','question':'Which relationship is reciprocal, trustworthy and strategically useful?'},
    'contract_conflict': {'label':'Contract / Conflict Management','domains':{'business':0.30,'relationships':0.25,'discipline':0.25,'reputation':0.20},'type':'risk','question':'Where should terms, records, expectations or boundaries be made clearer?'},
    'overstretch': {'label':'Overstretch / Execution Pressure','domains':{'discipline':0.45,'money':0.20,'career':0.20,'inner_growth':0.15},'type':'risk','question':'Which commitments should be simplified, delayed or documented more carefully?'},
}


def _event_band(score: float, kind: str) -> str:
    if kind=='risk':
        if score>=70: return 'High management priority'
        if score>=58: return 'Moderate management priority'
        if score>=45: return 'Watch / verify'
        return 'Lower symbolic pressure'
    if score>=72: return 'Strong symbolic window'
    if score>=62: return 'Supportive window'
    if score>=50: return 'Conditional / workable'
    if score>=40: return 'Higher-friction window'
    return 'Low emphasis / use caution'


def event_windows_for_year(chart: Dict, year: int) -> Dict:
    fy=forecast_year(chart,int(year))
    domains=fy['domains']; events=[]
    for key,rule in EVENT_RULES.items():
        raw=0.0; evidence=[]; conf=[]
        for dk,w in rule['domains'].items():
            d=domains.get(dk) or {'score':50,'confidence':50,'label':dk}
            raw += float(d['score'])*w
            conf.append(float(d.get('confidence',50))*w)
            evidence.append({'domain':dk,'label':d.get('label',dk),'score':d.get('score',50),'weight':w})
        score=(100-raw) if rule['type']=='risk' else raw
        score=_clamp(score)
        events.append({'key':key,'label':rule['label'],'type':rule['type'],'score':round(score,1),
                       'band':_event_band(score,rule['type']),'confidence':round(sum(conf),1),
                       'evidence':sorted(evidence,key=lambda x:x['weight'],reverse=True),
                       'verification_question':rule['question']})
    support=sorted([x for x in events if x['type']=='support'],key=lambda x:x['score'],reverse=True)
    risk=sorted([x for x in events if x['type']=='risk'],key=lambda x:x['score'],reverse=True)
    return {'year':int(year),'events':events,'top_windows':support[:5],'management_flags':[x for x in risk if x['score']>=45][:3],'lower_pressure':risk[-3:],
            'timing':fy['house_cycle'],'method':'Derived from multiple V6 domain scores plus the year-specific 36-year/annual layers; no single graha creates an event claim.',
            'certainty':'These are symbolic planning windows, not statistical event probabilities, dates or guarantees.'}


def decision_dashboard(chart: Dict, year: int) -> Dict:
    e=event_windows_for_year(chart,year)
    return {
        'year':year,
        'best_use':[{'label':x['label'],'score':x['score'],'question':x['verification_question']} for x in e['top_windows'][:3]],
        'protect':[{'label':x['label'],'score':x['score'],'question':x['verification_question']} for x in e['management_flags'][:2]],
        'rules':['Verify real-world facts before acting.','Use astrology as a reflection/timing aid, not as sole justification for medical, legal, financial or safety-critical decisions.','When birth time or source rule is uncertain, downgrade confidence rather than forcing a precise claim.']
    }
