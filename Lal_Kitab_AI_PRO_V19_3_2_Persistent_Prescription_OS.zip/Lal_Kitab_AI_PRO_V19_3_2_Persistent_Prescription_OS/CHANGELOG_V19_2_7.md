# V19.2.7 — City Intelligence Expansion

- Expanded built-in city/town presets from 12 to 174 across India and major world locations.
- Searchable city/town field replaces long dropdown.
- Selecting a known city auto-fills latitude, longitude and default UTC offset.
- Custom city/town/district names are allowed when coordinates are entered manually.
- Unknown places no longer silently fall back to Delhi; generation stops and asks for coordinates.
- Existing cloud persistence, Client 360, Simple Power Mode, predictions, remedies and 15-day radar remain intact.
- Golden Kundli regression remains locked.

Accuracy note: preset UTC offsets are defaults; historical DST-sensitive births outside India should be verified against the birth-date timezone in a future timezone-history layer.
