from __future__ import annotations

"""Large, safety-filtered Lal Kitab-inspired remedy catalog.

This module deliberately separates:
1) traditional motif (planet/house symbolic association),
2) a low-risk modern action, and
3) blocked variants that should not be operationalized.

The text is paraphrased and normalized rather than copied from any single source.
"""

from typing import Dict, List, Optional

PLANETS = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu"]

PLANET_DATA: Dict[str, Dict] = {
    "Sun": {
        "hi":"सूर्य", "day":"Sunday", "themes":["authority","father/mentors","self-respect","public role"],
        "items":["wheat","jaggery","copper item","simple red/orange cloth"],
        "actions":[
            "Offer clean water toward the morning Sun from a reusable vessel, without creating litter.",
            "Show practical respect to father-figures, mentors or legitimate authority while keeping healthy boundaries.",
            "Donate wheat or another staple food within your means.",
            "Use a simple copper item as a symbolic reminder of disciplined conduct; no expensive purchase is needed.",
            "Keep the east-facing area of your room/home clean and uncluttered.",
            "Begin Sunday with one completed responsibility before leisure.",
            "Avoid ego-driven arguments and public promises you cannot keep.",
            "Help an elder with a practical task or service.",
        ],
    },
    "Moon": {
        "hi":"चंद्र", "day":"Monday", "themes":["mind","mother/caregivers","home","emotional rhythm"],
        "items":["rice","milk donation","silver-coloured item","clean water"],
        "actions":[
            "Keep sleep and waking times steady for a week as a symbolic Moon discipline.",
            "Support your mother or a caregiving elder through a practical act where appropriate.",
            "Donate rice or another white staple food to a verified community kitchen.",
            "Keep drinking-water storage clean and covered.",
            "Place a clean glass of water near the bedside only if safe, then use it for a plant the next morning.",
            "Keep a small inexpensive silver-coloured object as a symbolic reminder rather than buying jewellery.",
            "Reduce reactive communication when emotionally overloaded.",
            "Create one calm, uncluttered corner at home for reflection.",
        ],
    },
    "Mars": {
        "hi":"मंगल", "day":"Tuesday", "themes":["courage","siblings","energy","conflict","initiative"],
        "items":["red lentils","copper","red cloth","tree/plant care"],
        "actions":[
            "Channel extra energy into safe exercise, walking or constructive physical work.",
            "Donate red lentils or another protein staple to a community kitchen.",
            "Repair one broken household item instead of leaving it pending.",
            "Keep relations with siblings/cousins respectful and avoid impulsive escalation.",
            "Plant or responsibly care for a tree/plant where local rules permit.",
            "Use copper only as a low-cost symbolic object; do not ingest metals or metal-infused substances.",
            "On Tuesday, pause before sending angry messages or making confrontational decisions.",
            "Offer practical help to workers doing physically demanding tasks.",
        ],
    },
    "Mercury": {
        "hi":"बुध", "day":"Wednesday", "themes":["speech","learning","trade","records","siblings/young people"],
        "items":["green moong","stationery","books","green plant"],
        "actions":[
            "Donate whole green moong or another staple food through a verified channel.",
            "Donate notebooks, pens or school supplies to students.",
            "Keep contracts, receipts and messages clear and archived.",
            "Practice truthful, measured speech for one full day each Wednesday.",
            "Teach or mentor someone in a skill you know well.",
            "Care for a green plant rather than using wasteful symbolic disposal rituals.",
            "Review one financial or business record for errors before signing or sending.",
            "Support daughters, sisters or younger relatives with respect and without control.",
        ],
    },
    "Jupiter": {
        "hi":"गुरु", "day":"Thursday", "themes":["wisdom","teachers","ethics","children","expansion"],
        "items":["chana dal","books","yellow staple food","educational support"],
        "actions":[
            "Respect teachers and mentors; acknowledge useful guidance without blind obedience.",
            "Donate chana dal or another staple food through a trusted charity.",
            "Donate or lend useful books and educational material.",
            "Share knowledge freely for a short mentoring session.",
            "Keep one ethical commitment even when a shortcut looks easier.",
            "Support a child's education through time, materials or a verified scholarship fund within your means.",
            "Use Thursday for reviewing long-term goals and values.",
            "Avoid preaching, exaggeration and status-based moral superiority.",
        ],
    },
    "Venus": {
        "hi":"शुक्र", "day":"Friday", "themes":["relationships","comfort","art","agreements","cleanliness"],
        "items":["clean clothes","white staple food","art supplies","fragrance-free hygiene essentials"],
        "actions":[
            "Keep clothes, bedding and personal spaces clean and orderly.",
            "Donate clean clothing or hygiene essentials through a reputable organization.",
            "Practice respectful communication and consent in relationships.",
            "Avoid display-driven overspending or buying status items as a remedy.",
            "Support women/girls in family or community through practical, respectful assistance.",
            "Contribute art or craft supplies to students or a community center.",
            "Resolve one small relationship misunderstanding without manipulation.",
            "Use Friday to review subscriptions, luxury spending and unused possessions.",
        ],
    },
    "Saturn": {
        "hi":"शनि", "day":"Saturday", "themes":["discipline","workers","delay","responsibility","service"],
        "items":["black gram","sesame","mustard oil donation","blanket/work essentials"],
        "actions":[
            "Be punctual and fair with workers, service staff and people in dependent roles.",
            "Finish one delayed responsibility before starting a new one.",
            "Donate black gram, sesame or another staple item through a verified food program.",
            "Donate a blanket, footwear or work essentials when genuinely needed and seasonally appropriate.",
            "Support a reputable animal-welfare shelter instead of feeding unsafe food to stray animals.",
            "Avoid exploiting labour, delaying dues or withholding agreed payment.",
            "Use Saturday for maintenance, repairs and cleaning neglected areas.",
            "Practice consistency rather than extreme fasting or self-punishment.",
        ],
    },
    "Rahu": {
        "hi":"राहु", "day":"Saturday / source-dependent", "themes":["ambition","foreign/unusual paths","obsession","secrecy","technology"],
        "items":["coconut donation","dark blanket","digital declutter","anonymous charity"],
        "actions":[
            "Keep legal, tax, digital and financial records transparent and backed up.",
            "Reduce one compulsive digital habit or doom-scrolling window.",
            "Donate a coconut or equivalent food item through a temple/community kitchen rather than throwing it into water.",
            "Choose one anonymous act of charity without posting it publicly.",
            "Avoid intoxicant-linked, illegal or risky 'remedies' and shortcuts.",
            "Review privacy settings, passwords and suspicious subscriptions.",
            "Declutter broken electronics through certified e-waste channels.",
            "Seek facts before acting on rumours, fear or obsession.",
        ],
    },
    "Ketu": {
        "hi":"केतु", "day":"Tuesday / source-dependent", "themes":["detachment","simplification","breaks","animals","inner work"],
        "items":["blanket donation","simple cloth","animal-welfare support","decluttering"],
        "actions":[
            "Declutter one small area and donate usable items responsibly.",
            "Support a reputable dog/animal-welfare shelter rather than feeding unsafe foods.",
            "Use solitude for reflection, journaling or prayer instead of social isolation.",
            "Donate a simple blanket or useful cloth when needed.",
            "Finish or consciously close one abandoned task.",
            "Avoid superstition-driven fear, self-harm, animal harm or costly rituals.",
            "Practice a short device-free period to simplify attention.",
            "Help an elderly, disabled or isolated person through practical community support without making assumptions about them.",
        ],
    },
}

HOUSE_DATA: Dict[int, Dict] = {
    1:{"theme":"self, conduct, body routine","hi":"स्वभाव/शरीर","actions":["Keep personal routines disciplined.","Use respectful speech when asserting yourself.","Keep your entrance and personal workspace orderly.","Avoid impulsive identity or status decisions."]},
    2:{"theme":"family, speech, stored resources","hi":"परिवार/वाणी/संचित धन","actions":["Keep family financial records transparent.","Avoid insulting or deceptive speech.","Share staple food with someone in need.","Protect emergency savings from impulsive use."]},
    3:{"theme":"effort, courage, siblings, communication","hi":"पराक्रम/भाई-बहन","actions":["Complete one pending communication.","Support a sibling/peer without controlling them.","Use physical effort constructively.","Avoid gossip and unnecessary confrontations."]},
    4:{"theme":"home, mother, emotional base","hi":"घर/माता/मन","actions":["Keep the home clean and well ventilated.","Support caregivers respectfully.","Repair a household water issue promptly.","Create a calm family routine."]},
    5:{"theme":"learning, children, creativity","hi":"संतान/बुद्धि/रचना","actions":["Support education or creative learning.","Avoid gambling-like decisions framed as luck.","Mentor a younger person respectfully.","Keep promises made to children/dependents."]},
    6:{"theme":"service, competition, obligations","hi":"सेवा/प्रतिस्पर्धा/दायित्व","actions":["Pay dues and bills on time where possible.","Keep workplace boundaries fair.","Organize medicines/documents safely without changing medical treatment.","Resolve one small debt or obligation practically."]},
    7:{"theme":"partnership, spouse, trade","hi":"साझेदारी/विवाह/व्यापार","actions":["Put agreements in writing.","Practice consent and respectful negotiation.","Avoid secret parallel commitments.","Review business partnership responsibilities."]},
    8:{"theme":"change, shared resources, hidden matters","hi":"परिवर्तन/गुप्त विषय","actions":["Keep insurance and emergency documents organized.","Avoid secrecy around shared money.","Safely dispose of unusable clutter through proper channels.","Plan for contingencies without fear-based thinking."]},
    9:{"theme":"fortune, mentors, ethics, long journeys","hi":"भाग्य/गुरु/धर्म","actions":["Respect teachers while verifying claims.","Support education or a public-good cause.","Avoid religious or moral superiority.","Plan long travel responsibly and legally."]},
    10:{"theme":"career, status, duty","hi":"कर्म/करियर/प्रतिष्ठा","actions":["Finish a visible professional responsibility.","Keep work records and promises accurate.","Treat junior staff fairly.","Avoid unethical shortcuts for recognition."]},
    11:{"theme":"gains, network, fulfilment","hi":"लाभ/नेटवर्क","actions":["Help one contact without immediate expectation of return.","Audit recurring income/expense records.","Avoid exploitative networking.","Share credit for collaborative work."]},
    12:{"theme":"expense, sleep, release, distance","hi":"व्यय/नींद/त्याग","actions":["Review unnecessary expenses.","Keep a steady sleep routine.","Donate unused usable items responsibly.","Avoid escapist or compulsive habits."]},
}

CONCERN_MAP: Dict[str, Dict] = {
    "career":{"label":"Career / Job","planets":["Saturn","Sun","Mercury","Jupiter"],"houses":[10,6,11,2]},
    "business":{"label":"Business / Trade","planets":["Mercury","Saturn","Mars","Venus"],"houses":[7,10,11,3]},
    "money":{"label":"Money / Savings","planets":["Jupiter","Mercury","Venus","Saturn"],"houses":[2,11,10,9]},
    "relationship":{"label":"Relationship / Marriage","planets":["Venus","Moon","Jupiter","Mercury"],"houses":[7,2,4,11]},
    "family":{"label":"Family / Home","planets":["Moon","Sun","Jupiter","Venus"],"houses":[2,4,9]},
    "education":{"label":"Education / Learning","planets":["Mercury","Jupiter","Sun"],"houses":[3,5,9]},
    "property":{"label":"Property / Home Assets","planets":["Mars","Saturn","Moon"],"houses":[4,8,10]},
    "travel":{"label":"Travel / Foreign Exposure","planets":["Rahu","Ketu","Moon","Jupiter"],"houses":[3,9,12]},
    "stress":{"label":"Calm / Routine","planets":["Moon","Saturn","Mercury"],"houses":[4,6,12]},
    "spiritual":{"label":"Spiritual / Simplification","planets":["Jupiter","Ketu","Moon"],"houses":[9,12,5]},
}

CATEGORY_LABELS = {
    "conduct":"Conduct / Habit",
    "charity":"Charity / Service",
    "household":"Household / Order",
    "relationship":"Relationship / Respect",
    "symbolic":"Symbolic Object",
    "animal_welfare":"Animal Welfare",
    "environment":"Environment-safe Alternative",
    "learning":"Learning / Records",
}


def _cat(text: str) -> str:
    s=text.lower()
    if any(k in s for k in ["donate","charity","support a reputable","community kitchen","help an elder","help an elderly","service"]): return "charity"
    if any(k in s for k in ["animal","dog","shelter"]): return "animal_welfare"
    if any(k in s for k in ["clean","home","room","entrance","declutter","repair","water storage","workspace"]): return "household"
    if any(k in s for k in ["relationship","mother","father","sibling","mentor","teacher","caregiver","consent"]): return "relationship"
    if any(k in s for k in ["copper","silver","object","cloth","vessel"]): return "symbolic"
    if any(k in s for k in ["record","contract","receipt","learn","teach","book","stationery","privacy","password"]): return "learning"
    if any(k in s for k in ["plant","e-waste","waterway","litter","dispose"]): return "environment"
    return "conduct"


def build_catalog() -> List[Dict]:
    rows: List[Dict] = []
    rid=1
    # Planet universal remedies
    for planet,pd in PLANET_DATA.items():
        for i,action in enumerate(pd["actions"],1):
            rows.append({
                "id":f"U{rid:04d}","planet":planet,"planet_hi":pd["hi"],"house":None,
                "category":_cat(action),"concerns":[],"title":f"{planet} universal #{i}","action":action,
                "timing":pd["day"],"duration":"Optional routine; 43-day tracking available",
                "source_class":"Traditional motif — safety-normalized","safety":"low-risk","priority":2,
                "note":"Use only if chart/context supports the planet; no guaranteed outcome."
            });rid+=1
    # House universal practices
    for house,hd in HOUSE_DATA.items():
        for i,action in enumerate(hd["actions"],1):
            rows.append({
                "id":f"H{rid:04d}","planet":None,"planet_hi":"—","house":house,
                "category":_cat(action),"concerns":[],"title":f"House {house} practice #{i}","action":action,
                "timing":"Any suitable day","duration":"Repeat as a practical habit",
                "source_class":"House-theme practical layer","safety":"low-risk","priority":1,
                "note":f"House {house}: {hd['theme']}."
            });rid+=1
    # Source-aware "house awakening" reference layer, safety-normalized.
    # Traditional sources assign one planet to each sleeping-house awakening rule; the software
    # stores these as a study/reference option, not as a guaranteed prescription.
    house_awakener={1:"Mars",2:"Moon",3:"Mercury",4:"Moon",5:"Sun",6:"Rahu",7:"Venus",8:"Moon",9:"Jupiter",10:"Saturn",11:"Jupiter",12:"Ketu"}
    for house,planet in house_awakener.items():
        hd=HOUSE_DATA[house];pd=PLANET_DATA[planet]
        awaken_actions=[
            f"House {house} awakening reference: use a low-risk {planet}-linked service habit rather than a costly ritual; start with: {pd['actions'][0]}",
            f"For a sleeping House {house} study flag, strengthen the practical theme of {hd['theme']} for 43 days and track completion before judging any result.",
            f"If using the traditional {planet} association for House {house}, prefer lawful charity, cleanliness, respectful conduct or a small symbolic reminder; avoid pollution, fear-based rituals and expensive purchases.",
        ]
        for i,action in enumerate(awaken_actions,1):
            rows.append({
                "id":f"A{rid:04d}","planet":planet,"planet_hi":pd["hi"],"house":house,
                "category":_cat(action),"concerns":[],"title":f"House {house} awakening reference #{i}","action":action,
                "timing":pd["day"],"duration":"43-day tracking available",
                "source_class":"Traditional sleeping-house awakening reference — safety-normalized",
                "safety":"low-risk","priority":2,
                "note":"Source-dependent Lal Kitab study rule; whole-chart context and school profile matter."
            });rid+=1

    # General cross-chart practices frequently seen in Lal Kitab teaching, rewritten as low-risk options.
    general_actions=[
        "Keep the home and workplace free of long-unused clutter; donate or recycle usable items responsibly.",
        "Take meals in a clean designated eating area rather than making ritual rules that create distress or conflict.",
        "Seek blessings or goodwill from parents/elders where the relationship is safe; respectful boundaries still apply.",
        "Use food donation through a verified community kitchen instead of leaving unsuitable food where animals or wildlife may be harmed.",
        "Keep drinking-water areas, storage vessels and drains clean; do not use waterways as disposal sites for ritual objects.",
        "Pay workers, helpers and service providers fairly and on time.",
        "Avoid humiliating elderly, poor, disabled or dependent people; practical dignity and fairness are preferred over symbolic show.",
        "Before adding a new remedy, complete one pending responsibility connected with the affected house theme.",
        "Use a 43-day habit tracker for any selected remedy and stop if it causes harm, conflict, financial strain or unsafe behavior.",
        "Prefer modest charity within your means; never borrow money or buy luxury items solely for an astrological remedy.",
        "Do not replace medical care, legal advice, financial planning or emergency action with astrology.",
        "Keep promises realistic and written where money, business or shared responsibilities are involved.",
        "Repair broken household items or dispose of them responsibly instead of allowing long-term neglect to accumulate.",
        "Maintain one weekly act of anonymous or low-profile service without seeking public recognition.",
        "When a traditional remedy involves animals, use a reputable animal-welfare route and species-appropriate food only.",
        "When a traditional remedy involves water, use a reusable vessel or plant-watering substitute rather than throwing materials into rivers or lakes.",
        "When a traditional remedy involves fire or smoke, follow local safety rules and use a non-fire symbolic alternative if needed.",
        "When a remedy mentions a metal, keep it external and symbolic; never ingest metals, ash or unknown preparations.",
        "Use journaling to record the issue, selected remedy, practical action and observed outcome separately.",
        "Reassess a remedy after 43 days; do not keep escalating rituals because of fear or a promise of guaranteed results.",
        "Do not use astrology to accuse relatives, partners or coworkers of causing bad luck.",
        "Do not abandon lawful contracts, treatment, education or employment solely because of a symbolic score.",
        "Keep one small daily act aligned with truthfulness, cleanliness, discipline, service or respectful speech.",
        "If multiple remedies conflict, choose the lowest-risk practical action and consult the source/rule profile before combining traditions.",
    ]
    for i,action in enumerate(general_actions,1):
        rows.append({
            "id":f"G{rid:04d}","planet":None,"planet_hi":"—","house":None,
            "category":_cat(action),"concerns":[],"title":f"General Lal Kitab-safe practice #{i}","action":action,
            "timing":"Any suitable day","duration":"Use as a sustainable routine",
            "source_class":"Cross-source Lal Kitab motif — paraphrased + safety-normalized",
            "safety":"low-risk","priority":1,
            "note":"General supportive practice; not a chart-specific prescription or guaranteed cure."
        });rid+=1

    # 108 planet x house combinations, twelve safe actions per combination.
    # This makes the catalog deeply house-personalized without copying any one website/book verbatim.
    for planet,pd in PLANET_DATA.items():
        for house,hd in HOUSE_DATA.items():
            item=pd["items"][(house-1) % len(pd["items"])]
            combos = [
                pd["actions"][(house-1) % len(pd["actions"])],
                hd["actions"][(PLANETS.index(planet)) % len(hd["actions"])],
                f"For {planet} in House {house}, combine {pd['themes'][house % len(pd['themes'])]} awareness with one concrete {hd['theme']} responsibility; keep it simple and measurable.",
                f"On {pd['day']}, review House {house} ({hd['theme']}) and complete one low-cost act of service or discipline before adding any symbolic remedy.",
                f"If you want a material symbol for {planet} in House {house}, prefer a small lawful donation involving {item} or an equivalent useful item; never overspend for astrological reasons.",
                f"Run a House {house} responsibility audit: write one unresolved issue connected with {hd['theme']}, choose one practical next action, and finish it before repeating a ritual remedy.",
                f"For the {planet}–House {house} combination, improve one relationship linked to {pd['themes'][(house+1) % len(pd['themes'])]} through respectful communication, clear boundaries and a concrete helpful act.",
                f"Use an environment-safe Lal Kitab alternative for {planet} in House {house}: do not dump ritual objects into water or public spaces; donate, reuse, recycle or dispose of symbolic items responsibly.",
                f"For {planet} in House {house}, keep a 43-day observation log: record the selected action, one real-world responsibility tied to {hd['theme']}, and whether the habit improved clarity or conduct.",
                f"Create a low-cost daan/seva option for {planet} in House {house}: give a useful staple, school/work essential or verified charitable contribution within your means, then avoid attaching a guaranteed outcome to it.",
                f"Use a household-order option for {planet} in House {house}: clean, repair or organize one area symbolically linked with {hd['theme']} and keep it maintained rather than repeating wasteful disposal rituals.",
                f"Use a speech-and-relationship option for {planet} in House {house}: avoid one recurring harmful communication pattern and replace it with a specific respectful behavior for the tracking period.",
            ]
            concerns=[k for k,v in CONCERN_MAP.items() if planet in v["planets"] or house in v["houses"]]
            for i,action in enumerate(combos,1):
                rows.append({
                    "id":f"PH{rid:04d}","planet":planet,"planet_hi":pd["hi"],"house":house,
                    "category":_cat(action),"concerns":concerns,"title":f"{planet} in House {house} — option {i}",
                    "action":action,"timing":pd["day"],"duration":"Traditionally tracked consistently; software supports 43 days",
                    "source_class":"108-combination Lal Kitab-inspired, paraphrased + safety-normalized","safety":"low-risk","priority":3,
                    "note":"Selection must consider whole-chart context; this is not an automatic prescription."
                });rid+=1
    # Concern-focused cross-planet options.
    for concern,cfg in CONCERN_MAP.items():
        for planet in cfg["planets"]:
            pd=PLANET_DATA[planet]
            for j in range(2):
                action=pd["actions"][(j+len(concern)) % len(pd["actions"])]
                rows.append({
                    "id":f"C{rid:04d}","planet":planet,"planet_hi":pd["hi"],"house":None,
                    "category":_cat(action),"concerns":[concern],"title":f"{cfg['label']} — {planet} option {j+1}",
                    "action":action,"timing":pd["day"],"duration":"Use as a supportive routine, not a substitute for practical action",
                    "source_class":"Concern index / traditional theme mapping","safety":"low-risk","priority":2,
                    "note":"The concern-to-planet mapping is interpretive and should be checked against the chart."
                });rid+=1
    return rows



def build_ultra_extensions(start_no: int=1) -> List[Dict]:
    """Additional low-risk indexed options for PRO ULTRA.

    These are normalized practice variants, not claims that every line is a verbatim
    classical remedy. They make the vault more useful for filtering and planning while
    keeping source-dependent traditional rules distinct from modern safe substitutions.
    """
    rows: List[Dict] = []
    rid=start_no
    # Six extra context variants for every graha x house pair (648 records).
    for planet,pd in PLANET_DATA.items():
        pi=PLANETS.index(planet)
        for house,hd in HOUSE_DATA.items():
            item=pd["items"][(house+pi) % len(pd["items"])]
            extra=[
                f"{planet} in House {house}: choose one truth-and-conduct correction connected with {hd['theme']}; write the exact behaviour to stop and the replacement behaviour to follow for 43 days.",
                f"{planet} in House {house}: choose one seva action linked with {pd['themes'][pi % len(pd['themes'])]} and House {house}; keep the cost modest and record completion rather than expecting a guaranteed result.",
                f"{planet} in House {house}: if using a symbolic item, use a small lawful {item} or equivalent useful donation; do not bury, burn, ingest or dump objects into public land or water.",
                f"{planet} in House {house}: use a family/relationship correction only where safe — reduce one repeated disrespectful pattern linked with {hd['theme']} and replace it with a specific boundary or helpful act.",
                f"{planet} in House {house}: add a records-and-accountability remedy — review one document, payment, promise, maintenance task or communication tied to {hd['theme']} and close the oldest pending item.",
                f"{planet} in House {house}: run a minimalist 3-part protocol on {pd['day']}: one practical duty, one modest service act and one short reflection note; do not stack multiple rituals at once.",
            ]
            concerns=[k for k,v in CONCERN_MAP.items() if planet in v['planets'] or house in v['houses']]
            for i,action in enumerate(extra,1):
                rows.append({
                    'id':f'X{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':house,
                    'category':_cat(action),'concerns':concerns,'title':f'{planet} in House {house} — ULTRA option {i}',
                    'action':action,'timing':pd['day'],'duration':'Use one selected protocol for 43 days, then review',
                    'source_class':'PRO ULTRA context variant — Lal Kitab-inspired + safety-normalized','safety':'low-risk','priority':3,
                    'note':'Use as one option within a whole-chart plan; do not combine many remedies simply to increase intensity.',
                    'remedy_group':'context_protocol','intensity':'gentle'
                });rid+=1
    # Four additional safe sleeping-house review options (48 records).
    house_awakener={1:'Mars',2:'Moon',3:'Mercury',4:'Moon',5:'Sun',6:'Rahu',7:'Venus',8:'Moon',9:'Jupiter',10:'Saturn',11:'Jupiter',12:'Ketu'}
    for house,planet in house_awakener.items():
        pd=PLANET_DATA[planet];hd=HOUSE_DATA[house]
        acts=[
            f"Sleeping-house review H{house}: first verify that the house is truly unoccupied and receives no relevant source-defined drishti before using the {planet} awakening reference.",
            f"H{house} / {planet} awakening reference: select the lowest-risk {planet} conduct or charity practice and pair it with one real-world responsibility related to {hd['theme']}.",
            f"H{house} review: track the practical house theme for 43 days before adding a second symbolic practice; improvement in routine is the observation target, not proof of astrology.",
            f"H{house} review: if the traditional version would create pollution, animal risk, fire risk or financial strain, replace it with service, donation, cleaning, repair or respectful conduct linked with {planet}.",
        ]
        for i,action in enumerate(acts,1):
            rows.append({'id':f'SA{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':house,
                         'category':_cat(action),'concerns':[],'title':f'House {house} awakening review — ULTRA {i}',
                         'action':action,'timing':pd['day'],'duration':'43-day review cycle',
                         'source_class':'Sleeping-house source-aware review — safety-normalized','safety':'low-risk','priority':3,
                         'note':'A sleeping-house label is source/rule dependent and should not be auto-diagnosed from emptiness alone.',
                         'remedy_group':'house_awakening','intensity':'gentle'});rid+=1
    # Four planet-specific protocol cards per planet (36 records).
    for planet,pd in PLANET_DATA.items():
        acts=[
            f"{planet} protocol: choose only one of the indexed {planet} actions as the core remedy and one practical responsibility as support; avoid remedy stacking.",
            f"{planet} protocol: use {pd['day']} as a weekly review point for conduct, spending, promises and service connected with {', '.join(pd['themes'][:2])}.",
            f"{planet} protocol: if charity is selected, set a sustainable budget cap first and never borrow or make a large purchase for astrological reasons.",
            f"{planet} protocol: stop and reassess any practice that creates fear, family conflict, unsafe behaviour, medical delay, legal risk or financial strain.",
        ]
        for i,action in enumerate(acts,1):
            rows.append({'id':f'PP{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':None,
                         'category':_cat(action),'concerns':[],'title':f'{planet} PRO protocol #{i}','action':action,
                         'timing':pd['day'],'duration':'Weekly review / 43-day observation','source_class':'PRO remedy planning protocol',
                         'safety':'low-risk','priority':2,'note':'Planning layer; not a classical verbatim prescription.',
                         'remedy_group':'planet_protocol','intensity':'gentle'});rid+=1
    return rows

def build_v6_extensions(start_no: int=1) -> List[Dict]:
    """420 additional V6 safe planning/index records.

    These extend search and protocol design without pretending to be 420 newly
    discovered classical prescriptions. Each record is explicitly labelled as a
    V6 safe planning or verification protocol.
    """
    rows: List[Dict] = []
    rid = start_no
    # 3 per graha x house = 324
    for planet, pd in PLANET_DATA.items():
        for house, hd in HOUSE_DATA.items():
            concerns=[k for k,v in CONCERN_MAP.items() if planet in v['planets'] or house in v['houses']]
            acts=[
                f"{planet} H{house} verification protocol: before starting an upay, write one observable issue linked with {hd['theme']}, one practical action, and one 43-day review measure; do not use coincidence as proof.",
                f"{planet} H{house} low-cost protocol: select one existing safe {planet} remedy plus one real-world responsibility related to {hd['theme']}; set a zero-debt budget and avoid gemstones or expensive purchases unless independently desired.",
                f"{planet} H{house} de-escalation protocol: if several remedies are suggested, keep only the single most relevant conduct/service action for 14 days, then decide whether a 43-day continuation is useful.",
            ]
            for i,action in enumerate(acts,1):
                rows.append({
                    'id':f'V6{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':house,
                    'category':_cat(action),'concerns':concerns,'title':f'{planet} in House {house} — V6 protocol {i}',
                    'action':action,'timing':pd['day'],'duration':'14-day check then up to 43-day review',
                    'source_class':'V6 software planning protocol — not a classical verbatim remedy','safety':'low-risk','priority':2,
                    'note':'Designed to reduce remedy stacking and keep practical verification visible.',
                    'remedy_group':'v6_verification','intensity':'gentle'
                }); rid += 1
    # 8 per house = 96; total 420
    for house, hd in HOUSE_DATA.items():
        house_acts=[
            f"House {house} practical reset: clear one overdue task directly connected with {hd['theme']} before adding a symbolic remedy.",
            f"House {house} record check: document one promise, payment, maintenance item or boundary connected with {hd['theme']} and close the oldest unresolved item.",
            f"House {house} service option: choose one modest act of help relevant to {hd['theme']} without publicising it or expecting a guaranteed return.",
            f"House {house} environment option: clean, repair or responsibly declutter one physical area associated with {hd['theme']} instead of dumping ritual materials outdoors.",
            f"House {house} communication option: replace one repeated reactive sentence or behaviour linked with {hd['theme']} with a specific respectful alternative for 43 days.",
            f"House {house} budget option: if a donation/remedy involves money, set a sustainable cap first and never borrow for it.",
            f"House {house} review option: track what changed in routine, communication or responsibility after 14 and 43 days; record no-change honestly.",
            f"House {house} stop-rule: discontinue any practice tied to {hd['theme']} that causes fear, conflict, pollution, animal risk, medical delay, legal risk or financial strain.",
        ]
        for i,action in enumerate(house_acts,1):
            rows.append({
                'id':f'VH{rid:05d}','planet':None,'planet_hi':'','house':house,
                'category':_cat(action),'concerns':[k for k,v in CONCERN_MAP.items() if house in v['houses']],
                'title':f'House {house} V6 safe protocol {i}','action':action,'timing':'Any suitable day',
                'duration':'14/43-day practical review','source_class':'V6 house-level safe planning protocol','safety':'low-risk','priority':1,
                'note':'Software planning layer; not a claim of classical Lal Kitab authorship.',
                'remedy_group':'v6_house_protocol','intensity':'gentle'
            }); rid += 1
    return rows


V11_PLANET_SOURCE_URLS = {
    "Sun":"https://www.astroscience.com/pages/sun-lal-kitab-remedies",
    "Moon":"https://www.astroscience.com/pages/moon-lal-kitab-remedies",
    "Mars":"https://www.astroscience.com/pages/mars-lal-kitab-remedies",
    "Mercury":"https://www.astroscience.com/pages/mercury-lal-kitab-remedies",
    "Jupiter":"https://www.astroscience.com/pages/jupiter-lal-kitab-remedies",
    "Venus":"https://www.astroscience.com/pages/venus-lal-kitab-remedies",
    "Saturn":"https://www.astroscience.com/pages/saturn-lal-kitab-remedies",
    "Rahu":"https://www.astroscience.com/pages/rahu-lal-kitab-remedies",
    "Ketu":"https://www.astroscience.com/pages/ketu-lal-kitab-remedies",
}

V11_OFFICIAL_UNIVERSAL = {
    "Sun":"Use a simple sunrise water offering as a reflective morning routine; keep the vessel reusable and the area clean.",
    "Moon":"Choose a modest donation of a useful white staple item and pair it with practical care for home/caregiver relationships.",
    "Mars":"Choose a modest red-lentil/staple donation or a safe devotional/discipline practice that channels anger into constructive effort.",
    "Mercury":"Choose green-food/staple charity or learning support; keep speech, records and agreements especially clear.",
    "Jupiter":"Choose yellow-staple/education support and show practical respect toward teachers, mentors and ethical commitments.",
    "Venus":"Choose modest white-food/hygiene charity and respectful support for women/girls without turning the remedy into display or luxury spending.",
    "Saturn":"Choose modest dark-staple/work-essential charity and fairness toward workers; use animal-welfare support instead of unsafe feeding.",
    "Rahu":"Choose modest dark/blue useful-item charity or responsible animal-welfare support; avoid risky shortcuts, intoxication-linked or illegal remedies.",
    "Ketu":"Choose modest earth-tone/useful-item charity or responsible dog/animal-welfare support; pair it with decluttering and task closure.",
}

V11_CONCERN_CARDS = [
    ("career","Career / job","Review authority relationships, records, skill-building and one delayed professional responsibility before adding a symbolic remedy."),
    ("business","Business","Review contracts, cash-flow discipline, partner communication and customer commitments; choose one low-cost supporting upay only."),
    ("money","Money / wealth","Use a spending-and-savings audit plus modest charity within budget; never borrow for a remedy or promise guaranteed returns."),
    ("relationship","Marriage / relationship","Prioritize respectful speech, consent, boundaries and repair of one recurring conflict pattern before ritual stacking."),
    ("family","Family","Support elders/caregivers where safe, keep shared responsibilities clear, and reduce blame-based interpretations of astrology."),
    ("education","Education","Support study discipline, books/stationery or mentoring; track actual learning effort separately from astrological interpretation."),
    ("property","Property / vehicle","Check documents, maintenance, dues and disputes carefully; do not make property decisions solely from a symbolic score."),
    ("foreign_travel","Foreign / travel","Verify visas, documents, budgets and logistics; use astrology only as a reflective timing layer, not a substitute for requirements."),
    ("leadership","Leadership","Reduce ego-driven communication, complete one responsibility first, and seek feedback from a trusted mentor."),
    ("creativity","Creativity","Create consistently, finish one pending work and avoid expensive symbolic purchases as a substitute for practice."),
    ("network","Network / gains","Keep promises realistic, avoid opportunistic relationships and strengthen one long-term professional connection through useful service."),
    ("discipline","Discipline / routine","Choose one sustainable 43-day habit with a measurable completion target; avoid extreme fasting or self-punishment."),
    ("reputation","Reputation","Use truthful communication, documented commitments and timely corrections instead of image-management rituals."),
    ("inner_growth","Inner growth","Use reflection, prayer/journaling or quiet service; avoid fear-based interpretations and deterministic claims."),
]


def build_v11_gdvashist_extensions(start_no: int=1) -> List[Dict]:
    """Exactly 900 V11 source-aware records.

    864 = 9 planets × 12 houses × 8 original, source-guided protocol cards.
    36 = 9 official universal source cards + 9 house-first source audit cards +
         14 concern cards + 4 source/safety study cards.

    These are NOT copied from Gurudev GD Vashist books, paid reports, or video
    transcripts. They are independently paraphrased/safety-normalized planning
    cards linked to public Astroscience/GD Vashist sources.
    """
    rows: List[Dict] = []
    rid=start_no
    for planet,pd in PLANET_DATA.items():
        src=V11_PLANET_SOURCE_URLS[planet]
        for house,hd in HOUSE_DATA.items():
            concerns=[k for k,v in CONCERN_MAP.items() if planet in v['planets'] or house in v['houses']]
            item=pd['items'][(house-1)%len(pd['items'])]
            rel=pd['themes'][(house+1)%len(pd['themes'])]
            acts=[
                ("source_service", f"{planet} H{house} source-guided seva: choose one modest useful donation linked with {item} or an equivalent staple, within budget, then pair it with one real responsibility connected with {hd['theme']}."),
                ("source_conduct", f"{planet} H{house} conduct correction: for 43 days reduce one repeated behaviour that disturbs {hd['theme']} and replace it with a measurable respectful action."),
                ("source_relationship", f"{planet} H{house} relationship upay: improve one connection linked with {rel} through truthful speech, boundaries and one practical act of support; do not use astrology to blame the other person."),
                ("source_household", f"{planet} H{house} home/workplace audit: clean, repair or organize one area symbolically tied to {hd['theme']}; keep it maintained rather than repeating disposal rituals."),
                ("source_weekly", f"On {pd['day']}, review {planet} H{house}: check conduct, spending, promises and service connected with {hd['theme']}, and complete the oldest pending item before adding another remedy."),
                ("source_avoid", f"{planet} H{house} avoid-list: avoid shortcuts, harsh or manipulative speech, fear-driven spending and unnecessary conflict around {hd['theme']}; use the linked source page for context before combining traditions."),
                ("source_verify", f"{planet} H{house} verification protocol: select one upay only, note why it was chosen, track routine/communication outcomes at 14 and 43 days, and record 'no change' honestly when appropriate."),
                ("source_safe_alt", f"{planet} H{house} safe-alternative card: if a traditional version involves flowing-water disposal, unsafe animal feeding, smoke/fire or costly material purchase, substitute lawful charity, animal-welfare support, cleaning/repair or a reusable symbolic act."),
            ]
            for i,(grp,action) in enumerate(acts,1):
                rows.append({
                    'id':f'GV{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':house,
                    'category':_cat(action),'concerns':concerns,'title':f'{planet} H{house} — GD Vashist source-aware #{i}',
                    'action':action,'timing':pd['day'],'duration':'14-day check / up to 43-day observation',
                    'source_class':'GD Vashist/Astroscience public-source inspired — paraphrased, not official prescription',
                    'source_name':'Astroscience — public planet/house remedy page','source_url':src,
                    'source_kind':'official_public_page','safety':'low-risk','priority':3,
                    'note':'Independent software normalization. Read whole-chart context; this is not an official Astroscience/Vashist Jyotish output.',
                    'remedy_group':grp,'intensity':'gentle'
                });rid+=1

    # 9 public universal source cards from the official remedies hub.
    hub='https://www.astroscience.com/pages/lal-kitab-remedies'
    for planet,action in V11_OFFICIAL_UNIVERSAL.items():
        pd=PLANET_DATA[planet]
        rows.append({
            'id':f'GU{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':None,'category':_cat(action),'concerns':[],
            'title':f'{planet} — Astroscience public remedy hub summary','action':action,'timing':pd['day'],
            'duration':'Optional / chart-context review','source_class':'Astroscience public remedy hub — paraphrased + safety-normalized',
            'source_name':'Astroscience Lal Kitab Remedies','source_url':hub,'source_kind':'official_public_page','safety':'low-risk','priority':4,
            'note':'Short public-source summary, not a replacement for personalized chart analysis.','remedy_group':'gdv_public_universal','intensity':'gentle'
        });rid+=1

    # 9 house-first/Vashist-principle audit cards.
    principle='https://www.astroscience.com/blogs/astro-blog/lal-kitab-astrology-remedies-foundational-principles'
    for planet,pd in PLANET_DATA.items():
        rows.append({
            'id':f'GP{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':None,'category':'learning','concerns':[],
            'title':f'{planet} — house-first Vashist source audit',
            'action':f"Before prescribing a {planet} remedy, review its Lal Kitab house placement, the ascendant context, same-house relationships and the affected life theme; then keep only the smallest relevant protocol.",
            'timing':'Before remedy selection','duration':'One chart review','source_class':'Vashist Jyotish public-principle inspired research protocol',
            'source_name':'Astroscience foundational-principles article','source_url':principle,'source_kind':'official_public_page','safety':'low-risk','priority':4,
            'note':'Independent implementation; proprietary Vashist rules are not reproduced.','remedy_group':'gdv_house_first','intensity':'gentle'
        });rid+=1

    # 14 concern cards.
    for concern,label,action in V11_CONCERN_CARDS:
        rows.append({
            'id':f'GC{rid:05d}','planet':None,'planet_hi':'','house':None,'category':_cat(action),'concerns':[concern],
            'title':f'{label} — V11 source-aware upay protocol','action':action,'timing':'Context dependent','duration':'14/43-day review',
            'source_class':'V11 GD Vashist/Astroscience category-inspired planning protocol','source_name':'Astroscience public category/service descriptions',
            'source_url':'https://www.astroscience.com/pages/get-solutions-to-all-your-life-problems','source_kind':'official_public_page','safety':'low-risk','priority':3,
            'note':'Category workflow inspired by public descriptions; not a paid/category-file reproduction.','remedy_group':'gdv_category','intensity':'gentle'
        });rid+=1

    # 4 source/safety study cards -> grand total exactly 900.
    study=[
        ('Official source check','Open the linked official Astroscience/GD Vashist source before treating an unusual remedy as authentic; keep the source URL and date in the client record.'),
        ('YouTube context check','For a GD Vashist YouTube remedy, store only a short paraphrased takeaway plus the video URL; do not rely on a clipped quote without the chart/context discussed in the full video.'),
        ('No transcript cloning','Do not bulk-copy proprietary books, paid reports or full video transcripts into the remedy vault; keep source metadata and independently written summaries instead.'),
        ('Safety override','If a sourced remedy conflicts with medical, legal, environmental, animal-welfare, fire or financial safety, the software safety rule overrides the ritual implementation and proposes a low-risk symbolic/service alternative.'),
    ]
    for title,action in study:
        rows.append({
            'id':f'GS{rid:05d}','planet':None,'planet_hi':'','house':None,'category':'learning','concerns':[],
            'title':title,'action':action,'timing':'Always','duration':'Ongoing','source_class':'V11 source-governance protocol',
            'source_name':'Official Astroscience site + Gurudev GD Vashist official YouTube channel','source_url':'https://youtube.com/@gurudevgdvashist',
            'source_kind':'source_governance','safety':'low-risk','priority':5,'note':'Protects attribution, context and safety.','remedy_group':'gdv_source_governance','intensity':'gentle'
        });rid+=1
    assert len(rows)==900, len(rows)
    return rows



# V12 — Shri Sumitacharya public-source-aware extension.
# Public pages are used only as source metadata / methodology themes. The
# actions below are independently written, safety-normalized cards and are not
# copied from paid reports, consultations, books, or video transcripts.
V12_SUMIT_BASE = "https://sumitacharya.in"
V12_SUMIT_CHANNEL = "https://www.youtube.com/@Sumitacharyajimaharaj"
V12_SUMIT_SOURCES = {
    "report": f"{V12_SUMIT_BASE}/unlock-your-destiny-comprehensive-100-page-personalized-kundali-report-by-shri-sumitacharya-ji-maharaj/",
    "marriage": f"{V12_SUMIT_BASE}/product/kundali-milan-marriage-sumitacharya-best-astrologer/",
    "business": f"{V12_SUMIT_BASE}/product/grow-business-with-astrology-strategic-help-for-offices-shops/",
    "grah_shanti": f"{V12_SUMIT_BASE}/product/grah-dosh-shanti-puja-shri-sumitacharya-ji-maharaj-hawan/",
    "pooja": f"{V12_SUMIT_BASE}/product-category/pooja/",
    "services": f"{V12_SUMIT_BASE}/product-category/astrology-services/",
    "trijata": f"{V12_SUMIT_BASE}/trijata-dosh-hawan-nivaran/",
    "terms": f"{V12_SUMIT_BASE}/terms-and-conditions/",
    "youtube": V12_SUMIT_CHANNEL,
}

V12_SUMIT_GENERAL = [
    ("Chart-first remedy selection", "Before choosing any ritual, gemstone or mantra, review the full birth chart, current timing layer and the actual life problem; keep one low-risk remedy at a time and document why it was chosen.", "report"),
    ("Five-year planning review", "Use the next-five-year forecast as a planning calendar: mark supportive, mixed and caution periods, then attach real-world milestones and verification checks instead of treating dates as guarantees.", "report"),
    ("Career verification", "For career questions, combine D1/D10, current dasha, 10th-house themes and actual skills/work history; make a practical 90-day skill and application plan alongside any symbolic upay.", "report"),
    ("Business verification", "For business questions, review timing, partner fit, cash-flow, agreements and workplace layout separately; astrology must not replace accounting, legal review or market research.", "business"),
    ("Finance safety", "For money questions, use astrology only for reflective planning; keep emergency savings, debt control and regulated professional advice separate from symbolic remedies or timing scores.", "report"),
    ("Marriage compatibility", "For relationship questions, use both charts, Ashtakoot/Manglik research, D9 and communication evidence; never use a single dosha label to pressure or reject a partner.", "marriage"),
    ("Family/children care", "For family or children themes, use supportive communication, routine and qualified professional care when needed; astrology must not diagnose fertility, development or health.", "report"),
    ("Wellbeing boundary", "Wellbeing indicators are cultural/reflective only. Do not predict disease, lifespan or replace doctors, medicines, therapy or emergency care with a ritual.", "terms"),
    ("Grah Shanti review", "If a Grah Shanti or havan is considered, first identify the exact chart reason, record the source and use trained practitioners for fire rituals; do not automate costly ritual purchases.", "grah_shanti"),
    ("Gemstone caution", "Treat gemstone recommendations as optional traditional references: verify chart context, budget and authenticity, and never borrow money or expect guaranteed financial/health results.", "report"),
    ("Mantra routine", "If mantra practice is chosen, keep it voluntary, sustainable and non-punitive; pair it with one measurable conduct or service action connected to the chart theme.", "pooja"),
    ("Charity within means", "Use modest, useful charity within budget as a low-risk symbolic practice; do not create waste, debt, public display pressure or dependency as part of a remedy.", "pooja"),
    ("Muhurta reality check", "Use Muhurta as a secondary timing lens after legal, logistical, medical and financial constraints are satisfied; keep an alternate practical date ready.", "business"),
    ("Vastu scope boundary", "For business Vastu, use the software as a checklist only until actual entrance, directions and floor plan are supplied; do not suggest structural changes without site data and qualified review.", "business"),
    ("Source verification", "Open the official source link before treating a social-media remedy as authentic. Store only a concise paraphrase, the URL and the date reviewed.", "youtube"),
]


def build_v12_sumitacharya_extensions(start_no: int=1) -> List[Dict]:
    """Exactly 1,200 V12 Sumitacharya public-source-aware records.

    1080 = 9 planets × 12 houses × 10 independently-written source-guided cards.
    120 = source/method/safety/category cards.
    """
    rows: List[Dict] = []
    rid=start_no
    # 1,080 planet-house cards.
    for planet,pd in PLANET_DATA.items():
        for house,hd in HOUSE_DATA.items():
            concerns=[k for k,v in CONCERN_MAP.items() if planet in v['planets'] or house in v['houses']]
            source = V12_SUMIT_SOURCES['report']
            if house==7 or planet in {'Venus','Jupiter'}: source=V12_SUMIT_SOURCES['marriage']
            elif house in {2,10,11} or planet in {'Mercury','Saturn'}: source=V12_SUMIT_SOURCES['business']
            acts=[
                ("sumit_chart_first", f"{planet} H{house} chart-first review: connect this placement with {hd['theme']}, current dasha/transit and the client’s actual question before selecting any remedy."),
                ("sumit_action", f"{planet} H{house} practical upay: choose one measurable 14–43 day conduct, service, learning, repair or documentation action linked with {hd['theme']}; track completion before changing remedies."),
                ("sumit_traditional", f"{planet} H{house} traditional-reference card: if mantra, pooja, charity, yantra or gemstone is considered, treat it as optional cultural practice, verify source/context and avoid expensive or fear-driven prescriptions."),
                ("sumit_prediction", f"{planet} H{house} prediction check: compare D1 plus relevant divisional chart, 4-level dasha and annual/transit evidence; describe supportive/mixed/caution periods rather than guaranteed events in {hd['theme']}."),
                ("sumit_safety", f"{planet} H{house} safety override: no ritual may replace medical/legal/financial advice, require dangerous fasting/fire, pollution, animal harm, secret fees or borrowing; use a low-risk symbolic/service alternative."),
                ("sumit_dosha_context", f"{planet} H{house} dosha-context check: do not name a dosha from this placement alone; check house lord, conjunctions, dignity, divisional support and cancellation/variant rules before creating an upay plan."),
                ("sumit_muhurta", f"{planet} H{house} timing bridge: if an action concerns {hd['theme']}, compare practical readiness with Dasha/annual/transit/Muhurta layers; a favourable date never overrides legal, safety or logistical requirements."),
                ("sumit_varga", f"{planet} H{house} divisional cross-check: compare D1 with the most relevant Varga (for example D9 relationship, D10 career, D12 family) and mark disagreement as uncertainty rather than forcing one conclusion."),
                ("sumit_consult", f"{planet} H{house} consultation question: ask for one verified past event and one current real-world concern connected with {hd['theme']}; use the answer to challenge or refine the software interpretation."),
                ("sumit_source_verify", f"{planet} H{house} source verification: keep the public source URL visible, store only an original short summary, and do not represent this software card as a personal prescription from Shri Sumitacharya Ji."),
            ]
            for i,(grp,action) in enumerate(acts,1):
                rows.append({
                    'id':f'SA{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':house,
                    'category':_cat(action),'concerns':concerns,'title':f'{planet} H{house} — Sumitacharya source-aware #{i}',
                    'action':action,'timing':'Chart/context dependent','duration':'14-day check / up to 43-day observation',
                    'source_class':'Shri Sumitacharya public-site inspired — independent paraphrase, not official prescription',
                    'source_name':'Sumitacharya.in public astrology/report/service pages','source_url':source,
                    'source_kind':'sumitacharya_public_page','safety':'low-risk','priority':3,
                    'note':'Independent software synthesis. No paid report, consultation content, copyrighted article text or full video transcript is copied.',
                    'remedy_group':grp,'intensity':'gentle'
                }); rid+=1

    # 15 reusable methodology/category cards × 8 variants = 120.
    for base_idx,(title,action,src_key) in enumerate(V12_SUMIT_GENERAL,1):
        for variant in range(1,9):
            extra = [
                "Record a baseline and review after 14 days.",
                "Keep the source URL visible in the client report.",
                "Ask what changed in real life before attributing change to a remedy.",
                "Use a second-opinion / skeptic pass when the interpretation is strong or fear-inducing.",
                "Cross-check the relevant divisional chart before escalating the interpretation.",
                "Compare the current four-level Dasha chain and annual/transit evidence before choosing timing language.",
                "Prefer a no-cost or low-cost practical action before considering a material purchase.",
                "Document disagreement between source traditions instead of silently merging them.",
            ][variant-1]
            rows.append({
                'id':f'SG{rid:05d}','planet':None,'planet_hi':'','house':None,
                'category':_cat(action),'concerns':[], 'title':f'{title} — protocol {variant}',
                'action':action+' '+extra,'timing':'As relevant','duration':'Review cycle',
                'source_class':'Sumitacharya public-service methodology inspired — independently written',
                'source_name':'Sumitacharya.in / official public channel','source_url':V12_SUMIT_SOURCES[src_key],
                'source_kind':'sumitacharya_public_page','safety':'low-risk','priority':4,
                'note':'Source-linked planning card only; not an endorsement or official Sumitacharya output.',
                'remedy_group':'sumit_method','intensity':'gentle'
            }); rid+=1
    assert len(rows)==1200, len(rows)
    return rows


def build_v18_personalized_extensions(start_no: int=1) -> List[Dict]:
    """2,400 V18 software-derived personalization/remedy-planning cards.

    These are deliberately NOT labelled as classical Lal Kitab or practitioner prescriptions.
    2,160 = 9 planets × 12 houses × 20 practical protocol variants.
    240 = 10 concerns × 24 low-burden planning variants.
    """
    rows: List[Dict] = []
    rid=start_no
    protocol_specs=[
        ('one_remedy', 'Choose only one low-burden action for this placement and complete it consistently before adding another.'),
        ('no_cost', 'Use a no-cost conduct correction linked to the house theme: truthful speech, punctuality, cleanliness, boundary repair or completing a pending duty.'),
        ('five_minute', 'Create a five-minute daily review for the house theme: note one action completed, one avoidable mistake and one practical next step.'),
        ('weekly_service', 'Choose one weekly service action connected with the planet theme, within normal safety and financial limits.'),
        ('charity_budget', 'If charity is chosen, set a small fixed budget first and never borrow, overspend or use fear-based payments as a remedy.'),
        ('relationship_repair', 'Where relevant, repair one relationship through respectful communication, consent, boundaries and a concrete helpful action.'),
        ('records', 'Keep one record category accurate for 43 days: bills, promises, documents, appointments, study notes or maintenance logs.'),
        ('declutter', 'Remove one small source of clutter or neglect each week and dispose, recycle or donate responsibly.'),
        ('maintenance', 'Repair one safe, ordinary household/workplace issue instead of repeating symbolic disposal rituals.'),
        ('learning', 'Study one reliable source or skill connected with the planet/house theme for 10 minutes twice a week.'),
        ('mentor', 'Seek or offer ethical mentoring related to this life area without creating dependency or blind obedience.'),
        ('digital', 'Reduce one digital distraction, rumor loop or impulsive online habit that interferes with this house theme.'),
        ('spending', 'Track discretionary spending connected with this life area and pause 24 hours before non-essential purchases.'),
        ('communication', 'Use a 3-step communication rule: verify facts, reduce harsh language, and write down important agreements.'),
        ('morning', 'Use a simple morning intention tied to responsibility in this house; no special material purchase is required.'),
        ('evening', 'Use an evening check-in to close pending tasks and avoid carrying avoidable disorder into the next day.'),
        ('family', 'Where family is relevant, choose one practical support action while respecting autonomy and healthy boundaries.'),
        ('environment', 'Prefer reusable, non-polluting symbolic actions; never dump ritual items, food, oils, plastics or metals into natural water.'),
        ('tracker', 'Track the selected action at day 7, 14, 21 and 43, recording completion and real-life observations without claiming causation.'),
        ('stop_rule', 'Stop or replace the practice if it causes fear, financial strain, conflict, animal risk, fire/smoke risk, health risk or legal/environmental harm.'),
    ]
    for planet,pd in PLANET_DATA.items():
        for house,hd in HOUSE_DATA.items():
            concerns=[k for k,v in CONCERN_MAP.items() if planet in v['planets'] or house in v['houses']]
            for i,(grp,base) in enumerate(protocol_specs,1):
                action=f"{planet} H{house} V18 personalized protocol: {base} Apply it to {hd['theme']} and review the current Dasha/transit context before escalating any traditional remedy."
                rows.append({
                    'id':f'V18P{rid:05d}','planet':planet,'planet_hi':pd['hi'],'house':house,
                    'category':_cat(action),'concerns':concerns,'title':f'{planet} H{house} — V18 Personal Protocol #{i}',
                    'action':action,'timing':'Flexible / chart-context dependent','duration':'7–43 day review cycle',
                    'source_class':'V18 software-derived personalization protocol — not a classical or practitioner prescription',
                    'source_name':'Lal Kitab AI PRO V18 safety/personalization engine','source_url':'','source_kind':'software_derived_v18',
                    'safety':'low-risk','priority':2,'note':'Designed to reduce remedy overload and improve traceability. No claim of guaranteed external effects.',
                    'remedy_group':grp,'intensity':'gentle'
                }); rid+=1
    # 240 concern-level planning cards
    concern_variants=[
        'Define one measurable real-world goal before choosing any remedy.',
        'List the practical causes you can control and address those first.',
        'Choose the simplest no-cost action that does not conflict with existing responsibilities.',
        'Use only one primary remedy for 14 days before deciding whether to add support.',
        'Record a baseline: what is happening now, frequency, impact and current practical actions.',
        'Set a reminder for day 7 and day 14 to review completion rather than expecting instant results.',
        'At day 21, note what changed and what did not change without attributing every coincidence to astrology.',
        'At day 43, close, continue or replace the protocol based on burden, safety and usefulness.',
        'Check whether a recommended donation is affordable and genuinely useful to the recipient.',
        'Avoid secret fees, urgency pressure, guaranteed outcomes or borrowing money for remedies.',
        'If a ritual requires fire/smoke, use trained supervision and ordinary fire-safety rules or choose a non-fire alternative.',
        'If animals are involved, use reputable animal-welfare support rather than unsafe feeding.',
        'If water is involved, keep the practice pollution-free and use reusable symbolic alternatives.',
        'Never ingest metals, ash, unknown herbs, oils or ritual mixtures as an astrology remedy.',
        'Keep prescribed medical treatment and qualified professional advice completely separate from astrology remedies.',
        'Keep legal, tax, financial and safety obligations primary even during favourable astrology windows.',
        'If two source traditions disagree, display both and choose a low-risk common denominator or no remedy.',
        'Ask one skeptic question: what ordinary explanation could also account for this problem?',
        'Ask one source question: is this remedy actually sourced, or is it a software-derived planning suggestion?',
        'Ask one burden question: can the person realistically maintain this without stress or family conflict?',
        'Use a one-page remedy summary with action, reason, duration, stop rule and review date.',
        'Do not stack multiple remedies for the same planet merely because more options are available.',
        'Prefer repair, discipline, service, learning and ethical conduct before material symbolism.',
        'Archive the outcome as Hit/Partial/Miss only as client feedback, not scientific proof of astrology.'
    ]
    for concern,cfg in CONCERN_MAP.items():
        for i,base in enumerate(concern_variants,1):
            rows.append({
                'id':f'V18C{rid:05d}','planet':None,'planet_hi':'','house':None,'category':_cat(base),
                'concerns':[concern],'title':f"{cfg['label']} — V18 low-burden protocol #{i}",
                'action':base,'timing':'As relevant','duration':'Review cycle','source_class':'V18 software-derived safety/personalization protocol',
                'source_name':'Lal Kitab AI PRO V18','source_url':'','source_kind':'software_derived_v18','safety':'low-risk','priority':2,
                'note':'Planning/safety card; not a classical Lal Kitab remedy or practitioner prescription.','remedy_group':'v18_concern_protocol','intensity':'gentle'
            }); rid+=1
    assert len(rows)==2400, len(rows)
    return rows

CATALOG = build_catalog()
CATALOG.extend(build_ultra_extensions(len(CATALOG)+1))
CATALOG.extend(build_v6_extensions(len(CATALOG)+1))
CATALOG.extend(build_v11_gdvashist_extensions(len(CATALOG)+1))
CATALOG.extend(build_v12_sumitacharya_extensions(len(CATALOG)+1))
CATALOG.extend(build_v18_personalized_extensions(len(CATALOG)+1))
CATALOG_BY_ID = {x["id"]:x for x in CATALOG}

# Unsafe or environmentally harmful variants are catalogued only as blocked categories,
# without operational instructions that could encourage harm.
BLOCKED_VARIANTS = [
    {"type":"water pollution","rule":"Do not throw coins, plastics, oils, chemicals, cloth or food waste into rivers/lakes.","alternative":"Donate the item or use a clean symbolic water offering at home and dispose responsibly."},
    {"type":"animal harm","rule":"Do not feed animals chocolate, sweets, excessive salt/spices or species-inappropriate foods.","alternative":"Support a reputable animal-welfare group or use veterinarian-approved feed."},
    {"type":"fire/smoke hazard","rule":"Do not create unsafe indoor smoke, unattended flames or hazardous burning rituals.","alternative":"Use a safe lamp only where permitted, or replace it with a non-fire symbolic routine."},
    {"type":"ingestion risk","rule":"Do not ingest metals, ash, unknown herbs, chemicals, oils or ritual mixtures as an astrological remedy.","alternative":"Keep symbolic objects external; medical treatment belongs with qualified clinicians."},
    {"type":"medical replacement","rule":"No remedy may replace prescribed medicines, emergency care, therapy or medical evaluation.","alternative":"Use cultural practices only as optional personal rituals alongside appropriate care."},
    {"type":"financial exploitation","rule":"No remedy requires expensive gemstones, large payments, loans, secret fees or guaranteed-return purchases.","alternative":"Prefer low-cost service, discipline and charity within your means."},
    {"type":"self-harm / deprivation","rule":"No extreme fasting, sleep deprivation, self-punishment or deliberate exposure to unsafe conditions.","alternative":"Use ordinary, sustainable habits."},
    {"type":"illegal activity","rule":"No trespass, dumping, wildlife interference, theft, bribery or other unlawful conduct as a remedy.","alternative":"Choose a lawful symbolic or charitable substitute."},
]


def catalog_meta() -> Dict:
    return {
        "total":len(CATALOG),
        "planet_house_combinations":108,
        "planets":PLANETS,
        "houses":list(range(1,13)),
        "categories":CATEGORY_LABELS,
        "concerns":{k:v["label"] for k,v in CONCERN_MAP.items()},
        "blocked_safety_variants":BLOCKED_VARIANTS,
        "method_note":"V18 catalog contains 7,200 records: the V12 4,800-record multi-source vault plus 2,400 clearly-labelled software-derived personalization/safety protocols. Practitioner source cards remain independently paraphrased/safety-normalized, not official prescriptions or proprietary-rule copies.",
        "planner":"V18 Remedy Engine 7.0 keeps a large searchable vault but defaults to 1–3 low-burden core actions, source visibility, conflict checks, stop rules and 7/14/21/43-day tracking.",
        "source_boundary":"Traditional source rules, safe modern substitutions and software planning protocols are labelled separately."
    }


def search_catalog(q: str="", planet: Optional[str]=None, house: Optional[int]=None,
                   category: Optional[str]=None, concern: Optional[str]=None,
                   limit: int=250, source_kind: Optional[str]=None) -> List[Dict]:
    q=(q or "").strip().lower();out=[]
    for r in CATALOG:
        if planet and r.get("planet") != planet: continue
        if house and r.get("house") != house: continue
        if category and r.get("category") != category: continue
        if concern and concern not in r.get("concerns",[]): continue
        if source_kind and r.get("source_kind") != source_kind: continue
        if q:
            blob=" ".join(str(r.get(k,"")) for k in ["planet","planet_hi","house","category","title","action","note","source_class","source_name","source_url","source_kind"]).lower()
            if q not in blob: continue
        out.append(r)
        if len(out)>=max(1,min(limit,2000)): break
    return out


def recommended_for_chart(chart: Dict, concern: Optional[str]=None, limit: int=18) -> List[Dict]:
    placements=chart.get("placements",[])
    scored=[]
    for p in placements:
        base=100-int(p.get("score",50))
        if "Neecha reference" in p.get("status",[]): base+=35
        if "Soya candidate" in p.get("status",[]): base+=20
        for r in CATALOG:
            if r.get("planet") != p.get("planet") or r.get("house") != p.get("house"): continue
            if concern and concern not in r.get("concerns",[]): continue
            scored.append((base+r.get("priority",1),r))
    # Deduplicate by action, preserve strongest chart relevance
    seen=set();out=[]
    for _,r in sorted(scored,key=lambda x:x[0],reverse=True):
        if r["action"] in seen: continue
        seen.add(r["action"]);out.append(r)
        if len(out)>=limit: break
    return out



def vashist_source_recommended(chart: Dict, concern: Optional[str]=None, limit: int=36) -> List[Dict]:
    """Rank only V11 source-linked Astroscience/GD Vashist public-source cards."""
    placements=chart.get('placements',[]) or []
    active_house=(chart.get('timing',{}).get('house_cycle_36',{}) or {}).get('house')
    rows=[]
    for p in placements:
        weakness=max(0,72-float(p.get('score',50)))
        if 'Neecha reference' in (p.get('status') or []): weakness+=20
        if 'Soya candidate' in (p.get('status') or []): weakness+=12
        if active_house==p.get('house'): weakness+=8
        for r in CATALOG:
            if r.get('source_kind')!='official_public_page': continue
            if r.get('planet') not in (None,p.get('planet')): continue
            if r.get('house') not in (None,p.get('house')): continue
            if concern and r.get('concerns') and concern not in r.get('concerns',[]): continue
            score=weakness+float(r.get('priority',1))*4
            if r.get('planet')==p.get('planet'): score+=8
            if r.get('house')==p.get('house'): score+=10
            if concern and concern in r.get('concerns',[]): score+=12
            rr=dict(r);rr['relevance_score']=round(min(100,score),1)
            rr['why_selected']=f"Source-linked card for {p.get('planet')} H{p.get('house')} (chart score {p.get('score',50)}/100)."
            rows.append(rr)
    out=[];seen=set()
    for r in sorted(rows,key=lambda x:x['relevance_score'],reverse=True):
        if r['action'] in seen: continue
        seen.add(r['action']);out.append(r)
        if len(out)>=limit: break
    return out



def sumitacharya_source_recommended(chart: Dict, concern: Optional[str]=None, limit: int=36) -> List[Dict]:
    """Rank only V12 Shri Sumitacharya public-source-aware cards."""
    placements=chart.get('placements',[]) or []
    active_house=(chart.get('timing',{}).get('house_cycle_36',{}) or {}).get('house')
    rows=[]
    for p in placements:
        weakness=max(0,72-float(p.get('score',50)))
        if 'Neecha reference' in (p.get('status') or []): weakness+=20
        if 'Soya candidate' in (p.get('status') or []): weakness+=10
        if active_house==p.get('house'): weakness+=8
        for r in CATALOG:
            if r.get('source_kind')!='sumitacharya_public_page': continue
            if r.get('planet') not in (None,p.get('planet')): continue
            if r.get('house') not in (None,p.get('house')): continue
            if concern and r.get('concerns') and concern not in r.get('concerns',[]): continue
            score=weakness+float(r.get('priority',1))*4
            if r.get('planet')==p.get('planet'): score+=8
            if r.get('house')==p.get('house'): score+=10
            if concern and concern in r.get('concerns',[]): score+=12
            rr=dict(r);rr['relevance_score']=round(min(100,score),1)
            rr['why_selected']=f"Sumitacharya-source card mapped to {p.get('planet')} H{p.get('house')} (chart score {p.get('score',50)}/100)."
            rows.append(rr)
    out=[];seen=set()
    for r in sorted(rows,key=lambda x:x['relevance_score'],reverse=True):
        sig=(r.get('planet'),r.get('house'),r.get('remedy_group'),r.get('action'))
        if sig in seen: continue
        seen.add(sig);out.append(r)
        if len(out)>=limit: break
    return out

def remedy_priority_plan(chart: Dict, concern: Optional[str]=None, primary_limit: int=3) -> Dict:
    """Build a small, diverse remedy protocol with conflict/overload warnings."""
    placements=chart.get('placements',[]) or []
    house_states={h.get('house'):h for h in chart.get('house_states',[]) or []}
    active_house=(chart.get('timing',{}).get('house_cycle_36',{}) or {}).get('house')
    candidates=[]
    for p in placements:
        weakness=max(0,70-float(p.get('score',50)))
        if 'Neecha reference' in (p.get('status') or []): weakness+=24
        if 'Soya candidate' in (p.get('status') or []): weakness+=16
        if active_house==p.get('house'): weakness+=8
        hs=house_states.get(p.get('house'),{})
        if 'sleep' in str(hs.get('state','')).lower() or 'soya' in str(hs.get('state','')).lower(): weakness+=7
        for r in CATALOG:
            if r.get('planet')!=p.get('planet'): continue
            if r.get('house') not in (None,p.get('house')): continue
            if concern and concern not in r.get('concerns',[]) and r.get('concerns'): continue
            relevance=weakness + 4*float(r.get('priority',1))
            if r.get('house')==p.get('house'): relevance+=12
            if concern and concern in r.get('concerns',[]): relevance+=14
            if r.get('remedy_group')=='context_protocol': relevance+=3
            candidates.append((relevance,r,p))
    candidates.sort(key=lambda x:x[0],reverse=True)

    def materialize(score,r,p):
        row=dict(r);row['relevance_score']=round(min(100,score),1)
        row['why_selected']=f"{p.get('planet')} H{p.get('house')} chart score {p.get('score',50)}/100" + ("; active 36-year house" if active_house==p.get('house') else '')
        return row

    # Core plan: one planet per core remedy and category diversity where possible.
    primary=[];seen_actions=set();used_planets=set();used_categories=set()
    for score,r,p in candidates:
        if r['action'] in seen_actions or r.get('planet') in used_planets: continue
        if r.get('category') in used_categories and len(used_categories)>=2: continue
        primary.append(materialize(score,r,p));seen_actions.add(r['action']);used_planets.add(r.get('planet'));used_categories.add(r.get('category'))
        if len(primary)>=primary_limit: break
    # If the chart has too few unique candidates after concern filtering, relax category but not action.
    if len(primary)<primary_limit:
        for score,r,p in candidates:
            if r['action'] in seen_actions or r.get('planet') in used_planets: continue
            primary.append(materialize(score,r,p));seen_actions.add(r['action']);used_planets.add(r.get('planet'))
            if len(primary)>=primary_limit: break

    secondary=[];planet_count={x.get('planet'):1 for x in primary};category_count={x.get('category'):1 for x in primary}
    for score,r,p in candidates:
        if r['action'] in seen_actions: continue
        if planet_count.get(r.get('planet'),0)>=2: continue
        if category_count.get(r.get('category'),0)>=3: continue
        secondary.append(materialize(score,r,p));seen_actions.add(r['action'])
        planet_count[r.get('planet')]=planet_count.get(r.get('planet'),0)+1;category_count[r.get('category')]=category_count.get(r.get('category'),0)+1
        if len(secondary)>=5: break

    conflicts=[]
    for i,a in enumerate(primary):
        for b in primary[i+1:]:
            if a.get('planet')==b.get('planet'):
                conflicts.append({'level':'review','pair':[a['id'],b['id']], 'reason':'Two core remedies target the same planet; use one core action first unless a source-aware astrologer intentionally combines them.'})
            elif a.get('category')==b.get('category'):
                conflicts.append({'level':'review','pair':[a['id'],b['id']], 'reason':f"Both are {a.get('category')} actions; simplify if the protocol becomes burdensome."})
    rules=[
        'Use at most 1–3 core remedies at a time; more remedies are not automatically stronger.',
        'Prefer conduct, responsibility, service and low-cost charity before symbolic material actions.',
        'Do not combine traditions when their source rules conflict; keep the selected Lal Kitab rule profile visible.',
        'Stop or replace any practice that creates pollution, animal risk, fire risk, health risk, legal risk or financial strain.',
        'Review after 43 days and record observable habit/practical changes; do not treat coincidence as proof of causation.'
    ]
    return {'primary':primary,'secondary':secondary,'conflicts':conflicts,'protocol_rules':rules,
            'concern':concern,'catalog_total':len(CATALOG),
            'note':'Priority is a software relevance ranking, not proof that a remedy changes external events.'}
