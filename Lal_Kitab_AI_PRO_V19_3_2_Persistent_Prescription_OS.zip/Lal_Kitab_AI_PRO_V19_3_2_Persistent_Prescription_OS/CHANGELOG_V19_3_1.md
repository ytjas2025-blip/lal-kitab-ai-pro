# V19.3.1 — 10/10 Accuracy + Simplicity Pass

- Preserves all V19.2.9 cumulative features and golden chart calculation guard.
- Adds Simple / Expert navigation modes; Simple Mode exposes only Home, Kundli, 15 Days, Predictions, Upay, Alerts, Saved Kundlis.
- Upay Prescription 3.1 now ranks with existing chart activation plus already-computed Dasha, Transit and Alert planet evidence when present.
- Adds explicit decision: Remedy Selected vs No Remedy Needed.
- Adds selection evidence and source-confidence labels per recommendation.
- Adds user feasibility controls: ₹0 only, low-cost, no donation, home-only, mobility limitation, no river, no animals, no mantra, no temple, no sunrise, no forced family contact.
- Keeps source tiers separate; no modern seva is promoted to an original Lal Kitab rule.
- Conflict Guard still limits visible prescription to one main action plus limited alternatives.
- Safety blocks alcohol gifting, pollution, wildlife products, unsafe fire/ingestion, forced family contact and professional-care substitution.
