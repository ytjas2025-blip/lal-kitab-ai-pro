from __future__ import annotations

"""V8 auxiliary Vedic/AI-OS calculations.

This module adds chart presentation and planning layers requested for the richer
mobile-style kundli experience. Lal Kitab fixed-house calculations remain in
engine.py. Vedic auxiliary layers (Lagna, Navamsha, Panchang, Vimshottari,
transits, etc.) are kept separate and explicitly labelled.

Astrology is a traditional belief system. Scores and timing views here are
interpretive/reference indexes, not objective probabilities or guarantees.
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import math
import swisseph as swe

from engine import calc_planets, CITY_PRESETS, HOUSE_MEANINGS, house_cycle_for_age, PLANETS
from prediction_pro import forecast_year, DOMAIN_RULES

SIGNS = [
    ("Aries", "Mesha"), ("Taurus", "Vrishabha"), ("Gemini", "Mithuna"),
    ("Cancer", "Karka"), ("Leo", "Simha"), ("Virgo", "Kanya"),
    ("Libra", "Tula"), ("Scorpio", "Vrishchika"), ("Sagittarius", "Dhanu"),
    ("Capricorn", "Makara"), ("Aquarius", "Kumbha"), ("Pisces", "Meena"),
]
SIGN_TO_NO = {x[0]: i + 1 for i, x in enumerate(SIGNS)}
PLANET_SHORT = {"Sun":"Su","Moon":"Mo","Mars":"Ma","Mercury":"Me","Jupiter":"Ju","Venus":"Ve","Saturn":"Sa","Rahu":"Ra","Ketu":"Ke"}

NAKSHATRAS = [
    "Ashwini","Bharani","Krittika","Rohini","Mrigashira","Ardra","Punarvasu","Pushya","Ashlesha",
    "Magha","Purva Phalguni","Uttara Phalguni","Hasta","Chitra","Swati","Vishakha","Anuradha","Jyeshtha",
    "Mula","Purva Ashadha","Uttara Ashadha","Shravana","Dhanishta","Shatabhisha","Purva Bhadrapada","Uttara Bhadrapada","Revati",
]
YOGAS = [
    "Vishkambha","Priti","Ayushman","Saubhagya","Shobhana","Atiganda","Sukarma","Dhriti","Shula",
    "Ganda","Vriddhi","Dhruva","Vyaghata","Harshana","Vajra","Siddhi","Vyatipata","Variyana",
    "Parigha","Shiva","Siddha","Sadhya","Shubha","Shukla","Brahma","Indra","Vaidhriti",
]
KARANA_MOVABLE = ["Bava","Balava","Kaulava","Taitila","Garaja","Vanija","Vishti"]


SIGN_LORDS = {1:"Mars",2:"Venus",3:"Mercury",4:"Moon",5:"Sun",6:"Mercury",7:"Venus",8:"Mars",9:"Jupiter",10:"Saturn",11:"Saturn",12:"Jupiter"}

def _same_sign(by: Dict[str, Dict], a: str, b: str) -> bool:
    return bool(by.get(a) and by.get(b) and by[a].get("sign_no") == by[b].get("sign_no"))

def raj_yoga_candidates(planet_rows: List[Dict], asc_sign_no: int) -> List[Dict]:
    """Transparent Vedic auxiliary yoga-candidate scanner.

    This deliberately reports candidates rather than categorical promises. Many
    classical yoga judgements require dignity, strength, aspects, cancellation
    rules and school-specific conventions beyond a simple conjunction check.
    """
    by={x["planet"]:x for x in planet_rows}
    out=[]
    moon_sign=by.get("Moon",{}).get("sign_no")
    jup_sign=by.get("Jupiter",{}).get("sign_no")
    if moon_sign and jup_sign and _whole_sign_house(jup_sign, moon_sign) in {1,4,7,10}:
        out.append({"name":"Gajakesari candidate","status":"Detected","evidence":"Jupiter is in a kendra from the Moon by whole-sign reference.","note":"Strength/aspects and school rules still need review."})
    for a,b,name in [("Sun","Mercury","Budha-Aditya candidate"),("Moon","Mars","Chandra-Mangala candidate"),("Jupiter","Mars","Guru-Mangala candidate")]:
        if _same_sign(by,a,b):
            out.append({"name":name,"status":"Detected","evidence":f"{a} and {b} occupy the same sidereal sign.","note":"Conjunction alone does not establish promised outcomes."})
    # House-lord conjunction candidates using whole-sign Lagna.
    house_lord={}
    for h in range(1,13):
        sign=((asc_sign_no-1+h-1)%12)+1
        house_lord[h]=SIGN_LORDS[sign]
    seen=set()
    for kh in (1,4,7,10):
        for th in (1,5,9):
            a,b=house_lord[kh],house_lord[th]
            if a==b or tuple(sorted((a,b))) in seen: continue
            seen.add(tuple(sorted((a,b))))
            if _same_sign(by,a,b):
                out.append({"name":"Kendra–Trikona lord conjunction candidate","status":"Detected","evidence":f"{a} (H{kh} lord) and {b} (H{th} lord) share a sign.","note":"A research flag only; full Raja Yoga judgement is more nuanced."})
    if not out:
        out.append({"name":"Raja Yoga candidate scan","status":"No simple conjunction candidate","evidence":"No configured high-level conjunction rule triggered.","note":"This does not mean no yoga exists; the scanner is intentionally conservative."})
    return out

def shodashavarga_workspace(charts: Dict[str,List[Dict]]) -> Dict:
    enabled=[
        {"key":"D1","label":"Rashi / Lagna","status":"Calculated","source":"Whole-sign sidereal"},
        {"key":"D9","label":"Navamsha","status":"Calculated","source":"Standard Navamsha mapping"},
        {"key":"D10","label":"Dasamsa","status":"Calculated","source":"Auxiliary divisional mapping"},
        {"key":"D12","label":"Dwadasamsa","status":"Calculated","source":"Auxiliary divisional mapping"},
    ]
    pending=["D2 Hora","D3 Drekkana","D4 Chaturthamsa","D7 Saptamsa","D16 Shodasamsa","D20 Vimsamsa","D24 Chaturvimsamsa","D27 Saptavimsamsa","D30 Trimsamsa","D40 Khavedamsa","D45 Akshavedamsa","D60 Shashtiamsa"]
    return {"calculated":enabled,"source_pack_required":pending,"note":"V8 computes only divisional charts whose formula implementation is explicitly enabled. Remaining Vargas are not fabricated; add a verified rule/formula pack before activation."}

def ghatak_favourable_workspace(panchang: Dict) -> Dict:
    return {
        "birth_anchors":{
            "vara":panchang.get("vara"),
            "nakshatra":(panchang.get("nakshatra") or {}).get("name"),
            "nakshatra_pada":(panchang.get("nakshatra") or {}).get("pada"),
            "tithi":f"{(panchang.get('tithi') or {}).get('paksha','')} {(panchang.get('tithi') or {}).get('name','')}".strip(),
            "moon_sign":panchang.get("moon_sign"),
        },
        "status":"Source-profile workspace",
        "note":"Ghatak/favourable tables vary across traditions. V8 exposes the calculated birth anchors and intentionally waits for a chosen, auditable rule profile before labelling days/signs as favourable or adverse."
    }

DASHA_ORDER = ["Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury"]
DASHA_YEARS = {"Ketu":7,"Venus":20,"Sun":6,"Moon":10,"Mars":7,"Rahu":18,"Jupiter":16,"Saturn":19,"Mercury":17}

# Approximate combustion thresholds, used only as an auxiliary reference flag.
COMBUST_LIMIT = {"Moon":12,"Mars":17,"Mercury":14,"Jupiter":11,"Venus":10,"Saturn":15}
VEDIC_EXALT = {"Sun":1,"Moon":2,"Mars":10,"Mercury":6,"Jupiter":4,"Venus":12,"Saturn":7}
VEDIC_DEBIL = {p: ((s + 5) % 12) + 1 for p, s in VEDIC_EXALT.items()}


def _profile_coords(profile: Dict) -> Tuple[float, float]:
    city = profile.get("city") or "Delhi"
    preset = CITY_PRESETS.get(city, CITY_PRESETS.get("Delhi", {"lat":28.6139,"lon":77.2090}))
    lat = profile.get("latitude")
    lon = profile.get("longitude")
    return float(lat if lat is not None else preset.get("lat", 28.6139)), float(lon if lon is not None else preset.get("lon", 77.2090))


def _julian_from_profile(profile: Dict) -> Tuple[float, datetime, datetime]:
    local_dt = datetime.fromisoformat(f"{profile['birth_date']}T{profile['birth_time']}")
    utc_dt = local_dt - timedelta(hours=float(profile.get("timezone_offset", 5.5)))
    hour = utc_dt.hour + utc_dt.minute/60 + utc_dt.second/3600
    jd = swe.julday(utc_dt.year, utc_dt.month, utc_dt.day, hour, swe.GREG_CAL)
    return jd, local_dt, utc_dt


def _sign_no_from_lon(lon: float) -> int:
    return int((lon % 360)//30) + 1


def _whole_sign_house(sign_no: int, asc_sign_no: int) -> int:
    return ((sign_no - asc_sign_no) % 12) + 1


def _angular_sep(a: float, b: float) -> float:
    d = abs((a-b) % 360)
    return min(d, 360-d)


def _navamsha_sign(sign_no: int, degree: float) -> int:
    pada = min(8, int(degree / (30/9)))
    # movable 1,4,7,10 starts same; fixed 2,5,8,11 starts 9th; dual starts 5th
    if sign_no in {1,4,7,10}:
        start = sign_no
    elif sign_no in {2,5,8,11}:
        start = ((sign_no + 7) % 12) + 1
    else:
        start = ((sign_no + 3) % 12) + 1
    return ((start - 1 + pada) % 12) + 1


def _dasamsa_sign(sign_no: int, degree: float) -> int:
    part = min(9, int(degree / 3.0))
    start = sign_no if sign_no % 2 == 1 else ((sign_no + 7) % 12) + 1
    return ((start - 1 + part) % 12) + 1


def _dwadasamsa_sign(sign_no: int, degree: float) -> int:
    part = min(11, int(degree / 2.5))
    return ((sign_no - 1 + part) % 12) + 1


def _chart_houses(planet_rows: List[Dict], asc_sign_no: int, sign_key: str = "sign_no") -> List[Dict]:
    out = []
    for h in range(1,13):
        sign_no = ((asc_sign_no - 1 + h - 1) % 12) + 1
        ps = []
        for p in planet_rows:
            p_sign = int(p.get(sign_key) or 1)
            if _whole_sign_house(p_sign, asc_sign_no) == h:
                ps.append({"planet":p["planet"],"short":PLANET_SHORT.get(p["planet"],p["planet"][:2]),"degree":p.get("degree",p.get("degree_in_sign")),"retrograde":bool(p.get("retrograde")),"flags":p.get("flags",[])})
        out.append({"house":h,"sign_no":sign_no,"sign":SIGNS[sign_no-1][0],"planets":ps})
    return out


def _lagna(profile: Dict) -> Dict:
    jd, local_dt, utc_dt = _julian_from_profile(profile)
    lat, lon = _profile_coords(profile)
    swe.set_sid_mode(swe.SIDM_LAHIRI,0,0)
    cusps, ascmc = swe.houses_ex(jd, lat, lon, b'P', swe.FLG_SIDEREAL)
    asc = float(ascmc[0] % 360)
    return {
        "longitude":round(asc,4),
        "degree_in_sign":round(asc%30,2),
        "sign_no":_sign_no_from_lon(asc),
        "sign":SIGNS[_sign_no_from_lon(asc)-1][0],
        "latitude":lat,"longitude_geo":lon,
        "local_datetime":local_dt.isoformat(timespec="minutes"),"utc_datetime":utc_dt.isoformat(timespec="minutes"),
        "cusps":[round(float(x%360),4) for x in cusps],
        "armc":float(ascmc[2]),
    }


def panchang_from_chart(profile: Dict, placements: List[Dict]) -> Dict:
    by = {p["planet"]:p for p in placements}
    sun = float(by["Sun"]["longitude"]); moon = float(by["Moon"]["longitude"])
    elong = (moon-sun)%360
    tithi = int(elong//12)+1
    paksha = "Shukla" if tithi <= 15 else "Krishna"
    tithi_no = tithi if tithi <= 15 else tithi-15
    tithi_names = ["Pratipada","Dwitiya","Tritiya","Chaturthi","Panchami","Shashthi","Saptami","Ashtami","Navami","Dashami","Ekadashi","Dwadashi","Trayodashi","Chaturdashi","Purnima/Amavasya"]
    nak_size = 360/27
    nak_idx = int(moon//nak_size)
    nak_within = moon - nak_idx*nak_size
    pada = int(nak_within/(nak_size/4))+1
    yoga_idx = int(((sun+moon)%360)//nak_size)
    karana_no = int(elong//6)+1
    if karana_no == 1: karana = "Kimstughna"
    elif 2 <= karana_no <= 57: karana = KARANA_MOVABLE[(karana_no-2)%7]
    elif karana_no == 58: karana = "Shakuni"
    elif karana_no == 59: karana = "Chatushpada"
    else: karana = "Naga"
    dt = datetime.fromisoformat(profile["birth_date"])
    vara = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"][dt.weekday()]
    return {
        "vara":vara,
        "tithi":{"number":tithi,"paksha":paksha,"name":tithi_names[tithi_no-1]},
        "nakshatra":{"number":nak_idx+1,"name":NAKSHATRAS[nak_idx],"pada":pada,"progress_pct":round(100*nak_within/nak_size,1)},
        "yoga":{"number":yoga_idx+1,"name":YOGAS[yoga_idx]},
        "karana":{"sequence":karana_no,"name":karana},
        "moon_sign":by["Moon"]["sign"],"sun_sign":by["Sun"]["sign"],
        "note":"Astronomical Panchang elements are calculated from sidereal Sun/Moon longitude. Local sunrise-based festival observance can require a dedicated Panchang almanac.",
    }


def vimshottari_dasha(profile: Dict, placements: List[Dict], years: int = 120) -> Dict:
    moon = next(p for p in placements if p["planet"]=="Moon")
    moon_lon = float(moon["longitude"])
    nak_size = 360/27
    nak_idx = int(moon_lon//nak_size)
    within = moon_lon - nak_idx*nak_size
    lord = DASHA_ORDER[nak_idx % 9]
    lord_index = DASHA_ORDER.index(lord)
    total = DASHA_YEARS[lord]
    remaining_fraction = 1 - within/nak_size
    remaining_years = total * remaining_fraction
    birth_dt = datetime.fromisoformat(profile["birth_date"])
    # Use mean tropical year for display scheduling; this is an auxiliary timeline.
    current_start = birth_dt
    current_end = current_start + timedelta(days=remaining_years*365.2425)
    rows = [{"lord":lord,"start":current_start.date().isoformat(),"end":current_end.date().isoformat(),"years":round(remaining_years,2),"partial_at_birth":True}]
    idx = (lord_index+1)%9
    while (current_end-birth_dt).days < years*365.25:
        l = DASHA_ORDER[idx]
        dur = DASHA_YEARS[l]
        nxt = current_end + timedelta(days=dur*365.2425)
        rows.append({"lord":l,"start":current_end.date().isoformat(),"end":nxt.date().isoformat(),"years":dur,"partial_at_birth":False})
        current_end = nxt; idx=(idx+1)%9
        if len(rows)>20: break
    today = datetime.now().date()
    active = next((r for r in rows if datetime.fromisoformat(r["start"]).date() <= today < datetime.fromisoformat(r["end"]).date()), None)
    return {"birth_nakshatra":NAKSHATRAS[nak_idx],"starting_lord":lord,"balance_at_birth_years":round(remaining_years,2),"active":active,"mahadasha":rows,"note":"Vimshottari is a Vedic auxiliary timing system, not a Lal Kitab rule. Dates are software reference dates using mean-year conversion."}


def _strength_lab(placements: List[Dict], lagna_sign_no: int, d9_signs: Dict[str,int]) -> List[Dict]:
    by = {p["planet"]:p for p in placements}
    sun_lon = float(by["Sun"]["longitude"])
    rows=[]
    for p in placements:
        name=p["planet"]; sign_no=SIGN_TO_NO[p["sign"]]; h=_whole_sign_house(sign_no,lagna_sign_no)
        score=50; flags=[]; components=[]
        if name in VEDIC_EXALT and sign_no==VEDIC_EXALT[name]: score+=18; flags.append("Exalted")
        if name in VEDIC_DEBIL and sign_no==VEDIC_DEBIL[name]: score-=18; flags.append("Debilitated")
        if h in {1,4,7,10}: score+=7; components.append("Kendra +7")
        if h in {1,5,9}: score+=7; components.append("Trikona +7")
        if h in {6,8,12}: score-=6; components.append("Dusthana -6")
        if p.get("retrograde") and name not in {"Rahu","Ketu"}: score+=2; flags.append("Retrograde")
        if name in COMBUST_LIMIT and _angular_sep(float(p["longitude"]),sun_lon) <= COMBUST_LIMIT[name]: score-=8; flags.append("Combust ref")
        if d9_signs.get(name)==sign_no: score+=6; flags.append("Vargottama")
        score=max(0,min(100,round(score)))
        rows.append({"planet":name,"score":score,"house":h,"sign_no":sign_no,"sign":p["sign"],"flags":flags or ["Standard"],"components":components,"note":"V8 Strength Lab is a transparent auxiliary index; it is not the full classical six-part Shadbala computation."})
    return rows


def vedic_auxiliary(chart: Dict) -> Dict:
    profile=chart.get("profile",{})
    placements=chart.get("placements",[])
    lag=_lagna(profile)
    asc_sign=lag["sign_no"]
    planet_rows=[]
    for p in placements:
        planet_rows.append({"planet":p["planet"],"sign_no":SIGN_TO_NO[p["sign"]],"degree":float(p["degree_in_sign"]),"longitude":float(p["longitude"]),"retrograde":p.get("retrograde",False)})
    d1=_chart_houses(planet_rows,asc_sign)
    moon_sign=next(x["sign_no"] for x in planet_rows if x["planet"]=="Moon")
    moon_chart=_chart_houses(planet_rows,moon_sign)

    d9_rows=[]; d9_signs={}
    for x in planet_rows:
        ns=_navamsha_sign(x["sign_no"],x["degree"]); d9_signs[x["planet"]]=ns
        d9_rows.append({**x,"sign_no":ns})
    d9_asc=_navamsha_sign(asc_sign,lag["degree_in_sign"])
    d9=_chart_houses(d9_rows,d9_asc)

    d10_rows=[]
    for x in planet_rows:
        d10_rows.append({**x,"sign_no":_dasamsa_sign(x["sign_no"],x["degree"])})
    d10_asc=_dasamsa_sign(asc_sign,lag["degree_in_sign"])
    d10=_chart_houses(d10_rows,d10_asc)

    d12_rows=[]
    for x in planet_rows:
        d12_rows.append({**x,"sign_no":_dwadasamsa_sign(x["sign_no"],x["degree"])})
    d12_asc=_dwadasamsa_sign(asc_sign,lag["degree_in_sign"])
    d12=_chart_houses(d12_rows,d12_asc)

    # Bhav Chalit auxiliary: tropical Placidus house-position calculation, while
    # displayed sign labels stay sidereal/whole-sign. This is intentionally
    # separated from Lal Kitab fixed houses.
    try:
        jd,_,_=_julian_from_profile(profile); lat,lon=_profile_coords(profile)
        tcusps,tascmc=swe.houses_ex(jd,lat,lon,b'P',0); armc=float(tascmc[2])
        ecl,_=swe.calc_ut(jd,swe.ECL_NUT); eps=float(ecl[0])
        chalit_rows=[]
        flags_t=swe.FLG_MOSEPH|swe.FLG_SPEED
        for name,code in PLANETS.items():
            vals,_=swe.calc_ut(jd,code,flags_t); hpos=float(swe.house_pos(armc,lat,eps,(float(vals[0]),float(vals[1])),b'P'))
            bh=max(1,min(12,int(math.floor(hpos))))
            natal=next(x for x in planet_rows if x['planet']==name)
            chalit_rows.append({**natal,'bhava_house':bh})
        rahu_ch=next(x for x in chalit_rows if x['planet']=='Rahu')
        ketu_natal=next(x for x in planet_rows if x['planet']=='Ketu')
        ketu_house=((rahu_ch['bhava_house']+5)%12)+1
        chalit_rows.append({**ketu_natal,'bhava_house':ketu_house})
        chalit=[]
        for h in range(1,13):
            sign_no=((asc_sign-1+h-1)%12)+1
            ps=[]
            for x in chalit_rows:
                if x['bhava_house']==h:
                    ps.append({'planet':x['planet'],'short':PLANET_SHORT.get(x['planet'],x['planet'][:2]),'degree':x.get('degree'),'retrograde':x.get('retrograde',False),'flags':[]})
            chalit.append({'house':h,'sign_no':sign_no,'sign':SIGNS[sign_no-1][0],'planets':ps})
    except Exception:
        chalit=d1

    panchang=panchang_from_chart(profile,placements)
    dasha=vimshottari_dasha(profile,placements)
    strength=_strength_lab(placements,asc_sign,d9_signs)

    planet_details=[]
    for p in placements:
        sign_no=SIGN_TO_NO[p["sign"]]; h=_whole_sign_house(sign_no,asc_sign); flags=[]
        if p.get("retrograde"): flags.append("Retrograde")
        if p["planet"] in COMBUST_LIMIT and _angular_sep(float(p["longitude"]),float(next(z for z in placements if z["planet"]=="Sun")["longitude"])) <= COMBUST_LIMIT[p["planet"]]: flags.append("Combust ref")
        if p["planet"] in VEDIC_EXALT and sign_no==VEDIC_EXALT[p["planet"]]: flags.append("Exalted")
        if p["planet"] in VEDIC_DEBIL and sign_no==VEDIC_DEBIL[p["planet"]]: flags.append("Debilitated")
        if d9_signs.get(p["planet"])==sign_no: flags.append("Vargottama")
        moon_lon=float(p["longitude"]); nak_size=360/27; ni=int(moon_lon//nak_size); within=moon_lon-ni*nak_size; pada=int(within/(nak_size/4))+1
        planet_details.append({"planet":p["planet"],"short":PLANET_SHORT[p["planet"]],"longitude":p["longitude"],"degree_in_sign":p["degree_in_sign"],"sign_no":sign_no,"sign":p["sign"],"house":h,"nakshatra":NAKSHATRAS[ni],"pada":pada,"flags":flags or ["Standard"]})

    bhav_mid=[]
    for h in range(1,13):
        sign_no=((asc_sign-1+h-1)%12)+1
        bhav_mid.append({"house":h,"sign_no":sign_no,"midpoint_longitude":round(((sign_no-1)*30+15)%360,2),"note":"Whole-sign midpoint reference"})

    yoga_candidates=raj_yoga_candidates(planet_rows,asc_sign)
    varga_workspace=shodashavarga_workspace({"lagna":d1,"navamsha":d9,"dasamsa":d10,"dwadasamsa":d12})
    ghatak_workspace=ghatak_favourable_workspace(panchang)

    return {
        "lagna":lag,
        "charts":{"lagna":d1,"navamsha":d9,"moon":moon_chart,"chalit":chalit,"dasamsa":d10,"dwadasamsa":d12},
        "chart_ascendants":{"lagna":asc_sign,"navamsha":d9_asc,"moon":moon_sign,"dasamsa":d10_asc,"dwadasamsa":d12_asc},
        "planet_details":planet_details,
        "panchang":panchang,
        "vimshottari":dasha,
        "strength_lab":strength,
        "bhav_madhya":bhav_mid,
        "raj_yoga_candidates":yoga_candidates,
        "shodashavarga_workspace":varga_workspace,
        "ghatak_favourable_workspace":ghatak_workspace,
        "ashtakavarga_workspace":{"status":"Source profile required","note":"V8 intentionally does not fabricate classical bindu totals. The workspace is ready for a selected, auditable Ashtakavarga rule table."},
        "kp_workspace":{"status":"Auxiliary foundation","cusps":lag["cusps"],"note":"Sidereal cusp longitudes are exposed. Full KP star/sub-lord judgement is not auto-claimed in V8."},
        "method_note":"Lagna/Navamsha/Moon/D10/D12/Panchang/Vimshottari are Vedic auxiliary layers. They are kept separate from Lal Kitab fixed-house rules.",
    }


def transit_snapshot(chart: Dict, when: Optional[str]=None) -> Dict:
    profile=chart.get("profile",{})
    tz=float(profile.get("timezone_offset",5.5))
    if when:
        dt=datetime.fromisoformat(when)
    else:
        dt=datetime.utcnow()+timedelta(hours=tz)
    birth_aux=chart.get("vedic_aux") or vedic_auxiliary(chart)
    asc_sign=birth_aux["chart_ascendants"]["lagna"]
    calc=calc_planets("Transit",dt.date().isoformat(),dt.time().replace(second=0,microsecond=0).isoformat(timespec="minutes"),tz)
    rows=[]
    for p in calc["placements"]:
        sign_no=SIGN_TO_NO[p["sign"]]
        rows.append({"planet":p["planet"],"short":PLANET_SHORT[p["planet"]],"sign_no":sign_no,"sign":p["sign"],"degree_in_sign":p["degree_in_sign"],"natal_whole_sign_house":_whole_sign_house(sign_no,asc_sign),"retrograde":p.get("retrograde",False)})
    return {"local_datetime":dt.isoformat(timespec="minutes"),"placements":rows,"note":"Live transit positions are astronomical sidereal placements mapped to the natal whole-sign Lagna chart. Interpretive meaning remains non-deterministic."}


def monthly_focus(chart: Dict, year: int) -> Dict:
    base=forecast_year(chart,int(year))
    profile=chart.get("profile",{})
    tz=float(profile.get("timezone_offset",5.5))
    rows=[]
    for month in range(1,13):
        dt=datetime(int(year),month,15,12,0)
        calc=calc_planets("Monthly transit",dt.date().isoformat(),"12:00",tz)
        by_domain=[]
        for key,rule in DOMAIN_RULES.items():
            annual=float(base["domains"].get(key,{}).get("score",50))
            boost=0; evidence=[]
            for p in calc["placements"]:
                if p["planet"] in rule.get("planets",[]) and p["house"] in rule.get("houses",[]):
                    boost += 2.5; evidence.append(f"{p['planet']} H{p['house']}")
                elif p["house"] in rule.get("houses",[]):
                    boost += 0.8
            score=max(0,min(100,annual+boost))
            by_domain.append({"key":key,"label":rule["label"],"score":round(score,1),"transit_evidence":evidence[:4]})
        top=sorted(by_domain,key=lambda x:x["score"],reverse=True)[:3]
        watch=sorted(by_domain,key=lambda x:x["score"])[:2]
        rows.append({"month":month,"label":dt.strftime("%B"),"top":top,"watch":watch,"all":by_domain})
    return {"year":int(year),"months":rows,"note":"Monthly Focus combines the existing annual software index with mid-month sidereal transit activation. It is a planning lens, not a promise that an event will occur in a given month."}


def life_timeline(chart: Dict, start_age:int=1, end_age:int=90) -> Dict:
    birth_year=int(chart.get("profile",{}).get("birth_date","2000-01-01")[:4])
    start=max(1,int(start_age)); end=min(108,max(start,int(end_age)))
    dasha=(chart.get("vedic_aux") or vedic_auxiliary(chart))["vimshottari"]["mahadasha"]
    def dasha_for_year(year:int):
        mid=datetime(year,7,1).date()
        for r in dasha:
            if datetime.fromisoformat(r["start"]).date() <= mid < datetime.fromisoformat(r["end"]).date(): return r["lord"]
        return None
    rows=[]; prev=None; turning=[]
    for age in range(start,end+1):
        year=birth_year+age
        fy=forecast_year(chart,year)
        top=fy.get("top",[])[:2]; watch=fy.get("watch",[])[:1]
        avg=round(sum(float(v.get("score",50)) for v in fy.get("domains",{}).values())/max(1,len(fy.get("domains",{}))),1)
        hc=house_cycle_for_age(age)
        row={"age":age,"year":year,"index":avg,"house_cycle":hc,"dasha_lord":dasha_for_year(year),"top":top,"watch":watch}
        if prev is not None:
            delta=round(avg-prev["index"],1); row["delta"]=delta
            if abs(delta)>=5:
                turning.append({"age":age,"year":year,"delta":delta,"direction":"up" if delta>0 else "down","top":top[:1],"house":hc.get("house")})
        else: row["delta"]=0
        rows.append(row); prev=row
    return {"start_age":start,"end_age":end,"rows":rows,"turning_points":sorted(turning,key=lambda x:abs(x["delta"]),reverse=True)[:18],"note":"Life Timeline combines annual software scores, 36-year house-cycle and a separately labelled Vedic Vimshottari reference. It is not an objective life-event probability model."}


def turning_point_summary(chart: Dict, years:int=18) -> Dict:
    current=datetime.now().year
    rows=[]; prev=None
    for y in range(current,current+max(2,min(int(years),30))):
        fy=forecast_year(chart,y)
        avg=round(sum(float(v.get("score",50)) for v in fy.get("domains",{}).values())/max(1,len(fy.get("domains",{}))),1)
        top=fy.get("top",[])[:2]
        row={"year":y,"index":avg,"top":top}
        if prev is not None: row["delta"]=round(avg-prev["index"],1)
        else: row["delta"]=0
        rows.append(row);prev=row
    points=sorted(rows[1:],key=lambda r:abs(r["delta"]),reverse=True)[:8]
    return {"years":rows,"turning_points":points,"note":"Turning points flag larger year-to-year changes in the software emphasis index, not guaranteed external events."}


def ai_feature_catalog() -> List[Dict]:
    return [
        {"key":"explainer","label":"AI Chart Explainer","desc":"Ask natural-language questions with chart evidence."},
        {"key":"second_opinion","label":"AI Second Opinion","desc":"Produces an independent interpretation and compares agreement."},
        {"key":"skeptic","label":"AI Skeptic","desc":"Actively searches for contradictory chart evidence and uncertainty."},
        {"key":"consultation","label":"AI Consultation Copilot","desc":"Builds questions, agenda, summary and follow-up actions."},
        {"key":"remedy_review","label":"AI Remedy Safety Review","desc":"Checks stacking, ambiguity and real-world safety boundaries."},
        {"key":"timeline","label":"AI Timeline Narrator","desc":"Turns the life timeline into a readable, caveated story."},
        {"key":"report","label":"AI Report Writer","desc":"Generates client-friendly narrative from calculated fields."},
        {"key":"evidence","label":"Why This Prediction?","desc":"Explains support, caution and source layers behind a score."},
        {"key":"muhurta","label":"AI Muhurta Copilot","desc":"Explains ranked planning dates and cautions without guarantees."},
        {"key":"research","label":"AI Research Copilot","desc":"Cross-checks Lal Kitab, Varga, Yogini and software evidence while keeping systems separate."},
        {"key":"compatibility_ai","label":"AI Compatibility Analyst","desc":"Explains pair/family evidence with balanced non-deterministic language."},
        {"key":"business_ai","label":"AI Business Planning Lens","desc":"Explains symbolic career/business themes without financial-return promises."},
        {"key":"source_compare","label":"AI Source Compare","desc":"Compares GD Vashist/Astroscience, Sumitacharya public-source and core software layers without pretending they are the same system."},
        {"key":"dosha_audit","label":"AI Dosha Auditor","desc":"Challenges dosha candidate flags, missing evidence and cancellation assumptions; never predicts death/disease/lifespan."},
        {"key":"remedy_scholar","label":"AI Remedy Scholar","desc":"Explains why source-linked low-risk upay were ranked and checks overlap, attribution and safety."},
    ]
