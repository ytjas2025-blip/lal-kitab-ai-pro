# V12 — Multi-Source Intelligence

## Added
- 1,200 Shri Sumitacharya public-source-aware upay cards; total remedy vault is now 4,800.
- Shri Sumitacharya Source Intelligence dashboard.
- Deep 5-year prediction workspace using existing calculated chart/Dasha/Varga/annual/transit layers.
- Conservative Vedic Dosha Research Lab: Manglik, Sade Sati, Kaal Sarpa and Trijata candidate screens.
- 108-Insight report builder (original software outline, not a reproduction of a paid report).
- Traditional Nakshatra/Pada Baby Name Lab.
- Business + Vastu workflow checklist.
- Marriage single-chart research panel.
- Expanded **18-source** library for official/public Sumitacharya website/service indexes and official YouTube references.
- Three new AI modes: Source Compare, Dosha Auditor and Remedy Scholar (15 total AI modes).
- V12 PDF appendix with source-aware research notes.

## Safety / provenance
- No paid report, consultation, proprietary algorithm, copyrighted article body or full transcript is imported.
- No death, widowhood, lifespan, disease or fertility predictions are operationalized from dosha labels.
- Source claims about wealth/health/ritual efficacy are presented as traditional beliefs, not factual guarantees.
- Medical, legal, investment and safety-critical decisions remain outside the astrology engine.
