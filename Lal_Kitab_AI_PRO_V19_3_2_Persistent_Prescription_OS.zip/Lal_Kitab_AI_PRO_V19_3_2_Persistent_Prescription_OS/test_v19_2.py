from engine import chart_payload
from intelligence_v19_2 import v19_2_dashboard
from critical_alerts_v19 import critical_alert_center
EXPECTED={'Sun':9,'Moon':3,'Mars':9,'Mercury':9,'Jupiter':8,'Venus':10,'Saturn':2,'Rahu':4,'Ketu':10}
def fixture():
    return chart_payload({'name':'Golden Fixture','birth_date':'1989-07-20','birth_time':'15:07:30','city':'Ludhiana','timezone_offset':5.5,'latitude':30.900965,'longitude':75.857276,'rule_profile':'1940-foundation'})
def test_v192():
    c=fixture(); assert {p['planet']:p['house'] for p in c['placements']}==EXPECTED
    d=v19_2_dashboard(c)
    sat=[x for x in d['drishti']['rows'] if x['planet']=='Saturn']
    assert {x['to_house'] for x in sat}=={4,8,11}
    mars=[x for x in d['drishti']['rows'] if x['planet']=='Mars']
    assert {x['to_house'] for x in mars}=={12,3,4}
    assert any(set(x['planets'])=={'Jupiter','Saturn'} for x in d['drishti']['mutual'])
    a=critical_alert_center(c); assert len(a['alerts'])>=40
if __name__=='__main__': test_v192(); print('V19.2 PASS')
