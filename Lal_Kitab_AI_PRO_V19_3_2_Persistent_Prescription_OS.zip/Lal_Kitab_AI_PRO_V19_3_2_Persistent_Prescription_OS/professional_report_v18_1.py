from __future__ import annotations
import io, math, textwrap
from datetime import datetime
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
    Image, KeepTogether, Flowable, HRFlowable
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

GOLD = colors.HexColor('#B7892D')
DARK_GOLD = colors.HexColor('#7A5518')
INK = colors.HexColor('#151515')
CHARCOAL = colors.HexColor('#262626')
MUTED = colors.HexColor('#666666')
IVORY = colors.HexColor('#FFF9ED')
PALE = colors.HexColor('#F7F0E1')
RED = colors.HexColor('#9F2D2D')
GREEN = colors.HexColor('#356B4A')
LINE = colors.HexColor('#D7C7A4')

PLANET_ORDER=['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu']
PLANET_SHORT={'Sun':'Su','Moon':'Mo','Mars':'Ma','Mercury':'Me','Jupiter':'Ju','Venus':'Ve','Saturn':'Sa','Rahu':'Ra','Ketu':'Ke'}
HOUSE_THEMES={1:'Self, vitality & identity',2:'Family, speech & stored wealth',3:'Courage, effort & siblings',4:'Home, mother & emotional base',5:'Children, intellect & creativity',6:'Service, competition & obligations',7:'Partnership, spouse & trade',8:'Change, longevity & hidden matters',9:'Fortune, mentors & principles',10:'Career, status & duty',11:'Gains, network & fulfilment',12:'Expense, sleep & release'}


def _font():
    candidates=[
        ('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),
        ('Liberation','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf'),
    ]
    for name,path in candidates:
        try:
            if Path(path).exists():
                if name not in pdfmetrics.getRegisteredFontNames(): pdfmetrics.registerFont(TTFont(name,path))
                return name
        except Exception: pass
    return 'Helvetica'

FONT=_font()

class NorthIndianChart(Flowable):
    def __init__(self, houses, width=72*mm, height=72*mm, title='Lagna Chart'):
        super().__init__(); self.houses=houses or []; self.width=width; self.height=height; self.title=title
    def draw(self):
        c=self.canv; w=self.width; h=self.height; x0=0; y0=0; cx=w/2; cy=h/2
        c.setStrokeColor(CHARCOAL); c.setLineWidth(0.8)
        c.rect(x0,y0,w,h)
        c.line(0,h,cx,cy); c.line(w,h,cx,cy); c.line(0,0,cx,cy); c.line(w,0,cx,cy)
        c.line(cx,h,0,cy); c.line(cx,h,w,cy); c.line(0,cy,cx,0); c.line(w,cy,cx,0)
        # house label positions tuned for North-Indian style
        pos={
            1:(cx, h*0.75), 2:(w*0.26,h*0.82), 3:(w*0.12,h*0.63), 4:(w*0.24,h*0.50),
            5:(w*0.12,h*0.36), 6:(w*0.26,h*0.18), 7:(cx,h*0.25), 8:(w*0.74,h*0.18),
            9:(w*0.88,h*0.36), 10:(w*0.76,h*0.50),11:(w*0.88,h*0.63),12:(w*0.74,h*0.82)
        }
        byh={int(r.get('house',0)):r for r in self.houses}
        c.setFillColor(INK)
        for hn,(x,y) in pos.items():
            r=byh.get(hn,{})
            sign=r.get('sign_no','')
            planets=r.get('planets') or []
            c.setFont(FONT,6.5); c.drawCentredString(x,y+6,str(sign))
            labels=[]
            for p in planets:
                sh=p.get('short') or PLANET_SHORT.get(p.get('planet'),'')
                if p.get('retrograde'): sh += 'R'
                labels.append(sh)
            if labels:
                c.setFont(FONT,6.2)
                # split into up to 2 lines
                s=' '.join(labels)
                if len(s)>11:
                    mid=max(1,len(labels)//2)
                    c.drawCentredString(x,y-2,' '.join(labels[:mid]))
                    c.drawCentredString(x,y-10,' '.join(labels[mid:]))
                else:
                    c.drawCentredString(x,y-4,s)
        c.setFillColor(DARK_GOLD); c.setFont(FONT,8.5); c.drawCentredString(cx,h+5,self.title)

class ScoreBar(Flowable):
    def __init__(self, label, score, width=70*mm, height=9*mm):
        super().__init__(); self.label=str(label); self.score=float(score or 0); self.width=width; self.height=height
    def draw(self):
        c=self.canv; w=self.width; h=self.height
        c.setFont(FONT,7.5); c.setFillColor(INK); c.drawString(0,h-7,self.label[:34])
        x=0; y=1; bw=w-35*mm
        c.setFillColor(colors.HexColor('#E8E2D5')); c.roundRect(x,y,bw,4,2,fill=1,stroke=0)
        c.setFillColor(GOLD if self.score>=55 else RED); c.roundRect(x,y,max(1,bw*max(0,min(100,self.score))/100),4,2,fill=1,stroke=0)
        c.setFillColor(CHARCOAL); c.setFont(FONT,7.5); c.drawRightString(w,h-7,f'{self.score:.1f}/100')


def _styles():
    return {
        'cover_title':ParagraphStyle('cover_title',fontName=FONT,fontSize=27,leading=33,textColor=INK,alignment=TA_CENTER,spaceAfter=4*mm),
        'cover_sub':ParagraphStyle('cover_sub',fontName=FONT,fontSize=12,leading=17,textColor=DARK_GOLD,alignment=TA_CENTER),
        'h1':ParagraphStyle('h1',fontName=FONT,fontSize=18,leading=23,textColor=DARK_GOLD,spaceAfter=4*mm),
        'h2':ParagraphStyle('h2',fontName=FONT,fontSize=13,leading=17,textColor=INK,spaceAfter=2.5*mm),
        'body':ParagraphStyle('body',fontName=FONT,fontSize=9.2,leading=13.2,textColor=CHARCOAL,spaceAfter=2.5*mm),
        'small':ParagraphStyle('small',fontName=FONT,fontSize=7.5,leading=10.5,textColor=MUTED),
        'tiny':ParagraphStyle('tiny',fontName=FONT,fontSize=6.6,leading=8.3,textColor=MUTED),
        'center':ParagraphStyle('center',fontName=FONT,fontSize=8.5,leading=12,textColor=CHARCOAL,alignment=TA_CENTER),
        'white':ParagraphStyle('white',fontName=FONT,fontSize=9.5,leading=13,textColor=colors.white),
        'quote':ParagraphStyle('quote',fontName=FONT,fontSize=10,leading=15,textColor=INK,leftIndent=5*mm,rightIndent=5*mm,borderColor=LINE,borderWidth=0.6,borderPadding=4*mm,backColor=IVORY),
    }

S=_styles()

def _esc(x):
    from xml.sax.saxutils import escape
    return escape(str(x if x is not None else ''))

def _section(title, subtitle=None):
    out=[Paragraph(_esc(title),S['h1']),HRFlowable(width='100%',thickness=0.7,color=GOLD,spaceAfter=4*mm)]
    if subtitle: out.append(Paragraph(_esc(subtitle),S['small'])); out.append(Spacer(1,2*mm))
    return out

def _tbl(data, widths=None, header=True, font=7.5, align='LEFT'):
    rows=[]
    for i,row in enumerate(data):
        rows.append([Paragraph(_esc(v),ParagraphStyle(f't{i}',fontName=FONT,fontSize=font,leading=font+2,textColor=colors.white if header and i==0 else CHARCOAL)) for v in row])
    t=Table(rows,colWidths=widths,repeatRows=1 if header else 0,hAlign=align)
    style=[('GRID',(0,0),(-1,-1),0.35,LINE),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]
    if header:
        style += [('BACKGROUND',(0,0),(-1,0),CHARCOAL),('TEXTCOLOR',(0,0),(-1,0),colors.white)]
    for r in range(1 if header else 0,len(rows)):
        if r%2==0: style.append(('BACKGROUND',(0,r),(-1,r),IVORY))
    t.setStyle(TableStyle(style)); return t

def _header_footer(canvas,doc,client):
    if doc.page==1: return
    canvas.saveState(); W,H=A4
    canvas.setStrokeColor(LINE); canvas.setLineWidth(0.5); canvas.line(15*mm,H-13*mm,W-15*mm,H-13*mm)
    canvas.setFont(FONT,7); canvas.setFillColor(MUTED)
    canvas.drawString(15*mm,H-10*mm,f'Lal Kitab AI PRO • Professional Kundli Report • {client}')
    canvas.drawRightString(W-15*mm,H-10*mm,'V18.1')
    canvas.line(15*mm,12*mm,W-15*mm,12*mm)
    canvas.drawString(15*mm,8*mm,'Interpretive astrology report • source-aware • explainable')
    canvas.drawRightString(W-15*mm,8*mm,f'Page {doc.page}')
    canvas.restoreState()

def _planet_sentence(p):
    pl=p.get('planet'); sign=p.get('sign'); house=p.get('house'); deg=p.get('degree_in_sign'); nak=p.get('nakshatra'); pada=p.get('pada'); flags=', '.join(p.get('flags') or [])
    theme=HOUSE_THEMES.get(house,'the relevant life area')
    return f"{pl} is placed in {sign} at {deg:.2f}° in House {house} ({theme}), Nakshatra {nak} Pada {pada}. Engine condition: {flags or 'standard placement'}. This placement should be read with its active Dasha, house relationships, transit triggers and divisional support rather than in isolation."

def _planet_focus(pl,house):
    f={
        'Sun':'identity, authority, confidence and visibility','Moon':'mind, emotional rhythm, home and public responsiveness','Mars':'action, courage, competition, land and conflict handling','Mercury':'learning, trade, communication, documents and analysis','Jupiter':'guidance, learning, expansion, mentors and long-range judgment','Venus':'relationships, comforts, agreements, aesthetics and value choices','Saturn':'discipline, delay, duty, structure and sustained effort','Rahu':'ambition, unconventional routes, networks, appetite and amplification','Ketu':'detachment, simplification, insight, endings and selective focus'}
    return f.get(pl,'the planet’s natural themes')

def _house_summary(chart,h):
    houses=chart.get('houses') or []
    row=next((x for x in houses if int(x.get('house',0))==h),{})
    occ=row.get('planets') or row.get('occupants') or []
    if occ and isinstance(occ[0],dict): occ=', '.join(x.get('planet','') for x in occ)
    elif isinstance(occ,list): occ=', '.join(map(str,occ))
    return occ or 'No natal planet listed'

def _build(chart, asset_dir=None):
    prof=chart.get('profile') or {}; va=chart.get('vedic_aux') or {}; panch=va.get('panchang') or {}
    name=prof.get('name','Client'); story=[]
    # Cover
    story += [Spacer(1,12*mm)]
    img_path=None
    if asset_dir:
        p=Path(asset_dir)/'static'/'lal_kitab_sacred_chart.png'
        if p.exists(): img_path=str(p)
    if img_path:
        story.append(Image(img_path,width=42*mm,height=42*mm)); story[-1].hAlign='CENTER'; story.append(Spacer(1,5*mm))
    story += [Paragraph('LAL KITAB AI PRO',S['cover_title']),Paragraph('Professional Kundli • Prediction • Remedy Report',S['cover_sub']),Spacer(1,8*mm)]
    info=[["Name",name],["Date of Birth",prof.get('birth_date','')],["Time of Birth",prof.get('birth_time','')],["Place",prof.get('city','')],["Ayanamsa / Method",'Sidereal • Lahiri auxiliary • Lal Kitab source-aware profile'],["Report Edition",'V18.1 Professional Report Engine']]
    t=_tbl(info,widths=[48*mm,95*mm],header=False,font=8.5,align='CENTER'); t.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),CHARCOAL),('TEXTCOLOR',(0,0),(0,-1),colors.white),('BOX',(0,0),(-1,-1),0.8,GOLD)])); story.append(t)
    story += [Spacer(1,9*mm),Paragraph('A dense, chart-first report inspired by the structure of traditional professional Kundli reports: calculated charts, tables, timing, predictions and remedies are kept together instead of stretching one sentence across a page.',S['quote']),Spacer(1,8*mm),Paragraph('Astrology is interpretive guidance, not a guarantee. Medical, legal and financial decisions require qualified professional advice.',S['small']),PageBreak()]

    # Report map + basic details
    story += _section('1. Basic Details & Report Map','The opening section collects the same core birth anchors a professional Kundli report should establish before interpretation.')
    lag=va.get('lagna') or {}; nak=panch.get('nakshatra') or {}; tithi=panch.get('tithi') or {}; yoga=panch.get('yoga') or {}; kar=panch.get('karana') or {}
    basic=[['Field','Value'],['Name',name],['Date of Birth',prof.get('birth_date','')],['Time of Birth',prof.get('birth_time','')],['Place',prof.get('city','')],['Timezone',prof.get('timezone_offset','')],['Latitude',f"{lag.get('latitude','—')}"],['Longitude',f"{lag.get('longitude_geo','—')}"],['Ascendant',lag.get('sign','—')],['Moon Sign',panch.get('moon_sign','—')],['Nakshatra / Pada',f"{nak.get('name','—')} / {nak.get('pada','—')}"],['Tithi',f"{tithi.get('paksha','')} {tithi.get('name','')}"],['Vara',panch.get('vara','—')],['Yoga',yoga.get('name','—')],['Karana',kar.get('name','—')]]
    story.append(_tbl(basic,widths=[54*mm,108*mm],font=8.1)); story.append(Spacer(1,5*mm))
    sections=['Traditional chart overview','Ascendant & Nakshatra','Planetary positions','12-house analysis','Planet passports','Vimshottari & Yogini timing','Varshphal / annual forecast','Current transits','16 life-domain predictions','12-month forecast','5-year roadmap & Event Radar','Lal Kitab placement analysis','Remedies','Dosha research','Shadbala research index','16 Vargas','25-year Luck Chain','Source comparison & audit']
    story.append(Paragraph('<b>Report sections</b>',S['h2'])); story.append(_tbl([['#','Section']]+[[i+1,s] for i,s in enumerate(sections)],widths=[12*mm,150*mm],font=7.5)); story.append(PageBreak())

    # Traditional overview
    story += _section('2. Traditional Overview - Lagna & Navamsha','Dense chart-and-table presentation, not a text-only page.')
    d1=va.get('charts',{}).get('lagna',[]); d9=va.get('charts',{}).get('navamsha',[])
    ct=Table([[NorthIndianChart(d1,70*mm,70*mm,'Lagna / D1'),NorthIndianChart(d9,70*mm,70*mm,'Navamsha / D9')]],colWidths=[82*mm,82*mm]); ct.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP')])); story.append(ct); story.append(Spacer(1,5*mm))
    pd=va.get('planet_details') or []
    rows=[['Planet','Sign','Degree','House','Nakshatra','Pada']]
    for p in pd: rows.append([p.get('planet'),p.get('sign'),f"{p.get('degree_in_sign',0):.2f}°",p.get('house'),p.get('nakshatra'),p.get('pada')])
    story.append(_tbl(rows,widths=[22*mm,25*mm,21*mm,15*mm,39*mm,14*mm],font=7)); story.append(PageBreak())

    # Ascendant / nakshatra
    story += _section('3. Ascendant & Nakshatra','A professional report should explain the two primary identity anchors before jumping into predictions.')
    asc=lag.get('sign','—'); nname=nak.get('name','—'); npada=nak.get('pada','—')
    story.append(Paragraph(f'<b>Ascendant: {_esc(asc)}</b>',S['h2'])); story.append(Paragraph(f"The ascendant sets the house framework for the Vedic auxiliary layer. In this chart it is {asc}. The software uses it for D1 house placement, divisional support and transit mapping, while Lal Kitab fixed-house interpretation is kept as a separate rule layer.",S['body']))
    story.append(Paragraph(f'<b>Nakshatra: {_esc(nname)} - Pada {_esc(npada)}</b>',S['h2'])); story.append(Paragraph(f"The Moon falls in {nname}, Pada {npada}. Nakshatra is used as a timing and temperament support factor and is not treated as a standalone destiny statement. The current report cross-checks it against Moon sign {panch.get('moon_sign','—')}, active Dasha and current transit context.",S['body']))
    anchor_tbl=[['Birth Anchor','Calculated Value'],['Ascendant',asc],['Moon sign',panch.get('moon_sign','—')],['Sun sign',panch.get('sun_sign','—')],['Nakshatra',nname],['Pada',npada],['Tithi',f"{tithi.get('paksha','')} {tithi.get('name','')}"],['Yoga',yoga.get('name','—')],['Karana',kar.get('name','—')]]
    story.append(_tbl(anchor_tbl,widths=[56*mm,106*mm],font=8)); story.append(PageBreak())

    # Planetary positions page
    story += _section('4. Planetary Positions & Condition','This is the factual placement layer used by the later interpretation sections.')
    rows=[['Planet','Sign','House','Degree','Nakshatra','Pada','Condition']]
    for p in pd:
        rows.append([p.get('planet'),p.get('sign'),p.get('house'),f"{p.get('degree_in_sign',0):.2f}°",p.get('nakshatra'),p.get('pada'),', '.join(p.get('flags') or [])])
    story.append(_tbl(rows,widths=[19*mm,21*mm,13*mm,18*mm,32*mm,12*mm,47*mm],font=6.7)); story.append(Spacer(1,5*mm))
    story.append(Paragraph('Reading rule: placements are calculations; “condition” labels are software/reference classifications. Predictions and remedies are downstream interpretations and remain separately traceable.',S['quote'])); story.append(PageBreak())

    # Houses 2 pages
    for chunk_start in (1,7):
        story += _section(f'5. House Analysis - Houses {chunk_start}-{chunk_start+5}','Each house is shown with its theme and occupants so the client can verify the chart before reading narrative conclusions.')
        rows=[['House','Theme','Occupants']]
        for h in range(chunk_start,chunk_start+6): rows.append([h,HOUSE_THEMES[h],_house_summary(chart,h)])
        story.append(_tbl(rows,widths=[14*mm,84*mm,64*mm],font=7.4)); story.append(Spacer(1,4*mm))
        for h in range(chunk_start,chunk_start+6):
            story.append(Paragraph(f'<b>House {h}: {_esc(HOUSE_THEMES[h])}</b>',S['h2'])); story.append(Paragraph(f"Occupants: {_esc(_house_summary(chart,h))}. Read this house with its lord/relationship logic, active Dasha and transit activation. The report avoids declaring an event from one house alone.",S['body']))
        story.append(PageBreak())

    # Planet passports (3 per page)
    pmap={p.get('planet'):p for p in pd}
    for k in range(0,9,3):
        story += _section(f'6. Planet Passports - {", ".join(PLANET_ORDER[k:k+3])}','Chart-specific placement cards with timing and remedy context.')
        for pl in PLANET_ORDER[k:k+3]:
            p=pmap.get(pl,{})
            story.append(Paragraph(f'<b>{pl}</b> - {p.get("sign","—")} • House {p.get("house","—")} • {p.get("nakshatra","—")} Pada {p.get("pada","—")}',S['h2']))
            story.append(Paragraph(_planet_sentence(p),S['body']))
            story.append(Paragraph(f"<b>Primary themes:</b> {_planet_focus(pl,p.get('house'))}. <b>Professional use:</b> verify whether the planet is active in Mahadasha/Antardasha/Pratyantar/Sookshma or strongly triggered by transit before elevating it to a major prediction.",S['body']))
            story.append(HRFlowable(width='100%',thickness=0.4,color=LINE,spaceBefore=1*mm,spaceAfter=3*mm))
        story.append(PageBreak())

    # Vimshottari overview
    from prediction_v10 import vimshottari_full, full_prediction_studio
    dasha=vimshottari_full(chart)
    story += _section('7. Vimshottari Dasha - Full Timing Structure','Mahadasha is not enough; the active chain is shown down to Sookshma.')
    md=(va.get('vimshottari') or {}).get('mahadasha') or dasha.get('mahadasha') or []
    rows=[['Lord','Start','End','Years']]
    for x in md[:12]: rows.append([x.get('lord'),x.get('start'),x.get('end'),x.get('years','')])
    story.append(_tbl(rows,widths=[30*mm,45*mm,45*mm,24*mm],font=7.4)); story.append(Spacer(1,5*mm))
    story.append(Paragraph('<b>Active timing chain</b>',S['h2']))
    chain=[['Level','Lord','Start','End','Natal Support','Key Watch']]
    for x in dasha.get('active_chain',[]): chain.append([x.get('level'),x.get('lord'),x.get('start'),x.get('end'),f"{x.get('natal_score','—')}/100",x.get('watch','')])
    story.append(_tbl(chain,widths=[26*mm,22*mm,31*mm,31*mm,25*mm,39*mm],font=6.6)); story.append(PageBreak())

    # Active chain narrative page
    story += _section('8. Active Dasha Interpretation','Each level narrows the broad Mahadasha story into the currently active sub-period.')
    for x in dasha.get('active_chain',[]):
        story.append(Paragraph(f'<b>{_esc(x.get("level"))}: {_esc(x.get("lord"))}</b> • {_esc(x.get("start"))} to {_esc(x.get("end"))}',S['h2']))
        story.append(Paragraph(f"Focus: {_esc(x.get('focus',''))}. Support: {_esc(x.get('support',''))}. Watch: {_esc(x.get('watch',''))}. Lal Kitab house reference H{_esc(x.get('lal_kitab_house','—'))}; natal support {_esc(x.get('natal_score','—'))}/100.",S['body']))
    story.append(PageBreak())

    # Yogini
    from astro_v9 import yogini_dasha, shadbala_research, shodashavarga_full
    yogd=yogini_dasha(chart,4)
    story += _section('9. Yogini Dasha','A separate timing lens is retained rather than blended invisibly into Vimshottari.')
    periods=yogd.get('periods') or []
    rows=[['Yogini','Start','End','Years']]
    for x in periods[:18]: rows.append([x.get('yogini') or x.get('name'),x.get('start'),x.get('end'),x.get('years','')])
    story.append(_tbl(rows,widths=[34*mm,46*mm,46*mm,22*mm],font=7)); story.append(Spacer(1,5*mm)); story.append(Paragraph(yogd.get('method_note','Yogini Dasha is treated as an auxiliary timing layer.'),S['small'])); story.append(PageBreak())

    # Annual / Varshphal-style planning
    fp=full_prediction_studio(chart,years=5)
    story += _section('10. Annual Forecast / Varshphal-Style Planning','Birthday-year planning view with current domains and timing overlays.')
    yr=datetime.now().year
    ny=(fp.get('next_years') or [])
    current=next((x for x in ny if x.get('year')==yr),ny[0] if ny else {})
    story.append(Paragraph(f'<b>{yr} annual emphasis</b>',S['h2']))
    top=', '.join(x.get('label',str(x)) for x in (current.get('top') or [])[:4]) or 'See domain table below'
    watch=', '.join(x.get('label',str(x)) for x in (current.get('watch') or [])[:3]) or 'See domain table below'
    story.append(Paragraph(f"Stronger areas: {top}. Areas to verify/manage: {watch}. This layer is combined with active Dasha and current transits; it is not a stand-alone solar-return claim.",S['body']))
    story.append(Paragraph('<b>Current domain snapshot</b>',S['h2']))
    for d in sorted(fp.get('domains',[]),key=lambda x:x.get('current_score',0),reverse=True)[:10]: story.append(ScoreBar(d.get('label'),d.get('current_score'))); story.append(Spacer(1,1.2*mm))
    story.append(PageBreak())

    # Transits
    from astro_v8 import transit_snapshot
    tr=transit_snapshot(chart)
    story += _section('11. Current Transit Snapshot','Current sky overlay mapped to natal houses.')
    rows=[['Planet','Transit Sign','Natal House','Degree','Retrograde']]
    for p in tr.get('placements',[]): rows.append([p.get('planet'),p.get('sign'),p.get('house'),f"{p.get('degree',p.get('degree_in_sign',0))}", 'Yes' if p.get('retrograde') else 'No'])
    story.append(_tbl(rows,widths=[28*mm,32*mm,24*mm,28*mm,30*mm],font=7.2)); story.append(Spacer(1,5*mm))
    story.append(Paragraph('Transit interpretation is used mainly for timing activation. A natal promise is not considered “created” by a transit alone.',S['quote'])); story.append(PageBreak())

    # Prediction domains two pages
    doms=fp.get('domains') or []
    for i in (0,8):
        story += _section(f'12. Full Predictions - Domains {i+1}-{min(i+8,len(doms))}','Prediction + support + caution + practical verification.')
        for d in doms[i:i+8]:
            story.append(Paragraph(f'<b>{_esc(d.get("label"))}</b> • {_esc(d.get("current_score"))}/100 • {_esc(d.get("band"))}',S['h2']))
            story.append(Paragraph(_esc(d.get('narrative','')),S['body']))
            def _evtxt(v):
                if isinstance(v,list):
                    parts=[]
                    for z in v:
                        if isinstance(z,dict):
                            parts.append(str(z.get('text') or z.get('label') or z.get('evidence') or z))
                        else: parts.append(str(z))
                    return '; '.join(parts)
                return str(v or '')
            sup=_evtxt(d.get('supporting_evidence') or d.get('support') or [])
            cau=_evtxt(d.get('caution_evidence') or d.get('caution') or [])
            story.append(Paragraph(f"<b>Support:</b> {_esc(sup or 'multi-factor chart support')}<br/><b>Caution:</b> {_esc(cau or 'verify with timing and real-life context')}<br/><b>Practical lens:</b> {_esc(d.get('practical',''))}",S['small']))
            story.append(Spacer(1,2*mm))
        story.append(PageBreak())

    # 12 month forecast 6 per page
    months=fp.get('next_12_months') or []
    for i in (0,6):
        story += _section(f'13. 12-Month Forecast - {months[i].get("label","") if len(months)>i else ""} onward','Every month has actual top/watch areas; no blank filler pages.')
        rows=[['Month','Top 1','Top 2','Top 3','Watch']]
        for m in months[i:i+6]:
            topm=m.get('top') or []; watchm=m.get('watch') or []
            rows.append([m.get('label'),*(f"{x.get('label')} {x.get('score'):.1f}" for x in (topm+[{}, {}, {}])[:3]),', '.join(f"{x.get('label')} {x.get('score'):.1f}" for x in watchm[:2])])
        story.append(_tbl(rows,widths=[22*mm,34*mm,34*mm,34*mm,43*mm],font=6.1)); story.append(Spacer(1,4*mm))
        for m in months[i:i+6]:
            topm=m.get('top') or []; watchm=m.get('watch') or []
            story.append(Paragraph(f"<b>{_esc(m.get('label'))}</b>: strongest emphasis - {_esc(', '.join(x.get('label','') for x in topm[:3]))}; watch/verify - {_esc(', '.join(x.get('label','') for x in watchm[:2]))}.",S['body']))
        story.append(PageBreak())

    # 5-year + Event Radar
    from enterprise_v18 import event_radar, astro_council, source_conflict_viewer
    story += _section('14. 5-Year Roadmap & Event Radar','Year-level emphasis plus top event-support windows.')
    rows=[['Year','Stronger Areas','Watch Areas']]
    for y in ny[:5]: rows.append([y.get('year'),', '.join(x.get('label',str(x)) for x in (y.get('top') or [])[:3]),', '.join(x.get('label',str(x)) for x in (y.get('watch') or [])[:2])])
    story.append(_tbl(rows,widths=[20*mm,82*mm,62*mm],font=7)); story.append(Spacer(1,5*mm))
    er=event_radar(chart,5); erows=[['Year','Window','Score','Band']]
    for e in er.get('top_windows',[])[:12]: erows.append([e.get('year'),e.get('label'),f"{e.get('score')}/100",e.get('band')])
    story.append(Paragraph('<b>Event Radar</b>',S['h2'])); story.append(_tbl(erows,widths=[18*mm,80*mm,28*mm,42*mm],font=6.8)); story.append(PageBreak())

    # Lal Kitab placement analysis
    story += _section('15. Lal Kitab Planet-by-House Analysis','Placement-first interpretation with the software rule profile shown explicitly.')
    placements=chart.get('placements') or []
    rows=[['Planet','Lal Kitab House','Score','Status']]
    for p in placements: rows.append([p.get('planet'),p.get('house'),p.get('strength',p.get('score','—')),p.get('status',', '.join(p.get('flags') or []))])
    story.append(_tbl(rows,widths=[30*mm,33*mm,28*mm,70*mm],font=7)); story.append(Spacer(1,4*mm))
    for p in placements:
        story.append(Paragraph(f"<b>{_esc(p.get('planet'))} in H{_esc(p.get('house'))}</b>: {_esc(p.get('status') or ', '.join(p.get('flags') or []) or 'standard placement')}. Read through the selected Lal Kitab profile and cross-check against the Vedic timing layer before using a remedy.",S['body']))
    story.append(PageBreak())

    # Remedies
    plan=chart.get('remedy_plan') or {}
    story += _section('16. Priority Remedies','Only a small number of chart-relevant remedies are surfaced first; the large vault remains searchable in software.')
    prim=plan.get('primary') or []
    for idx,r in enumerate(prim[:3],1):
        data=[[f'Priority {idx}',r.get('planet','')],['Action',r.get('action','')],['Why selected',r.get('why_selected','')],['Duration / review',r.get('duration','43 days')],['Safety',r.get('safety','Use only low-risk, lawful, non-harmful variants; avoid replacing professional care.')]]
        tb=_tbl(data,widths=[38*mm,124*mm],header=False,font=7.5); tb.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),PALE),('TEXTCOLOR',(0,0),(0,-1),DARK_GOLD),('BOX',(0,0),(-1,-1),0.7,GOLD)])); story.append(tb); story.append(Spacer(1,5*mm))
    story.append(Paragraph('The report does not recommend wildlife products, pollution, animal harm, dangerous ingestion, or medical substitution. Source-tagged traditional references can be shown separately from recommended low-risk actions.',S['quote'])); story.append(PageBreak())

    # Dosha research
    from sumitacharya_v12 import dosha_research_scanner
    dr=dosha_research_scanner(chart)
    story += _section('17. Dosha Research','Conservative screening - not fear-based diagnosis.')
    flags=dr.get('flags') or []
    rows=[['Indicator','Status','Evidence']]
    for x in flags[:10]: rows.append([x.get('label'),x.get('status'),'; '.join(x.get('evidence') or [])])
    story.append(_tbl(rows,widths=[45*mm,34*mm,83*mm],font=6.8)); story.append(Spacer(1,5*mm)); story.append(Paragraph('A dosha flag should be interpreted only after checking chart strength, cancellation/mitigation logic and active timing. The report intentionally avoids deterministic fear language.',S['quote'])); story.append(PageBreak())

    # Shadbala research
    sh=shadbala_research(chart)
    story += _section('18. Shad Bala Research Index','Six-component software research index. It is explicitly not claimed as classical Virupa/Rupa Shadbala.')
    rows=[['Planet','Index','Sthana','Dig','Kala','Cheshta','Naisargika','Drik']]
    for r in sh.get('rows',[]):
        cp=r.get('components') or {}; rows.append([r.get('planet'),r.get('index'),cp.get('sthana'),cp.get('dig'),cp.get('kala'),cp.get('cheshta'),cp.get('naisargika'),cp.get('drik')])
    story.append(_tbl(rows,widths=[24*mm,18*mm,20*mm,18*mm,18*mm,20*mm,25*mm,18*mm],font=6.5)); story.append(Spacer(1,5*mm))
    for r in sorted(sh.get('rows',[]),key=lambda x:x.get('index',0),reverse=True): story.append(ScoreBar(r.get('planet'),r.get('index'),width=120*mm)); story.append(Spacer(1,1*mm))
    story.append(PageBreak())

    # Vargas 4 pages
    vg=shodashavarga_full(chart); keys=list(vg.get('charts',{}).keys())
    for page_i in range(0,len(keys),4):
        story += _section('19. Shodashvarga Charts', 'Actual divisional charts - not repeated placeholder paragraphs.')
        group=keys[page_i:page_i+4]; cells=[]
        for k in range(0,len(group),2):
            row=[]
            for key in group[k:k+2]:
                obj=vg['charts'][key]; houses=obj.get('houses') if isinstance(obj,dict) else obj
                row.append(NorthIndianChart(houses,68*mm,68*mm,key))
            while len(row)<2: row.append('')
            cells.append(row)
        t=Table(cells,colWidths=[82*mm,82*mm],rowHeights=[80*mm]*len(cells)); t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('ALIGN',(0,0),(-1,-1),'CENTER')])); story.append(t); story.append(PageBreak())

    # Luck chain
    from vashist_v11 import luck_chain
    lc=luck_chain(chart,25)
    story += _section('20. 25-Year Luck Chain','Independent software visualization; not a reproduction of any practitioner’s proprietary algorithm.')
    ys=lc.get('years') or []
    rows=[['Year','Score','Band','Momentum','State']]
    for x in ys: rows.append([x.get('year'),x.get('score'),x.get('band'),x.get('momentum',''),x.get('chain_state','')])
    story.append(_tbl(rows,widths=[22*mm,22*mm,45*mm,36*mm,39*mm],font=6.4)); story.append(PageBreak())

    # Source compare / council
    ac=astro_council(chart); sc=source_conflict_viewer(chart,5)
    story += _section('21. Source Comparison & Astro Council','Independent layers are shown side-by-side so disagreement is not hidden.')
    arows=[['Agent','Score','Stance','Why']]
    for a in ac.get('agents',[]): arows.append([a.get('agent'),a.get('score'),a.get('stance'),a.get('why')])
    story.append(_tbl(arows,widths=[42*mm,20*mm,32*mm,68*mm],font=6.5)); story.append(Spacer(1,5*mm))
    srows=[['Domain','Core','GD Vashist public layer','Sumitacharya public layer','Spread']]
    for r in (sc.get('rows') or [])[:10]: srows.append([r.get('label'),r.get('core'),r.get('vashist_public_layer'),r.get('sumitacharya_public_layer'),r.get('spread')])
    story.append(_tbl(srows,widths=[48*mm,22*mm,38*mm,38*mm,20*mm],font=6.3)); story.append(PageBreak())

    # Conclusion
    story += _section('22. Executive Summary & Reading Protocol','A concise closing page designed for consultation and print.')
    strongest=fp.get('strongest') or []; watch=fp.get('watch') or []
    story.append(Paragraph(f"<b>Strongest current areas:</b> {_esc(', '.join(x.get('label','') for x in strongest[:5]))}.",S['body']))
    story.append(Paragraph(f"<b>Watch / verify:</b> {_esc(', '.join(x.get('label','') for x in watch[:5]))}.",S['body']))
    if dasha.get('active_chain'):
        chain_txt=' → '.join(f"{x.get('lord')} ({x.get('level')})" for x in dasha.get('active_chain'))
        story.append(Paragraph(f"<b>Active Dasha chain:</b> {_esc(chain_txt)}.",S['body']))
    story.append(Paragraph('<b>How to use this report</b>',S['h2']))
    story.append(Paragraph('1) Verify birth details and chart first. 2) Read natal promise before timing. 3) Use Dasha + transit to narrow windows. 4) Read supportive and caution evidence together. 5) Use only a small number of safe remedies. 6) Log outcomes so future consultations can be calibrated.',S['body']))
    story.append(Spacer(1,5*mm)); story.append(Paragraph('This report is an original software-generated interpretation. Public practitioner material is source-tagged and paraphrased; proprietary reports, books and transcripts are not reproduced.',S['quote']))
    return story


def build_professional_pdf(chart:dict, asset_dir=None)->bytes:
    buf=io.BytesIO(); prof=chart.get('profile') or {}; name=prof.get('name','Client')
    doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=15*mm,leftMargin=15*mm,topMargin=18*mm,bottomMargin=16*mm,title=f'Lal Kitab AI PRO - {name}')
    story=_build(chart,asset_dir=asset_dir)
    doc.build(story,onFirstPage=lambda c,d:None,onLaterPages=lambda c,d:_header_footer(c,d,name))
    return buf.getvalue()
