# V19.3.2 — Persistent Prescription OS

Cumulative upgrade on V19.3.1. No calculation or source-grounding downgrade.

## Added / hardened
- PostgreSQL via `DATABASE_URL`; SQLite remains local-development fallback.
- Safe schema migration for existing V19.3.1 databases.
- Stable `client_uuid` plus deterministic `profile_key` deduplication.
- Unique indexes prevent duplicate cloud profiles.
- Sync UI states: Cloud Saved, Syncing, Saved, Not Synced, Local Save.
- Three-attempt save retry with device cache retained only as recovery backup.
- `/api/storage-status` alias and richer `/api/health` persistence metadata.
- Cloud profile history remains backed by chart snapshots; existing remedy check-ins, outcomes, follow-ups, consultations, favorites, appointments and payments preserved.

## Regression lock
Golden Chart calculation logic was not intentionally changed. V19.3.1 source-grounding and Upay Prescription 3.1 remain intact.
