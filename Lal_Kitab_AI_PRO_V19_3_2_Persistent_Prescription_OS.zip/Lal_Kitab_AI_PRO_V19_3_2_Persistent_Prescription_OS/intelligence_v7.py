from __future__ import annotations

"""V7 command-center intelligence.

These functions summarize existing calculated/reference layers into transparent
planning views. Scores are symbolic software indexes, not probabilities and not
substitutes for medical, legal, financial, relationship or safety-critical advice.
"""

from datetime import datetime
from typing import Dict, List, Optional

from prediction_pro import forecast_year, event_windows_for_year, DOMAIN_RULES
from intelligence_v6 import prediction_consensus
from remedies import remedy_priority_plan


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def _base_domains(chart: Dict) -> Dict[str, Dict]:
    return {r.get("key"): r for r in chart.get("predictions", []) if r.get("key")}


def _avg(values: List[float], default: float = 50.0) -> float:
    vals = [float(v) for v in values if v is not None]
    return round(sum(vals) / len(vals), 1) if vals else default


SCENARIOS = {
    "job_change": {
        "label": "Job / Role Change",
        "domains": {"career": 0.34, "reputation": 0.18, "leadership": 0.16, "discipline": 0.16, "decision_quality": 0.16},
        "checks": ["Role scope and reporting line", "Compensation and stability", "Skill/reputation upside", "Exit and notice terms"],
    },
    "business_launch": {
        "label": "Start / Expand Business",
        "domains": {"business": 0.30, "money": 0.20, "network": 0.15, "discipline": 0.15, "decision_quality": 0.20},
        "checks": ["Demand validation", "Margins and working capital", "Contracts and partner incentives", "Downside/exit plan"],
    },
    "property": {
        "label": "Property Purchase / Move",
        "domains": {"property": 0.34, "money": 0.22, "family": 0.16, "discipline": 0.12, "decision_quality": 0.16},
        "checks": ["Title/legal verification", "Affordability and liquidity", "Inspection and location", "Family requirements"],
    },
    "foreign_move": {
        "label": "Foreign Move / Long Travel",
        "domains": {"travel_foreign": 0.34, "career": 0.18, "money": 0.16, "network": 0.14, "decision_quality": 0.18},
        "checks": ["Visa/legal eligibility", "Income and runway", "Purpose and career value", "Housing/support network"],
    },
    "partnership": {
        "label": "Marriage / Partnership Decision",
        "domains": {"relationships": 0.30, "communication": 0.20, "family": 0.15, "discipline": 0.12, "decision_quality": 0.23},
        "checks": ["Consent and expectations", "Money and family boundaries", "Conflict/communication style", "Real-world compatibility"],
    },
    "study": {
        "label": "Study / Certification",
        "domains": {"learning": 0.34, "discipline": 0.24, "career": 0.16, "reputation": 0.10, "decision_quality": 0.16},
        "checks": ["Career leverage", "Time/cost commitment", "Accreditation quality", "Practice plan"],
    },
    "creative_launch": {
        "label": "Creative / Public Launch",
        "domains": {"creativity": 0.30, "leadership": 0.18, "reputation": 0.20, "network": 0.16, "discipline": 0.16},
        "checks": ["Work readiness", "Claim accuracy", "Distribution plan", "Feedback loop"],
    },
    "brand_visibility": {
        "label": "Brand / Visibility Push",
        "domains": {"reputation": 0.28, "leadership": 0.20, "network": 0.20, "communication": 0.16, "creativity": 0.16},
        "checks": ["Message clarity", "Proof/credibility", "Audience fit", "Consistency"],
    },
    "consolidate": {
        "label": "Consolidate / Reduce Pressure",
        "domains": {"discipline": 0.27, "money": 0.18, "inner_growth": 0.16, "decision_quality": 0.24, "family": 0.15},
        "checks": ["Cut low-value commitments", "Protect cash/time", "Document priorities", "Review support system"],
    },
}


def scenario_compare(chart: Dict, year: Optional[int] = None, scenario_keys: Optional[List[str]] = None) -> Dict:
    year = int(year or datetime.now().year)
    fy = forecast_year(chart, year)
    domains = fy.get("domains", {})
    keys = scenario_keys or list(SCENARIOS.keys())
    rows = []
    for key in keys:
        rule = SCENARIOS.get(key)
        if not rule:
            continue
        score = 0.0
        evidence = []
        for dk, weight in rule["domains"].items():
            d = domains.get(dk, {"score": 50, "label": dk})
            val = float(d.get("score", 50))
            score += val * weight
            evidence.append({"key": dk, "label": d.get("label", dk), "score": round(val, 1), "weight": weight})
        score = _clamp(score)
        if score >= 68:
            band = "Stronger symbolic readiness — still verify facts"
        elif score >= 56:
            band = "Constructive / workable with verification"
        elif score >= 45:
            band = "Mixed — strengthen weak fundamentals first"
        else:
            band = "Higher-friction — avoid forcing a decision from astrology"
        rows.append({
            "key": key,
            "label": rule["label"],
            "index": round(score, 1),
            "band": band,
            "evidence": sorted(evidence, key=lambda x: x["weight"], reverse=True),
            "real_world_checks": rule["checks"],
        })
    rows.sort(key=lambda x: x["index"], reverse=True)
    return {
        "year": year,
        "scenarios": rows,
        "best_symbolic_fit": rows[:3],
        "needs_more_management": list(reversed(rows[-3:])),
        "note": "Scenario indexes compare software evidence layers. They are not probabilities and should never replace contracts, due diligence, consent, qualified advice or safety checks.",
    }


def year_compare(chart: Dict, year_a: int, year_b: int) -> Dict:
    a = forecast_year(chart, int(year_a))
    b = forecast_year(chart, int(year_b))
    rows = []
    for key, rule in DOMAIN_RULES.items():
        av = float(a["domains"].get(key, {}).get("score", 50))
        bv = float(b["domains"].get(key, {}).get("score", 50))
        rows.append({"key": key, "label": rule["label"], "year_a": round(av,1), "year_b": round(bv,1), "delta": round(bv-av,1)})
    return {
        "year_a": int(year_a), "year_b": int(year_b),
        "improving": sorted(rows, key=lambda x: x["delta"], reverse=True)[:5],
        "cooling": sorted(rows, key=lambda x: x["delta"])[:5],
        "all": sorted(rows, key=lambda x: abs(x["delta"]), reverse=True),
        "note": "Delta shows change in the software emphasis index between two annual layers, not a guaranteed improvement or decline in real life.",
    }


def consultation_brief(chart: Dict, year: Optional[int] = None) -> Dict:
    year = int(year or datetime.now().year)
    fy = forecast_year(chart, year)
    ev = event_windows_for_year(chart, year)
    con = prediction_consensus(chart, year)
    top = fy.get("top", [])[:4]
    watch = fy.get("watch", [])[:4]
    questions = []
    for x in ev.get("top_windows", [])[:3]:
        questions.append(x.get("verification_question"))
    for x in ev.get("management_flags", [])[:2]:
        questions.append(x.get("verification_question"))
    questions = [q for q in questions if q]
    return {
        "year": year,
        "opening_summary": f"Review {len(fy.get('domains',{}))} life areas with strongest emphasis in {', '.join(x['label'] for x in top[:2]) or 'mixed areas'}, while explicitly checking {', '.join(x['label'] for x in watch[:2]) or 'watch areas'}.",
        "stronger_areas": top,
        "watch_areas": watch,
        "consultation_questions": questions,
        "contradictions": con.get("contradictions", [])[:5],
        "practical_close": [
            "Separate chart observation from source-specific rule and interpretation.",
            "Record which claims the client can verify from past/current facts.",
            "Choose no more than 1–3 remedies at a time and review adherence/outcome.",
            "Downgrade confidence when birth time or source-school rules are uncertain.",
        ],
    }


def command_center(chart: Dict, year: Optional[int] = None) -> Dict:
    year = int(year or datetime.now().year)
    domains = _base_domains(chart)
    consensus = prediction_consensus(chart, year)
    events = event_windows_for_year(chart, year)
    scenarios = scenario_compare(chart, year)
    remedies = chart.get("remedy_plan") or remedy_priority_plan(chart, primary_limit=3)
    next_year = forecast_year(chart, year + 1)

    domain_scores = [float(x.get("score", 50)) for x in domains.values()]
    confs = [float(x.get("confidence", 50)) for x in domains.values()]
    con_rows = consensus.get("all", [])
    consensus_index = _avg([x.get("consensus", 50) for x in con_rows])
    contradiction_count = len(consensus.get("contradictions", []))
    avg_domain = _avg(domain_scores)
    avg_conf = _avg(confs)

    strongest = sorted(domains.values(), key=lambda x: float(x.get("score", 50)), reverse=True)[:4]
    watch = sorted(domains.values(), key=lambda x: float(x.get("score", 50)))[:4]
    next_scores = next_year.get("scores", {})
    momentum = []
    for key, row in domains.items():
        now = float(row.get("score", 50)); nxt = float(next_scores.get(key, now))
        momentum.append({"key": key, "label": row.get("label", key), "current": round(now,1), "next": round(nxt,1), "delta": round(nxt-now,1)})

    flags = []
    for r in watch:
        if float(r.get("score", 50)) < 42:
            flags.append({"level":"attention","title":r.get("label"),"detail":f"Lower symbolic emphasis ({r.get('score')}/100). Strengthen practical fundamentals before high-stakes action."})
    for c in consensus.get("contradictions", [])[:3]:
        flags.append({"level":"mixed","title":c.get("label"),"detail":"Supporting and caution layers both present; verify instead of forcing a single conclusion."})
    if not flags:
        flags.append({"level":"stable","title":"No major engine conflict","detail":"Current software layers do not show a severe low-score or high-priority contradiction flag."})

    birth_time = (chart.get("profile") or {}).get("birth_time")
    placements = chart.get("placements", [])
    data_integrity = round(_clamp(55 + min(25, len(placements)*2.5) + (12 if birth_time else -10) + (8 if (chart.get('profile') or {}).get('rule_profile') else 0)), 1)

    return {
        "year": year,
        "client": (chart.get("profile") or {}).get("name", "Current chart"),
        "kpis": {
            "domain_balance": avg_domain,
            "evidence_coverage": avg_conf,
            "consensus_index": consensus_index,
            "data_integrity": data_integrity,
            "contradictions": contradiction_count,
            "core_remedies": len(remedies.get("primary", [])),
        },
        "strongest": strongest,
        "watch": watch,
        "top_event_windows": events.get("top_windows", [])[:4],
        "management_flags": events.get("management_flags", [])[:3],
        "scenario_spotlight": scenarios.get("scenarios", [])[:5],
        "momentum_up": sorted(momentum, key=lambda x: x["delta"], reverse=True)[:4],
        "momentum_down": sorted(momentum, key=lambda x: x["delta"])[:4],
        "attention_flags": flags[:7],
        "remedy_protocol": {
            "primary": remedies.get("primary", [])[:3],
            "conflicts": remedies.get("conflicts", [])[:5],
            "rules": remedies.get("protocol_rules", [])[:4],
        },
        "current_cycle": (chart.get("timing") or {}).get("house_cycle_36", {}),
        "method_note": "V7 Command Center summarizes existing calculated, traditional-reference and interpretive layers. It does not turn astrology into objective risk, probability or certainty.",
    }
