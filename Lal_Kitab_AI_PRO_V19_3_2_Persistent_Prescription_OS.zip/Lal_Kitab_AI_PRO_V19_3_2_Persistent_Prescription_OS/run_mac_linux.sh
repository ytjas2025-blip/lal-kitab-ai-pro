#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt
( command -v xdg-open >/dev/null && xdg-open http://127.0.0.1:8000 >/dev/null 2>&1 ) || ( command -v open >/dev/null && open http://127.0.0.1:8000 ) || true
python3 app.py
