# V19.2.4 — Simple Power Mode

- Rebuilt Remedies as a 5-second action-first experience.
- Added What Should I Do Today? Morning / Day / Evening cards.
- Replaced confusing relevance numbers with High / Medium / Low priority.
- Added exact Kya / Kaise / Kab / Kitne Din / Kyun / Avoid structure.
- Added problem-first Upay selector: Money, Career, Business, Relationship, Property, Travel, Calm, Spiritual.
- Added Done Today interaction and simple no-cost/low-cost-first guidance.
- Kept source-specific backend remedies available as optional details instead of exposing vague source language first.
- Existing V19.2.3 15-day radar, calculations, intelligence and regression logic retained.
