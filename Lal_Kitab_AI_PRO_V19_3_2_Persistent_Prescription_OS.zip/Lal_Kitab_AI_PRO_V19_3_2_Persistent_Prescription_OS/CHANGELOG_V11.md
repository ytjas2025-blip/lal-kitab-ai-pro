# V11 — Vashist Source Intelligence Edition

## Remedy Intelligence
- Remedy vault expanded from **2,700 to 3,600** indexed records.
- Added exactly **900 GD Vashist/Astroscience public-source-aware cards**.
- All source-aware cards are paraphrased and safety-normalized; paid books/reports and video transcripts are not copied.
- Official source URLs stored on relevant remedy cards.
- Added chart-ranked **GD Vashist Source Upay Vault**.
- Added source-governance rules, safety override, conflict/stacking protection, and 14/43-day verification.

## GD Vashist / Astroscience Source Lab
- Public source registry: official remedies hub, 9 planet-by-house remedy pages, Vashist principle article, app/category pages, official YouTube channel and selected public videos.
- House-first / ascendant-aware research presentation inspired by public Vashist Jyotish descriptions.
- Explicit non-affiliation / non-proprietary-clone boundary.

## New Prediction Features
- **Luck Meter**.
- **Kismat Ki Saankdi — 25-year Luck Chain**.
- **2 / 5 / 7 / 10 / 25 year Category Prediction Files**.
- Categories: wealth, marriage/relationship, wellbeing/routine, children/family, occupation, business, property/vehicle, foreign/travel, education, public status.
- **Problem Detector** ranking planet + house attention without pretending to diagnose real-world problems.
- Best/watch years and good-time / caution-window indexes.

## Existing V10 depth retained
- Mahadasha → Antardasha → Pratyantar → Sookshma.
- 16 detailed life-domain predictions.
- 12-month focus and 5-year detailed studio.
- 16 Varga, Yogini, Muhurta, transit wheel, rule graph, compatibility, rectification, AI/voice, CRM and PDF reports.

## Source/Copyright Boundary
V11 links to public sources and creates original summaries/software protocols. It does not reproduce proprietary Vashist Jyotish laws, paid category files, books, or full YouTube transcripts.
