# V19.2.3 — Actionable Astro Briefing + 15-Day Sudden Radar
- Replaces score-heavy home with My Astro Briefing.
- Adds date-specific 15-day Sudden Situation Radar.
- Near-term prominent watches require transit agreement with natal structure; active Vimshottari lords add timing support.
- Shows Top 3 predictions, Top 3 upay, one priority watch, opportunities, and a daily 15-day timeline.
- Sensitive situations remain non-deterministic and include practical-first guidance.
- Existing V19.2.2 features retained.
