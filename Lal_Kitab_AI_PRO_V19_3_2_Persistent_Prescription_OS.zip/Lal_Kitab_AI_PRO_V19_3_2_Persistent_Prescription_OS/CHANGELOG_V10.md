# V10 — Prediction Intelligence Edition

## Prediction depth
- Added full 4-level Vimshottari hierarchy: Mahadasha, Antardasha, Pratyantar and Sookshma.
- Added current active chain with dates, Lal Kitab house, natal index and planet-theme explanation.
- Added Antardasha / Pratyantar / Sookshma tables for the active hierarchy.
- Added Full Prediction Studio combining the existing 16-domain engine with the active Dasha chain.
- Added detailed narrative per domain with support, caution, Dasha contribution and practical verification guidance.
- Added next-12-month focus ribbon using annual index + mid-month sidereal transit activation.
- Added next-5-year prediction rail with annual focus, 36-year house cycle and event-theme windows.
- Added top remedy protocol to the prediction page.
- Added V10 Dasha and detailed prediction sections to the PDF report.

## Method boundary
Vimshottari is a Vedic auxiliary timing system and remains labelled separately from Lal Kitab fixed-house rules. Dasha subdivision dates use the common proportional 120-year framework with mean-year conversion for software scheduling. Prediction scores are interpretive emphasis indexes, not event probabilities or guaranteed outcomes.
