# V19.2.6 — Cloud Vault + Client 360

- Permanent PostgreSQL-ready data layer retained from V19.2.5.
- Duplicate Guard: exact same name + DOB + birth time + city updates one cloud profile instead of creating repeated records.
- Favorite/star Kundlis and custom client tags.
- Search saved Kundlis by name, city, or tags.
- Client 360: active remedy programs, notes, follow-ups, prediction outcomes and consultations in one view.
- Automatic chart snapshots on save and recalculation.
- One-click full cloud backup export as JSON.
- Cloud/local persistence status remains visible in the UI.
- Existing calculations, Simple Power Mode, Predictions, Upay and 15-Day Sudden Radar retained.
