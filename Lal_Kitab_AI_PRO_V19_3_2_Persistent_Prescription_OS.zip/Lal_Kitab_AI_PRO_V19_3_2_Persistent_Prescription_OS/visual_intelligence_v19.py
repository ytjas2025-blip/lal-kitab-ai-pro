from typing import Dict

def visual_intelligence(chart:Dict)->Dict:
    ps=chart.get('placements',[])
    house_counts={h:0 for h in range(1,13)}
    for p in ps: house_counts[int(p.get('house',1))]+=1
    return {
      'graha_power_bars':[{'planet':p.get('planet'),'score':p.get('score',50),'house':p.get('house'),'sign':p.get('sign')} for p in ps],
      'house_activation_bars':[{'house':h,'natal_occupants':n} for h,n in house_counts.items()],
      'visual_modules':['Animated Kundli Drishti','Drishti Matrix','Planet Relationship Web','House Lord Network','Yoga Galaxy','Dosha X-Ray','Dasha Waterfall','Life Timeline','Varga Matrix','Ashtakavarga Heatmap','Sade Sati Cinema','Astro Time Machine','Prediction MRI','Astroverse 360','3D Graha Intelligence','3D Bhava Towers','Astro Terrain','Evidence Sankey','Critical Alert Timeline'],
      'ui':{'body_px':18,'card_px':20,'value_px':30,'section_heading_px':34,'hero_px':48,'font_modes':['Large','XL','XXL'],'motion_modes':['Off','Subtle','Cinematic'],'performance_mode':True,'reduced_motion':True},
      'note':'3D/animation modules are visualization layers; deterministic calculation remains the source of truth.'
    }
