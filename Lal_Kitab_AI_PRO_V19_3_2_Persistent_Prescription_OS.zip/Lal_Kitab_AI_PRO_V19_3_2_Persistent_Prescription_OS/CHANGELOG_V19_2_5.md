# V19.2.5 — Persistent Cloud Data

- Added PostgreSQL persistence via `DATABASE_URL`.
- SQLite remains a local/offline fallback only.
- Saved Kundlis, chart JSON (including predictions/upay/radar enrichment), remedy programs/check-ins, notes, outcome history, follow-ups, AI chat history, consultations, appointments and payments persist in PostgreSQL.
- Added `/api/storage/health` to expose Cloud Saved vs local fallback state.
- Added PostgreSQL schema with cascade-safe profile deletion and indexes.
- App version bumped to 19.2.5.

Important: Render free PostgreSQL instances may have provider expiry/plan limitations. For long-term production retention use a persistent paid database or external managed PostgreSQL and maintain backups.
