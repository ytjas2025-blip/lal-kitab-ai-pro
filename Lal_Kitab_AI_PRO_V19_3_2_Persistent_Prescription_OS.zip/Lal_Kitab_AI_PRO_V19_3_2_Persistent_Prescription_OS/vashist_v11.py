from __future__ import annotations

"""V11 source-aware Vashist/GD Vashist inspired research layer.

This module DOES NOT reproduce proprietary books, paid reports, or video transcripts.
It stores public-source metadata and builds original software synthesis from the
existing calculated chart, with explicit source labels and safety boundaries.
"""

from datetime import datetime
from typing import Dict, List, Optional

from prediction_pro import forecast_year, event_windows_for_year
from prediction_v10 import vimshottari_full

OFFICIAL_BASE = "https://www.astroscience.com"
OFFICIAL_CHANNEL = "https://youtube.com/@gurudevgdvashist"

PLANET_SOURCE_URLS = {
    "Sun": f"{OFFICIAL_BASE}/pages/sun-lal-kitab-remedies",
    "Moon": f"{OFFICIAL_BASE}/pages/moon-lal-kitab-remedies",
    "Mars": f"{OFFICIAL_BASE}/pages/mars-lal-kitab-remedies",
    "Mercury": f"{OFFICIAL_BASE}/pages/mercury-lal-kitab-remedies",
    "Jupiter": f"{OFFICIAL_BASE}/pages/jupiter-lal-kitab-remedies",
    "Venus": f"{OFFICIAL_BASE}/pages/venus-lal-kitab-remedies",
    "Saturn": f"{OFFICIAL_BASE}/pages/saturn-lal-kitab-remedies",
    "Rahu": f"{OFFICIAL_BASE}/pages/rahu-lal-kitab-remedies",
    "Ketu": f"{OFFICIAL_BASE}/pages/ketu-lal-kitab-remedies",
}

PUBLIC_SOURCE_LIBRARY = [
    {
        "id":"astro-remedies-hub","kind":"official_page","title":"Lal Kitab Remedies — 9 planets & problem-wise hub",
        "url":f"{OFFICIAL_BASE}/pages/lal-kitab-remedies",
        "themes":["9 planets","career","finance","marriage","health","education"],
        "note":"Public remedy overview; software stores paraphrased/safety-normalized cards, not a copy of the page."
    },
    {
        "id":"vashist-principle","kind":"official_page","title":"Lal Kitab Astrology Guide / Vashist Jyotish principle",
        "url":f"{OFFICIAL_BASE}/blogs/astro-blog/lal-kitab-astrology-remedies-foundational-principles",
        "themes":["house-first analysis","ascendant","personalized interpretation"],
        "note":"Used as methodology inspiration only; not an official implementation of proprietary rules."
    },
    {
        "id":"solution-horizons","kind":"official_page","title":"Get Solutions To All Your Life Problems",
        "url":f"{OFFICIAL_BASE}/pages/get-solutions-to-all-your-life-problems",
        "themes":["2 years","5 years","7 years","10 years","25 years","category predictions"],
        "note":"Used to shape V11 forecast horizon UI and category packs."
    },
    {
        "id":"app-features","kind":"official_page","title":"Astroscience App feature overview",
        "url":f"{OFFICIAL_BASE}/blogs/astro-blog/astroscience-app-ultimate-destinations-accurate-astrology-predictions-remedies",
        "themes":["Varshphal","category predictions","Luck Meter","Kismat Ki Saankdi"],
        "note":"V11 implements independently calculated research analogues with transparent method notes."
    },
    {
        "id":"vastu-house-map","kind":"official_page","title":"Lal Kitab + Vastu house-direction guidance",
        "url":f"{OFFICIAL_BASE}/blogs/learn-astrology-guide/learn-gurudev-how-improve-vaastu-house",
        "themes":["house directions","Vastu audit","Rahu example"],
        "note":"Used for an optional home-audit study layer. No structural or safety advice is automated."
    },
    {
        "id":"youtube-channel","kind":"official_youtube_channel","title":"Gurudev GD Vashist Astrologer — official YouTube channel",
        "url":OFFICIAL_CHANNEL,
        "themes":["Lal Kitab","remedies","classes","case discussions"],
        "note":"Channel link only. V11 does not scrape or reproduce transcripts."
    },
    {
        "id":"yt-jupiter-2026","kind":"official_youtube_video","title":"Brihaspati/Jupiter remedies conference video",
        "url":"https://www.youtube.com/watch?v=Jg3_BmvmYWA",
        "themes":["Jupiter","Mercury","Saturn","Rahu","Venus","house combinations"],
        "note":"Public description indexed; detailed spoken content is not copied."
    },
    {
        "id":"yt-venus-rahu","kind":"official_youtube_video","title":"Venus–Rahu case/remedy discussion",
        "url":"https://www.youtube.com/watch?v=p_DaTsZTDp8",
        "themes":["Venus","Rahu","relationship","money","wellbeing"],
        "note":"Public description indexed; no verbatim transcript ingestion."
    },
    {
        "id":"yt-shani-drishti","kind":"official_youtube_video","title":"Graha drishti, Shani and Lal Kitab remedies",
        "url":"https://www.youtube.com/watch?v=Lw37P6ZQEH4",
        "themes":["Shani","drishti","planet combinations","remedies"],
        "note":"Public description indexed for source discovery."
    },
    {
        "id":"yt-job","kind":"official_youtube_video","title":"Job-success Lal Kitab remedy discussion",
        "url":"https://www.youtube.com/watch?v=0PKNwbo_cmM",
        "themes":["job","career","remedies"],
        "note":"Public description indexed for career-source discovery."
    },
    {
        "id":"yt-vastu","kind":"official_youtube_video","title":"Lal Kitab and Vastu remedies lecture",
        "url":"https://www.youtube.com/watch?v=bX0VqAKsCgQ",
        "themes":["Lal Kitab remedies","Vastu","fortune"],
        "note":"Public description indexed; no transcript reproduction."
    },
    {
        "id":"yt-learning","kind":"official_youtube_video","title":"Lal Kitab class: job, money, yog and life categories",
        "url":"https://www.youtube.com/watch?v=iYbEfuvsGaw",
        "themes":["job","money","health themes","yog","classes"],
        "note":"Public description indexed for category mapping; not medical advice."
    },
    {
        "id":"yt-wealth","kind":"official_youtube_video","title":"Wealth and Lal Kitab remedies",
        "url":"https://www.youtube.com/watch?v=HyM5h2sPV8A",
        "themes":["wealth","money","planet effects","remedies"],
        "note":"Public video description indexed for wealth-source discovery."
    },
    {
        "id":"yt-marriage-delay","kind":"official_youtube_video","title":"Delay in marriage / marriage remedies",
        "url":"https://www.youtube.com/watch?v=hUN1rKDPJC0",
        "themes":["marriage","delay","relationship","remedies"],
        "note":"Public video description indexed for marriage-source discovery."
    },
    {
        "id":"yt-kids","kind":"official_youtube_video","title":"Astrology for kids / behaviour remedy discussion",
        "url":"https://www.youtube.com/watch?v=dZeJrh8EesU",
        "themes":["children","family","behaviour","remedies"],
        "note":"Public video description indexed. V11 does not make medical/developmental diagnoses about children."
    },
]

CATEGORY_MAP = {
    "wealth": {"label":"Wealth / Money", "domains":["money","business","network"], "event_labels":["income","business","money"]},
    "married_life": {"label":"Marriage / Relationship", "domains":["relationships","family"], "event_labels":["relationship","partnership","marriage"]},
    "wellbeing": {"label":"Wellbeing / Routine", "domains":["discipline","inner_growth","family"], "event_labels":["routine","wellbeing"]},
    "children_family": {"label":"Children / Family", "domains":["family","learning","relationships"], "event_labels":["family","education"]},
    "occupation": {"label":"Job / Occupation", "domains":["career","leadership","reputation"], "event_labels":["career","job","promotion"]},
    "business": {"label":"Business / Enterprise", "domains":["business","money","leadership","network"], "event_labels":["business","launch"]},
    "property_vehicle": {"label":"Property / Vehicle", "domains":["property","money"], "event_labels":["property","asset"]},
    "foreign": {"label":"Foreign / Travel", "domains":["travel_foreign","network","learning"], "event_labels":["foreign","travel","relocation"]},
    "education": {"label":"Education / Learning", "domains":["learning","creativity"], "event_labels":["education","study"]},
    "public_status": {"label":"Reputation / Public Status", "domains":["reputation","leadership","career"], "event_labels":["visibility","public"]},
}


def source_library() -> Dict:
    rows = list(PUBLIC_SOURCE_LIBRARY)
    for planet, url in PLANET_SOURCE_URLS.items():
        rows.append({
            "id":f"planet-{planet.lower()}","kind":"official_planet_page",
            "title":f"{planet} — Lal Kitab effects/remedies by house",
            "url":url,"themes":[planet,"12 houses","benefic/malefic","remedies"],
            "note":"V11 links this public source and uses independently paraphrased, safety-normalized remedy cards."
        })
    return {
        "sources": rows,
        "official_channel": OFFICIAL_CHANNEL,
        "planet_sources": PLANET_SOURCE_URLS,
        "boundary":"Source discovery/reference only. No paid book/report/video transcript is copied into the software.",
        "affiliation_note":"This software is not affiliated with, endorsed by, or an official product of Gurudev GD Vashist/Astroscience unless separately licensed."
    }


def _domain_score(fy: Dict, key: str) -> float:
    domains = fy.get("domains", {})
    row = domains.get(key) or {}
    try: return float(row.get("score", 50))
    except Exception: return 50.0


def category_year_score(chart: Dict, year: int, category: str) -> Dict:
    cfg = CATEGORY_MAP[category]
    fy = forecast_year(chart, year)
    scores = [_domain_score(fy, d) for d in cfg["domains"]]
    base = sum(scores) / max(1, len(scores))
    events = event_windows_for_year(chart, year)
    event_hits=[]
    for e in events.get("top_windows",[]) + events.get("windows",[]):
        blob=(str(e.get("key",""))+" "+str(e.get("label",""))).lower()
        if any(t in blob for t in cfg["event_labels"]):
            event_hits.append(e)
    if event_hits:
        base = base*0.86 + sum(float(x.get("score",50)) for x in event_hits[:3])/min(3,len(event_hits))*0.14
    score=round(max(0,min(100,base)),1)
    band = "Favourable emphasis" if score>=68 else "Supportive / workable" if score>=58 else "Mixed / verify" if score>=46 else "Higher-friction / protect basics"
    return {
        "year":year,"category":category,"label":cfg["label"],"score":score,"band":band,
        "domain_scores":[{"key":d,"score":round(_domain_score(fy,d),1)} for d in cfg["domains"]],
        "event_support":[{"label":e.get("label"),"score":e.get("score")} for e in event_hits[:3]],
        "house_cycle":fy.get("house_cycle"),"age_reference":fy.get("age_reference")
    }


def category_prediction_pack(chart: Dict, horizon: int=25) -> Dict:
    horizon=max(2,min(int(horizon),25))
    year0=datetime.now().year
    categories={}
    for key,cfg in CATEGORY_MAP.items():
        rows=[category_year_score(chart,y,key) for y in range(year0,year0+horizon)]
        best=sorted(rows,key=lambda x:x["score"],reverse=True)[:5]
        watch=sorted(rows,key=lambda x:x["score"])[:5]
        categories[key]={
            "label":cfg["label"],"current":rows[0],"years":rows,"best_years":best,"watch_years":watch,
            "good_time_threshold":68,"caution_threshold":46,
        }
    return {
        "start_year":year0,"horizon":horizon,"categories":categories,
        "supported_horizons":[2,5,7,10,25],
        "method_note":"Independent V11 category synthesis inspired by public Astroscience category/horizon descriptions. It does not reproduce proprietary Vashist Jyotish rules or paid category files.",
        "safety_note":"Wellbeing/children categories are non-medical and non-diagnostic; do not use them for pregnancy, disease, or treatment decisions."
    }


def luck_meter(chart: Dict, year: Optional[int]=None) -> Dict:
    y=year or datetime.now().year
    fy=forecast_year(chart,y)
    vals=[float(v.get("score",50)) for v in fy.get("domains",{}).values()]
    avg=sum(vals)/max(1,len(vals))
    cons=chart.get("prediction_consensus",{}) or {}
    consensus=float(cons.get("consensus_index",cons.get("score",50)) or 50)
    dasha=vimshottari_full(chart)
    chain=dasha.get("active_chain",[])
    ds=sum(float(x.get("natal_score",50)) * float(x.get("weight",1)) for x in chain)
    dw=sum(float(x.get("weight",1)) for x in chain) or 1
    dasha_score=ds/dw
    score=round(max(0,min(100,avg*0.58+consensus*0.17+dasha_score*0.25)),1)
    band="High support" if score>=70 else "Supportive" if score>=60 else "Mixed" if score>=48 else "Protective / slower"
    return {
        "year":y,"score":score,"band":band,"domain_average":round(avg,1),"consensus":round(consensus,1),"dasha_support":round(dasha_score,1),
        "strongest":sorted([{"key":k,"label":v.get("label",k),"score":v.get("score",50)} for k,v in fy.get("domains",{}).items()],key=lambda x:float(x["score"]),reverse=True)[:5],
        "watch":sorted([{"key":k,"label":v.get("label",k),"score":v.get("score",50)} for k,v in fy.get("domains",{}).items()],key=lambda x:float(x["score"]))[:5],
        "note":"Luck Meter is an interpretive software index, not a probability or guarantee of events."
    }


def luck_chain(chart: Dict, years: int=25) -> Dict:
    years=max(2,min(int(years),25)); y0=datetime.now().year
    rows=[]
    for y in range(y0,y0+years):
        lm=luck_meter(chart,y)
        rows.append({"year":y,"score":lm["score"],"band":lm["band"],"top":lm["strongest"][:2],"watch":lm["watch"][:2]})
    # local momentum / chain relation
    for i,r in enumerate(rows):
        prev=rows[i-1]["score"] if i else r["score"]
        nxt=rows[i+1]["score"] if i+1<len(rows) else r["score"]
        r["momentum"]=round((nxt-prev)/2,1)
        r["chain_state"]="Rising" if r["momentum"]>=3 else "Cooling" if r["momentum"]<=-3 else "Stable / mixed"
    return {
        "years":rows,"best":sorted(rows,key=lambda x:x["score"],reverse=True)[:5],"watch":sorted(rows,key=lambda x:x["score"])[:5],
        "method_note":"V11 Kismat Ki Saankdi is an independently computed 25-year chain-style visualization using domain, consensus and Dasha support. It is not the proprietary Astroscience algorithm."
    }


def problem_detector(chart: Dict) -> Dict:
    house_meanings={h.get("house"):h.get("meaning","") for h in chart.get("houses",[])}
    rows=[]
    for p in chart.get("placements",[]):
        score=float(p.get("score",50)); severity=max(0,70-score)
        status=p.get("status") or []
        if any("Neecha" in str(s) for s in status): severity+=18
        if any("Soya" in str(s) for s in status): severity+=10
        if p.get("retrograde"): severity+=4
        rows.append({
            "planet":p.get("planet"),"house":p.get("house"),"chart_score":score,"attention_score":round(min(100,severity),1),
            "status":status,"house_theme":house_meanings.get(p.get("house"),""),
            "source_url":PLANET_SOURCE_URLS.get(p.get("planet")),
            "why":f"Low/conditional chart strength plus status flags in House {p.get('house')}. Review whole-chart evidence before choosing remedies."
        })
    rows=sorted(rows,key=lambda x:x["attention_score"],reverse=True)
    return {
        "top_attention":rows[:8],"all":rows,
        "note":"Problem Detector is a ranking aid, not a diagnosis. It must not be used to diagnose disease, blame people, or guarantee that one planet causes a real-world problem."
    }


def vashist_dashboard(chart: Dict, horizon: int=25) -> Dict:
    return {
        "luck_meter":luck_meter(chart),
        "luck_chain":luck_chain(chart,horizon),
        "categories":category_prediction_pack(chart,horizon),
        "problem_detector":problem_detector(chart),
        "source_library":source_library(),
        "feature_note":"House-first / ascendant-aware research presentation inspired by public Vashist Jyotish descriptions; calculations and weights are this software's own transparent synthesis."
    }
