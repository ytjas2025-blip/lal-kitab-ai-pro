from __future__ import annotations

"""V6 cross-chart and audit intelligence.

These tools are deliberately framed as explainable symbolic comparison helpers.
They do not turn astrology into probabilities, guarantees, diagnoses, or objective
measures of relationship quality.
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional

from engine import chart_payload
from prediction_pro import enrich_chart, forecast_year, DOMAIN_RULES


MODE_DIMENSIONS = {
    "relationship": [
        ("relationships", 1.7), ("family", 1.0), ("money", 0.55),
        ("communication", 1.15), ("discipline", 0.55), ("inner_growth", 0.35),
    ],
    "business": [
        ("business", 1.7), ("money", 1.25), ("career", 1.0),
        ("network", 0.9), ("discipline", 1.0), ("communication", 1.15),
    ],
    "family": [
        ("family", 1.7), ("relationships", 1.0), ("communication", 1.15),
        ("property", 0.65), ("inner_growth", 0.55), ("discipline", 0.45),
    ],
}

# V6 adds two synthesis-only dimensions from already-computed domain evidence.
SYNTHETIC_LABELS = {
    "communication": "Communication & Coordination",
    "decision_quality": "Decision Quality & Verification",
}


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def _domain_scores(chart: Dict) -> Dict[str, float]:
    rows = chart.get("predictions") or []
    out = {r.get("key"): float(r.get("score", 50)) for r in rows if r.get("key")}
    # Communication is a transparent synthesis of domains that already encode
    # Mercury/3rd/7th/11th-house style evidence in the V6 scoring model.
    if "communication" not in out:
        out["communication"] = round(
            0.35 * out.get("business", 50)
            + 0.25 * out.get("relationships", 50)
            + 0.20 * out.get("network", 50)
            + 0.20 * out.get("learning", 50),
            1,
        )
    if "decision_quality" not in out:
        out["decision_quality"] = round(
            0.30 * out.get("discipline", 50)
            + 0.25 * out.get("learning", 50)
            + 0.20 * out.get("career", 50)
            + 0.15 * out.get("money", 50)
            + 0.10 * out.get("inner_growth", 50),
            1,
        )
    return out


def _planet_house_map(chart: Dict) -> Dict[str, int]:
    return {p.get("planet"): int(p.get("house")) for p in chart.get("placements", []) if p.get("planet") and p.get("house")}


def _planet_strength_map(chart: Dict) -> Dict[str, float]:
    return {p.get("planet"): float(p.get("score", 50)) for p in chart.get("placements", []) if p.get("planet")}


def compatibility_report(chart_a: Dict, chart_b: Dict, mode: str = "relationship") -> Dict:
    mode = mode if mode in MODE_DIMENSIONS else "relationship"
    sa, sb = _domain_scores(chart_a), _domain_scores(chart_b)
    dims = []
    weighted = 0.0
    weight_total = 0.0

    for key, weight in MODE_DIMENSIONS[mode]:
        a, b = sa.get(key, 50), sb.get(key, 50)
        # Similarity rewards comparable operating rhythm; joint strength rewards
        # two reasonably supported charts. Neither is an objective compatibility fact.
        similarity = 100 - abs(a - b)
        joint = (a + b) / 2
        score = _clamp(0.55 * similarity + 0.45 * joint)
        dims.append({
            "key": key,
            "label": SYNTHETIC_LABELS.get(key, DOMAIN_RULES.get(key, {}).get("label", key.replace("_", " ").title())),
            "score": round(score, 1),
            "a": round(a, 1),
            "b": round(b, 1),
            "similarity": round(similarity, 1),
        })
        weighted += score * weight
        weight_total += weight

    # Cross-chart planetary house resonance: deliberately low weight.
    ha, hb = _planet_house_map(chart_a), _planet_house_map(chart_b)
    sta, stb = _planet_strength_map(chart_a), _planet_strength_map(chart_b)
    resonance_rows = []
    resonance_sum = 0.0
    for planet in sorted(set(ha) & set(hb)):
        distance = min((ha[planet] - hb[planet]) % 12, (hb[planet] - ha[planet]) % 12)
        positional = {0: 78, 1: 68, 2: 62, 3: 58, 4: 54, 5: 51, 6: 48}.get(distance, 50)
        strength_balance = 100 - abs(sta.get(planet, 50) - stb.get(planet, 50))
        rs = _clamp(0.65 * positional + 0.35 * strength_balance)
        resonance_sum += rs
        resonance_rows.append({
            "planet": planet, "house_a": ha[planet], "house_b": hb[planet],
            "house_distance": distance, "score": round(rs, 1),
        })
    resonance = resonance_sum / max(1, len(resonance_rows))
    domain_index = weighted / max(weight_total, 1)
    overall = _clamp(domain_index * 0.88 + resonance * 0.12)

    if overall >= 72:
        band = "Strong symbolic operating alignment"
    elif overall >= 61:
        band = "Constructive alignment with manageable differences"
    elif overall >= 48:
        band = "Mixed alignment — clarify expectations and roles"
    else:
        band = "Higher-friction pattern — use explicit communication and verification"

    strongest = sorted(dims, key=lambda x: x["score"], reverse=True)[:3]
    watch = sorted(dims, key=lambda x: x["score"])[:3]
    return {
        "mode": mode,
        "person_a": (chart_a.get("profile") or {}).get("name", "Person A"),
        "person_b": (chart_b.get("profile") or {}).get("name", "Person B"),
        "overall_index": round(overall, 1),
        "band": band,
        "dimensions": dims,
        "strongest": strongest,
        "watch": watch,
        "planet_resonance": round(resonance, 1),
        "planet_rows": resonance_rows,
        "practical_checks": {
            "relationship": ["Discuss money expectations", "Discuss family boundaries", "Discuss conflict style and communication"],
            "business": ["Define roles and authority", "Document capital/profit sharing", "Set approval and exit rules"],
            "family": ["Clarify responsibilities", "Use respectful boundaries", "Separate care from control"],
        }[mode],
        "note": "This is a symbolic cross-chart comparison index, not a scientific compatibility probability and not a reason to start/end a relationship or partnership.",
    }


def family_matrix(charts: List[Dict]) -> Dict:
    charts = [c for c in charts if c.get("placements")][:8]
    names = [(c.get("profile") or {}).get("name", f"Person {i+1}") for i, c in enumerate(charts)]
    pairs = []
    for i in range(len(charts)):
        for j in range(i + 1, len(charts)):
            r = compatibility_report(charts[i], charts[j], "family")
            pairs.append({
                "a_index": i, "b_index": j, "a": names[i], "b": names[j],
                "score": r["overall_index"], "band": r["band"],
                "strongest": r["strongest"][:2], "watch": r["watch"][:2],
            })
    avg = round(sum(x["score"] for x in pairs) / max(1, len(pairs)), 1) if pairs else None
    return {
        "members": names,
        "pair_count": len(pairs),
        "family_alignment_index": avg,
        "pairs": sorted(pairs, key=lambda x: x["score"], reverse=True),
        "note": "Family Matrix compares communication/support patterns symbolically. It does not label any family member as the cause of conflict.",
    }


def prediction_consensus(chart: Dict, year: int) -> Dict:
    fy = forecast_year(chart, int(year))
    rows = []
    for key, d in fy.get("domains", {}).items():
        ev = d.get("evidence", [])
        support_layers = sorted({e.get("layer") for e in ev if e.get("direction") == "support" and e.get("layer")})
        caution_layers = sorted({e.get("layer") for e in ev if e.get("direction") == "caution" and e.get("layer")})
        n = len(support_layers) + len(caution_layers)
        agreement = abs(len(support_layers) - len(caution_layers)) / max(1, n)
        coverage = min(1.0, len(d.get("layers", [])) / 7.0)
        consensus = _clamp(45 + 35 * agreement + 20 * coverage)
        dominant = "support" if len(support_layers) > len(caution_layers) else ("caution" if len(caution_layers) > len(support_layers) else "mixed")
        contradiction = len(support_layers) > 0 and len(caution_layers) > 0
        rows.append({
            "key": key, "label": d.get("label"), "score": d.get("score"),
            "consensus": round(consensus, 1), "dominant": dominant,
            "support_layers": support_layers, "caution_layers": caution_layers,
            "contradiction": contradiction,
        })
    rows.sort(key=lambda x: (x["consensus"], abs(float(x["score"]) - 50)), reverse=True)
    return {
        "year": int(year),
        "high_consensus": [x for x in rows if x["consensus"] >= 70][:6],
        "contradictions": [x for x in rows if x["contradiction"]][:8],
        "all": rows,
        "note": "Consensus measures agreement among software evidence layers, not truth probability. Contradiction is shown instead of hiding mixed evidence.",
    }


def rule_audit(chart: Dict, year: Optional[int] = None) -> Dict:
    if year is None:
        year = datetime.now().year
    consensus = prediction_consensus(chart, year)
    prediction_rows = []
    for r in chart.get("predictions", []):
        prediction_rows.append({
            "key": r.get("key"), "label": r.get("label"), "score": r.get("score"),
            "confidence": r.get("confidence"), "layers": r.get("layers", []),
            "support": r.get("support", [])[:5], "cautions": r.get("cautions", [])[:5],
        })
    remedy_plan = chart.get("remedy_plan") or {}
    remedy_rows = []
    for group in ("primary", "secondary"):
        for r in remedy_plan.get(group, []):
            remedy_rows.append({
                "group": group, "id": r.get("id"), "planet": r.get("planet"), "house": r.get("house"),
                "source_class": r.get("source_class"), "safety": r.get("safety"),
                "why_selected": r.get("why_selected"),
            })
    return {
        "year": year,
        "calculated_layer": {
            "engine": chart.get("engine", {}),
            "placements": [{k: p.get(k) for k in ("planet", "house", "sign", "degree_in_sign", "retrograde")} for p in chart.get("placements", [])],
        },
        "reference_layer": {
            "rule_profile": (chart.get("profile") or {}).get("rule_profile"),
            "special_teva": chart.get("special_teva", []),
            "masnui": chart.get("masnui", []),
            "rin": chart.get("rin", []),
        },
        "prediction_layer": prediction_rows,
        "consensus": consensus,
        "remedy_layer": remedy_rows,
        "boundary": "Astronomy, traditional/reference rules, software synthesis and narrative interpretation remain separate. Audit data is meant to make disagreement visible.",
    }


def _parse_time(t: str) -> datetime:
    return datetime.strptime(t, "%H:%M")


def _fmt_time(dt: datetime) -> str:
    return dt.strftime("%H:%M")


def rectification_assistant(base_payload: Dict, window_minutes: int, step_minutes: int, events: List[Dict]) -> Dict:
    """Rank nearby candidate times against user-supplied known event years.

    `events` items: {year:int, domain:str, direction:'support'|'friction'|'neutral', note?:str}
    This is an exploratory ranking, not proof of a correct birth time.
    """
    window = max(5, min(int(window_minutes), 120))
    step = max(2, min(int(step_minutes), 30))
    bt = str(base_payload.get("birth_time", ""))[:5]
    birth_date = str(base_payload.get("birth_date", ""))
    try:
        base_time = datetime.fromisoformat(f"{birth_date}T{bt}")
    except Exception as exc:
        raise ValueError("birth_date/birth_time must be valid ISO date and HH:MM") from exc
    clean_events = []
    for e in events[:8]:
        key = str(e.get("domain", "")).strip()
        if key not in DOMAIN_RULES:
            continue
        direction = str(e.get("direction", "support"))
        if direction not in {"support", "friction", "neutral"}:
            direction = "support"
        clean_events.append({"year": int(e.get("year")), "domain": key, "direction": direction, "note": str(e.get("note", ""))[:240]})
    if not clean_events:
        raise ValueError("Add at least one known event with a supported domain key")

    offsets = list(range(-window, window + 1, step))
    if 0 not in offsets:
        offsets.append(0)
    offsets = sorted(set(offsets))
    candidates = []

    for off in offsets:
        dt = base_time + timedelta(minutes=off)
        payload = dict(base_payload)
        payload["birth_date"] = dt.date().isoformat()
        payload["birth_time"] = _fmt_time(dt)
        try:
            chart = enrich_chart(chart_payload(payload), years=1)
        except Exception:
            continue
        matches = []
        total = 0.0
        for ev in clean_events:
            fy = forecast_year(chart, ev["year"])
            domain = fy.get("domains", {}).get(ev["domain"], {})
            score = float(domain.get("score", 50))
            if ev["direction"] == "support":
                fit = score
            elif ev["direction"] == "friction":
                fit = 100 - score
            else:
                fit = 100 - abs(score - 50) * 2
            total += fit
            matches.append({**ev, "domain_score": round(score, 1), "fit": round(_clamp(fit), 1)})
        avg = total / len(clean_events)
        # Small preference for candidates closer to the recorded time when event fit is equal.
        proximity = max(0.0, 100 - abs(off) * 0.5)
        rank_score = _clamp(avg * 0.94 + proximity * 0.06)
        candidates.append({
            "birth_time": payload["birth_time"], "offset_minutes": off,
            "fit_index": round(rank_score, 1), "event_matches": matches,
            "changed_houses": {p.get("planet"): p.get("house") for p in chart.get("placements", [])},
        })

    candidates.sort(key=lambda x: x["fit_index"], reverse=True)
    if candidates:
        spread = round(candidates[0]["fit_index"] - candidates[-1]["fit_index"], 1)
    else:
        spread = 0.0
    return {
        "base_time": bt, "window_minutes": window, "step_minutes": step,
        "events": clean_events, "top_candidates": candidates[:10], "candidate_count": len(candidates),
        "discrimination_spread": spread,
        "stability_note": "A low score spread means this fixed-house model does not meaningfully distinguish nearby times for the supplied events.",
        "note": "Rectification Assistant is an exploratory ranking against user-supplied known events. It cannot verify the true birth time and should not override documentary evidence.",
    }
